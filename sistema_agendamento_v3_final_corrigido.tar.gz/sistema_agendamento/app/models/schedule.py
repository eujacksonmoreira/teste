from sqlalchemy import Column, Integer, String, DateTime, Text, ForeignKey, Enum, Date
from sqlalchemy.orm import relationship
from datetime import datetime, date
import enum
from .database import Base

class DayOfWeek(enum.Enum):
    MONDAY = "monday"
    TUESDAY = "tuesday"
    WEDNESDAY = "wednesday"
    THURSDAY = "thursday"
    FRIDAY = "friday"

class Period(enum.Enum):
    MORNING = "morning"
    AFTERNOON = "afternoon"

class WeeklySchedule(Base):
    __tablename__ = "weekly_schedules"
    
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    
    # Data da semana (segunda-feira da semana)
    week_start_date = Column(Date, nullable=False)
    
    # Dia da semana e período
    day_of_week = Column(Enum(DayOfWeek), nullable=False)
    period = Column(Enum(Period), nullable=False)
    
    # Localização/atividade
    location = Column(String(200), nullable=False)
    activity = Column(String(200))
    description = Column(Text)
    
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relacionamento
    user = relationship("User", back_populates="weekly_schedules")

