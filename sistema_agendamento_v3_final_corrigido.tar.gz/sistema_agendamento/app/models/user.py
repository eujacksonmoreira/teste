from sqlalchemy import Column, Integer, String, Boolean, DateTime, Text, ForeignKey
from sqlalchemy.orm import relationship
from datetime import datetime
from .database import Base

class User(Base):
    __tablename__ = "users"
    
    id = Column(Integer, primary_key=True, index=True)
    email = Column(String(255), unique=True, index=True, nullable=False)
    username = Column(String(100), unique=True, index=True, nullable=False)
    full_name = Column(String(255), nullable=False)
    hashed_password = Column(String(255), nullable=False)
    is_active = Column(Boolean, default=True)
    is_admin = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relacionamentos
    profile = relationship("Profile", back_populates="user", uselist=False)
    bookings = relationship("Booking", back_populates="user")
    weekly_schedules = relationship("WeeklySchedule", back_populates="user")
    user_roles = relationship("UserRole", foreign_keys="UserRole.user_id", back_populates="user")
    
    def get_permissions(self):
        """Obter todas as permissões do usuário baseadas em suas roles"""
        permissions = {
            'can_edit_bookings': False,
            'can_edit_schedule': False,
            'can_view_all_bookings': False,
            'can_manage_users': False,
            'can_manage_resources': False
        }
        
        # Admins têm todas as permissões
        if self.is_admin:
            return {key: True for key in permissions.keys()}
        
        # Combinar permissões de todas as roles do usuário
        for user_role in self.user_roles:
            role_permissions = user_role.role.permissions
            if role_permissions:
                for perm in role_permissions:
                    permissions['can_edit_bookings'] |= perm.can_edit_bookings
                    permissions['can_edit_schedule'] |= perm.can_edit_schedule
                    permissions['can_view_all_bookings'] |= perm.can_view_all_bookings
                    permissions['can_manage_users'] |= perm.can_manage_users
                    permissions['can_manage_resources'] |= perm.can_manage_resources
        
        return permissions

class Profile(Base):
    __tablename__ = "profiles"
    
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False, unique=True)
    department = Column(String(100))
    position = Column(String(100))
    phone = Column(String(20))
    bio = Column(Text)
    avatar_url = Column(String(500))
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relacionamento
    user = relationship("User", back_populates="profile")

