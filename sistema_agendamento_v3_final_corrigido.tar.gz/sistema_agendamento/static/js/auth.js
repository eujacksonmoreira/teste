// Authentication utilities
class AuthManager {
    constructor() {
        this.token = localStorage.getItem('token');
        this.user = null;
        this.init();
    }

    async init() {
        if (this.token) {
            try {
                await this.getCurrentUser();
                this.updateNavbar();
            } catch (error) {
                console.error('Erro ao inicializar autenticação:', error);
                // Não fazer logout automático, apenas limpar dados inválidos
                if (error.response?.status === 401) {
                    this.clearInvalidAuth();
                }
            }
        } else {
            this.updateNavbar();
        }
    }

    clearInvalidAuth() {
        this.token = null;
        this.user = null;
        localStorage.removeItem('token');
        this.updateNavbar();
    }

    async login(username, password) {
        try {
            const response = await axios.post('/api/auth/login-json', {
                username: username,
                password: password
            });

            this.token = response.data.access_token;
            localStorage.setItem('token', this.token);
            
            await this.getCurrentUser();
            this.updateNavbar();
            
            return { success: true, user: this.user };
        } catch (error) {
            console.error('Erro no login:', error);
            return { 
                success: false, 
                message: error.response?.data?.detail || 'Erro ao fazer login' 
            };
        }
    }

    async register(userData) {
        try {
            const response = await axios.post('/api/auth/register', userData);
            return { success: true, user: response.data };
        } catch (error) {
            console.error('Erro no registro:', error);
            return { 
                success: false, 
                message: error.response?.data?.detail || 'Erro ao registrar usuário' 
            };
        }
    }

    async getCurrentUser() {
        if (!this.token) {
            throw new Error('Token não encontrado');
        }

        try {
            const response = await axios.get('/api/auth/me', {
                headers: { Authorization: `Bearer ${this.token}` }
            });
            
            this.user = response.data;
            return this.user;
        } catch (error) {
            console.error('Erro ao obter usuário atual:', error);
            throw error;
        }
    }

    logout() {
        this.token = null;
        this.user = null;
        localStorage.removeItem('token');
        this.updateNavbar();
        
        // Redirecionar apenas se solicitado explicitamente
        showAlert('Logout realizado com sucesso!', 'success');
    }

    updateNavbar() {
        const userDropdown = document.getElementById('userDropdown');
        const loginButton = document.getElementById('loginButton');
        const userName = document.getElementById('userName');
        const adminMenu = document.getElementById('adminMenu');

        if (this.user) {
            // Usuário logado
            if (userDropdown) userDropdown.style.display = 'block';
            if (loginButton) loginButton.style.display = 'none';
            if (userName) userName.textContent = this.user.full_name || this.user.username;
            
            // Mostrar menu admin se for admin
            if (this.user.is_admin && adminMenu) {
                adminMenu.style.display = 'block';
            }
        } else {
            // Usuário não logado
            if (userDropdown) userDropdown.style.display = 'none';
            if (loginButton) loginButton.style.display = 'block';
            if (adminMenu) adminMenu.style.display = 'none';
        }
    }

    isAuthenticated() {
        return !!this.token && !!this.user;
    }

    isAdmin() {
        return this.user && this.user.is_admin;
    }

    getAuthHeaders() {
        if (!this.token) {
            throw new Error('Usuário não autenticado');
        }
        return { Authorization: `Bearer ${this.token}` };
    }

    async makeAuthenticatedRequest(method, url, data = null) {
        try {
            const config = {
                method: method,
                url: url,
                headers: this.getAuthHeaders()
            };

            if (data) {
                config.data = data;
            }

            const response = await axios(config);
            return { success: true, data: response.data };
        } catch (error) {
            console.error('Erro na requisição autenticada:', error);
            
            if (error.response?.status === 401) {
                showAlert('Sessão expirada. Por favor, faça login novamente.', 'warning');
                this.clearInvalidAuth();
                return { success: false, message: 'Sessão expirada. Faça login novamente.' };
            }
            
            return { 
                success: false, 
                message: error.response?.data?.detail || 'Erro na requisição' 
            };
        }
    }
}

// Instância global do gerenciador de autenticação
const authManager = new AuthManager();

// Função global para logout
function logout() {
    authManager.logout();
    // Redirecionar para home após logout
    setTimeout(() => {
        window.location.href = '/';
    }, 1000);
}

// Interceptor para adicionar token automaticamente (sem redirecionamento automático)
axios.interceptors.request.use(
    (config) => {
        const token = localStorage.getItem('token');
        if (token && !config.headers.Authorization) {
            config.headers.Authorization = `Bearer ${token}`;
        }
        return config;
    },
    (error) => {
        return Promise.reject(error);
    }
);

// Interceptor para tratar erros de autenticação (sem redirecionamento automático)
axios.interceptors.response.use(
    (response) => response,
    (error) => {
        // Não fazer logout automático, deixar para o código específico decidir
        return Promise.reject(error);
    }
);

// Verificar autenticação em páginas protegidas (sem redirecionamento automático)
function requireAuth() {
    if (!authManager.isAuthenticated()) {
        showAlert('Você precisa fazer login para acessar esta funcionalidade.', 'warning');
        return false;
    }
    return true;
}

// Verificar se é admin (sem redirecionamento automático)
function requireAdmin() {
    if (!authManager.isAuthenticated()) {
        showAlert('Você precisa fazer login para acessar esta funcionalidade.', 'warning');
        return false;
    }
    
    if (!authManager.isAdmin()) {
        showAlert('Acesso negado. Privilégios de administrador necessários.', 'danger');
        return false;
    }
    
    return true;
}

