-- Schema SQL para PostgreSQL
-- Sistema de Gestão de Processos Backoffice

-- Tabela de usuários
CREATE TABLE IF NOT EXISTS usuarios (
    id SERIAL PRIMARY KEY,
    nome VARCHAR(255) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    senha_hash VARCHAR(255) NOT NULL,
    perfil VARCHAR(50) NOT NULL CHECK(perfil IN ('administrador', 'comum')),
    ativo BOOLEAN DEFAULT TRUE,
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    atualizado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Índice para busca por email
CREATE INDEX idx_usuarios_email ON usuarios(email);

-- Tabela de tokens de convite
CREATE TABLE IF NOT EXISTS tokens_convite (
    id SERIAL PRIMARY KEY,
    usuario_id INTEGER NOT NULL,
    token VARCHAR(255) UNIQUE NOT NULL,
    expira_em TIMESTAMP NOT NULL,
    usado BOOLEAN DEFAULT FALSE,
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
);

-- Índice para busca por token
CREATE INDEX idx_tokens_convite_token ON tokens_convite(token);

-- Tabela de unidades
CREATE TABLE IF NOT EXISTS unidades (
    id SERIAL PRIMARY KEY,
    codigo VARCHAR(50) UNIQUE NOT NULL,
    nome VARCHAR(255) NOT NULL,
    ativo BOOLEAN DEFAULT TRUE
);

-- Índice para busca por código
CREATE INDEX idx_unidades_codigo ON unidades(codigo);

-- Tabela de colaboradores
CREATE TABLE IF NOT EXISTS colaboradores (
    id SERIAL PRIMARY KEY,
    nome VARCHAR(255) NOT NULL,
    cargo VARCHAR(50) NOT NULL CHECK(cargo IN ('estagiario', 'efetivo')),
    unidade_id INTEGER,
    ativo BOOLEAN DEFAULT TRUE,
    FOREIGN KEY (unidade_id) REFERENCES unidades(id) ON DELETE SET NULL
);

-- Índice para busca por unidade
CREATE INDEX idx_colaboradores_unidade ON colaboradores(unidade_id);

-- Tabela de tipos de processo
CREATE TABLE IF NOT EXISTS tipos_processo (
    id SERIAL PRIMARY KEY,
    codigo VARCHAR(50) UNIQUE NOT NULL,
    descricao VARCHAR(255) NOT NULL,
    ativo BOOLEAN DEFAULT TRUE
);

-- Índice para busca por código
CREATE INDEX idx_tipos_processo_codigo ON tipos_processo(codigo);

-- Tabela de processos
CREATE TABLE IF NOT EXISTS processos (
    id SERIAL PRIMARY KEY,
    protocolo VARCHAR(100) UNIQUE NOT NULL,
    tipo_processo_id INTEGER,
    unidade_id INTEGER,
    colaborador_id INTEGER,
    data_abertura TIMESTAMP NOT NULL,
    data_conclusao TIMESTAMP,
    tempo_processamento_minutos INTEGER,
    status VARCHAR(50) NOT NULL,
    observacao TEXT,
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (tipo_processo_id) REFERENCES tipos_processo(id) ON DELETE SET NULL,
    FOREIGN KEY (unidade_id) REFERENCES unidades(id) ON DELETE SET NULL,
    FOREIGN KEY (colaborador_id) REFERENCES colaboradores(id) ON DELETE SET NULL
);

-- Índices para melhor performance
CREATE INDEX idx_processos_protocolo ON processos(protocolo);
CREATE INDEX idx_processos_data_abertura ON processos(data_abertura);
CREATE INDEX idx_processos_unidade ON processos(unidade_id);
CREATE INDEX idx_processos_tipo ON processos(tipo_processo_id);
CREATE INDEX idx_processos_colaborador ON processos(colaborador_id);
CREATE INDEX idx_processos_status ON processos(status);

-- Tabela de logs de importação
CREATE TABLE IF NOT EXISTS logs_importacao (
    id SERIAL PRIMARY KEY,
    data_importacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    registros_importados INTEGER NOT NULL DEFAULT 0,
    registros_erro INTEGER NOT NULL DEFAULT 0,
    status VARCHAR(50) NOT NULL,
    mensagem TEXT
);

-- Índice para busca por data
CREATE INDEX idx_logs_importacao_data ON logs_importacao(data_importacao);

-- Tabela de configurações
CREATE TABLE IF NOT EXISTS configuracoes (
    id SERIAL PRIMARY KEY,
    chave VARCHAR(100) UNIQUE NOT NULL,
    valor TEXT NOT NULL,
    descricao TEXT,
    atualizado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Índice para busca por chave
CREATE INDEX idx_configuracoes_chave ON configuracoes(chave);

-- Tabela de simulações
CREATE TABLE IF NOT EXISTS simulacoes (
    id SERIAL PRIMARY KEY,
    nome VARCHAR(255) NOT NULL,
    efetivos INTEGER NOT NULL,
    estagiarios INTEGER NOT NULL,
    capacidade_mensal_estimada INTEGER,
    demanda_prevista INTEGER,
    percentual_atendimento NUMERIC(5,2),
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    usuario_id INTEGER,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE SET NULL
);

-- Índice para busca por usuário
CREATE INDEX idx_simulacoes_usuario ON simulacoes(usuario_id);

-- Inserir configurações padrão
INSERT INTO configuracoes (chave, valor, descricao) VALUES
    ('jornada_efetivo_inicio', '08:30', 'Horário de início da jornada de efetivos'),
    ('jornada_efetivo_fim', '17:30', 'Horário de fim da jornada de efetivos'),
    ('jornada_estagiario_inicio', '09:00', 'Horário de início da jornada de estagiários'),
    ('jornada_estagiario_fim', '16:00', 'Horário de fim da jornada de estagiários'),
    ('tempo_almoco_minutos', '60', 'Tempo de almoço em minutos'),
    ('efetivos_simulacao', '5', 'Quantidade de efetivos para simulação'),
    ('estagiarios_simulacao', '3', 'Quantidade de estagiários para simulação')
ON CONFLICT (chave) DO NOTHING;

-- Comentários nas tabelas
COMMENT ON TABLE usuarios IS 'Tabela de usuários do sistema';
COMMENT ON TABLE tokens_convite IS 'Tokens de convite para novos usuários';
COMMENT ON TABLE unidades IS 'Unidades/Agências';
COMMENT ON TABLE colaboradores IS 'Colaboradores do backoffice';
COMMENT ON TABLE tipos_processo IS 'Tipos de processos';
COMMENT ON TABLE processos IS 'Processos do backoffice';
COMMENT ON TABLE logs_importacao IS 'Logs de importação de dados';
COMMENT ON TABLE configuracoes IS 'Configurações do sistema';
COMMENT ON TABLE simulacoes IS 'Simulações de capacidade';

