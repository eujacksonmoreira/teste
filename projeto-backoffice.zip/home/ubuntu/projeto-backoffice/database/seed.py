"""
Script de seed para popular o banco de dados com dados de exemplo
"""
import asyncio
import sys
import os
from datetime import datetime, timedelta
import random

# Adicionar o diretório backend ao path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'backend'))

from database import obter_conexao
from autenticacao import criar_hash_senha

# Dados de exemplo
UNIDADES = [
    ('AG001', 'Agência Centro'),
    ('AG002', 'Agência Norte'),
    ('AG003', 'Agência Sul'),
    ('AG004', 'Agência Leste'),
    ('AG005', 'Agência Oeste'),
    ('AG006', 'Agência Shopping'),
    ('AG007', 'Agência Industrial'),
    ('AG008', 'Agência Universitária'),
]

TIPOS_PROCESSO = [
    ('ABERTURA_CONTA', 'Abertura de Conta'),
    ('EMPRESTIMO', 'Solicitação de Empréstimo'),
    ('CARTAO', 'Solicitação de Cartão'),
    ('INVESTIMENTO', 'Abertura de Investimento'),
    ('CONSORCIO', 'Adesão a Consórcio'),
    ('SEGUROS', 'Contratação de Seguros'),
    ('RENEGOCIACAO', 'Renegociação de Dívida'),
    ('ENCERRAMENTO', 'Encerramento de Conta'),
]

NOMES_COLABORADORES = [
    'Ana Silva', 'Bruno Santos', 'Carlos Oliveira', 'Diana Costa',
    'Eduardo Lima', 'Fernanda Souza', 'Gabriel Alves', 'Helena Martins',
    'Igor Pereira', 'Julia Rodrigues', 'Kevin Fernandes', 'Larissa Gomes',
    'Marcos Ribeiro', 'Natália Cardoso', 'Otávio Barbosa', 'Paula Araújo',
    'Rafael Mendes', 'Sabrina Dias', 'Thiago Carvalho', 'Vanessa Rocha'
]

STATUS_PROCESSOS = ['aberto', 'em_andamento', 'concluido']

async def seed_database():
    """Popula o banco de dados com dados de exemplo"""
    conn = await obter_conexao()
    
    print("Iniciando seed do banco de dados...")
    
    # 1. Criar usuário administrador padrão
    print("Criando usuário administrador...")
    senha_hash = criar_hash_senha('admin123')
    await conn.execute(
        """
        INSERT OR IGNORE INTO usuarios (nome, email, senha_hash, perfil, ativo)
        VALUES (?, ?, ?, ?, ?)
        """,
        ('Administrador', 'admin@sistema.com', senha_hash, 'administrador', 1)
    )
    
    # 2. Criar usuário comum de exemplo
    print("Criando usuário comum...")
    senha_hash = criar_hash_senha('user123')
    await conn.execute(
        """
        INSERT OR IGNORE INTO usuarios (nome, email, senha_hash, perfil, ativo)
        VALUES (?, ?, ?, ?, ?)
        """,
        ('Usuário Comum', 'usuario@sistema.com', senha_hash, 'comum', 1)
    )
    
    # 3. Inserir unidades
    print("Inserindo unidades...")
    for codigo, nome in UNIDADES:
        await conn.execute(
            "INSERT OR IGNORE INTO unidades (codigo, nome) VALUES (?, ?)",
            (codigo, nome)
        )
    
    # 4. Inserir tipos de processo
    print("Inserindo tipos de processo...")
    for codigo, descricao in TIPOS_PROCESSO:
        await conn.execute(
            "INSERT OR IGNORE INTO tipos_processo (codigo, descricao) VALUES (?, ?)",
            (codigo, descricao)
        )
    
    # 5. Inserir colaboradores
    print("Inserindo colaboradores...")
    cursor = await conn.execute("SELECT id FROM unidades")
    unidades_ids = [row[0] for row in await cursor.fetchall()]
    
    for nome in NOMES_COLABORADORES:
        cargo = random.choice(['efetivo', 'estagiario'])
        unidade_id = random.choice(unidades_ids)
        await conn.execute(
            "INSERT OR IGNORE INTO colaboradores (nome, cargo, unidade_id) VALUES (?, ?, ?)",
            (nome, cargo, unidade_id)
        )
    
    # 6. Inserir processos de exemplo
    print("Inserindo processos de exemplo (200 registros)...")
    
    cursor = await conn.execute("SELECT id FROM tipos_processo")
    tipos_ids = [row[0] for row in await cursor.fetchall()]
    
    cursor = await conn.execute("SELECT id FROM colaboradores")
    colaboradores_ids = [row[0] for row in await cursor.fetchall()]
    
    # Gerar 200 processos nos últimos 6 meses
    data_inicio = datetime.now() - timedelta(days=180)
    
    for i in range(200):
        # Gerar dados aleatórios
        protocolo = f"PROC{datetime.now().year}{i+1:05d}"
        tipo_id = random.choice(tipos_ids)
        unidade_id = random.choice(unidades_ids)
        colaborador_id = random.choice(colaboradores_ids)
        
        # Data de abertura aleatória nos últimos 6 meses
        dias_aleatorio = random.randint(0, 180)
        data_abertura = data_inicio + timedelta(days=dias_aleatorio)
        
        # Status e data de conclusão
        status = random.choice(STATUS_PROCESSOS)
        data_conclusao = None
        tempo_processamento = None
        
        if status == 'concluido':
            # Tempo de processamento entre 30 minutos e 5 horas
            tempo_processamento = random.randint(30, 300)
            data_conclusao = data_abertura + timedelta(minutes=tempo_processamento)
        elif status == 'em_andamento':
            # Alguns processos em andamento já têm tempo parcial
            if random.random() > 0.5:
                tempo_processamento = random.randint(30, 180)
        
        # Observação aleatória
        observacoes = [
            'Processo normal',
            'Cliente solicitou documentação adicional',
            'Aguardando aprovação',
            'Documentação completa',
            '<p>Observação com HTML</p>',
            'Processo prioritário',
            None
        ]
        observacao = random.choice(observacoes)
        
        await conn.execute(
            """
            INSERT OR IGNORE INTO processos 
            (protocolo, tipo_processo_id, unidade_id, colaborador_id, data_abertura, 
             data_conclusao, tempo_processamento_minutos, status, observacao)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (protocolo, tipo_id, unidade_id, colaborador_id, data_abertura.isoformat(),
             data_conclusao.isoformat() if data_conclusao else None, 
             tempo_processamento, status, observacao)
        )
    
    # 7. Inserir algumas simulações de exemplo
    print("Inserindo simulações de exemplo...")
    cursor = await conn.execute("SELECT id FROM usuarios WHERE perfil = 'administrador' LIMIT 1")
    admin_id = (await cursor.fetchone())[0]
    
    simulacoes_exemplo = [
        ('Cenário Atual', 5, 3, 440, 500, 88.0),
        ('Expansão Moderada', 7, 4, 616, 500, 123.2),
        ('Redução de Equipe', 3, 2, 264, 500, 52.8),
        ('Equipe Completa', 10, 5, 880, 500, 176.0),
    ]
    
    for nome, efetivos, estagiarios, capacidade, demanda, percentual in simulacoes_exemplo:
        await conn.execute(
            """
            INSERT OR IGNORE INTO simulacoes 
            (nome, efetivos, estagiarios, capacidade_mensal_estimada, demanda_prevista, percentual_atendimento, usuario_id)
            VALUES (?, ?, ?, ?, ?, ?, ?)
            """,
            (nome, efetivos, estagiarios, capacidade, demanda, percentual, admin_id)
        )
    
    await conn.commit()
    print("✓ Seed concluído com sucesso!")
    print("\n=== CREDENCIAIS DE ACESSO ===")
    print("Administrador:")
    print("  Email: admin@sistema.com")
    print("  Senha: admin123")
    print("\nUsuário Comum:")
    print("  Email: usuario@sistema.com")
    print("  Senha: user123")
    print("=============================\n")

if __name__ == '__main__':
    asyncio.run(seed_database())

