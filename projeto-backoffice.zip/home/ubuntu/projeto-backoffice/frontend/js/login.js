/**
 * Script da página de login
 */

document.getElementById('formLogin').addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const email = document.getElementById('email').value;
    const senha = document.getElementById('senha').value;
    const btnLogin = document.getElementById('btnLogin');
    const mensagemErro = document.getElementById('mensagemErro');
    
    // Esconder mensagem de erro
    esconderErro(mensagemErro);
    
    // Desabilitar botão
    btnLogin.disabled = true;
    btnLogin.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>Entrando...';
    
    try {
        const response = await apiRequest('/auth/login', {
            method: 'POST',
            body: JSON.stringify({ email, senha })
        });
        
        // Armazenar token e dados do usuário
        localStorage.setItem(TOKEN_KEY, response.token);
        localStorage.setItem(USER_KEY, JSON.stringify(response.usuario));
        
        // Redirecionar para dashboard
        window.location.href = 'index.html';
    } catch (error) {
        mostrarErro(mensagemErro, error.message || 'Erro ao fazer login');
        btnLogin.disabled = false;
        btnLogin.textContent = 'Entrar';
    }
});

