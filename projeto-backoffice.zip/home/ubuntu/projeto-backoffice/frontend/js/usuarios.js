/**
 * Script da página de usuários
 */

// Verificar se é admin
if (!isAdmin()) {
    window.location.href = 'index.html';
}

// Carregar usuários ao carregar a página
document.addEventListener('DOMContentLoaded', () => {
    carregarUsuarios();
});

/**
 * Carrega a lista de usuários
 */
async function carregarUsuarios() {
    try {
        const usuarios = await apiRequest('/usuarios/');
        
        const tbody = document.getElementById('tabelaUsuarios');
        tbody.innerHTML = '';
        
        if (usuarios.length === 0) {
            tbody.innerHTML = '<tr><td colspan="6" class="text-center">Nenhum usuário encontrado</td></tr>';
            return;
        }
        
        usuarios.forEach(usuario => {
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td>${usuario.nome}</td>
                <td>${usuario.email}</td>
                <td><span class="badge bg-${usuario.perfil === 'administrador' ? 'danger' : 'primary'}">${usuario.perfil}</span></td>
                <td><span class="badge bg-${usuario.ativo ? 'success' : 'secondary'}">${usuario.ativo ? 'Ativo' : 'Inativo'}</span></td>
                <td>${formatarDataHora(usuario.criado_em)}</td>
                <td>
                    ${usuario.ativo ? `
                        <button class="btn btn-sm btn-danger" onclick="desativarUsuario(${usuario.id})">
                            <i class="bi bi-x-circle"></i> Desativar
                        </button>
                    ` : ''}
                </td>
            `;
            tbody.appendChild(tr);
        });
    } catch (error) {
        console.error('Erro ao carregar usuários:', error);
        const tbody = document.getElementById('tabelaUsuarios');
        tbody.innerHTML = '<tr><td colspan="6" class="text-center text-danger">Erro ao carregar usuários</td></tr>';
    }
}

/**
 * Cria um novo usuário
 */
async function criarUsuario() {
    const nome = document.getElementById('nomeNovoUsuario').value;
    const email = document.getElementById('emailNovoUsuario').value;
    const perfil = document.getElementById('perfilNovoUsuario').value;
    const mensagemErro = document.getElementById('mensagemErroModal');
    
    esconderErro(mensagemErro);
    
    try {
        const response = await apiRequest('/usuarios/', {
            method: 'POST',
            body: JSON.stringify({ nome, email, perfil })
        });
        
        // Fechar modal
        const modal = bootstrap.Modal.getInstance(document.getElementById('modalNovoUsuario'));
        modal.hide();
        
        // Limpar formulário
        document.getElementById('formNovoUsuario').reset();
        
        // Recarregar lista
        carregarUsuarios();
        
        // Mostrar mensagem de sucesso
        alert(`Usuário criado com sucesso! Um email de convite foi enviado para ${email}`);
    } catch (error) {
        mostrarErro(mensagemErro, error.message || 'Erro ao criar usuário');
    }
}

/**
 * Desativa um usuário
 */
async function desativarUsuario(usuarioId) {
    if (!confirm('Tem certeza que deseja desativar este usuário?')) {
        return;
    }
    
    try {
        await apiRequest(`/usuarios/${usuarioId}`, {
            method: 'DELETE'
        });
        
        alert('Usuário desativado com sucesso!');
        carregarUsuarios();
    } catch (error) {
        console.error('Erro ao desativar usuário:', error);
        alert('Erro ao desativar usuário: ' + error.message);
    }
}

