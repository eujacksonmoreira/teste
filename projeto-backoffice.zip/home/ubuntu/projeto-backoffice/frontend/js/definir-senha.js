/**
 * Script da página de definir senha
 */

document.getElementById('formDefinirSenha').addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const senha = document.getElementById('senha').value;
    const confirmarSenha = document.getElementById('confirmarSenha').value;
    const btnDefinir = document.getElementById('btnDefinir');
    const mensagemErro = document.getElementById('mensagemErro');
    const mensagemSucesso = document.getElementById('mensagemSucesso');
    
    // Esconder mensagens
    esconderErro(mensagemErro);
    esconderErro(mensagemSucesso);
    
    // Validar senhas
    if (senha !== confirmarSenha) {
        mostrarErro(mensagemErro, 'As senhas não coincidem');
        return;
    }
    
    if (senha.length < 6) {
        mostrarErro(mensagemErro, 'A senha deve ter no mínimo 6 caracteres');
        return;
    }
    
    // Obter token da URL
    const token = getURLParameter('token');
    if (!token) {
        mostrarErro(mensagemErro, 'Token inválido ou ausente');
        return;
    }
    
    // Desabilitar botão
    btnDefinir.disabled = true;
    btnDefinir.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>Definindo...';
    
    try {
        await apiRequest('/usuarios/definir-senha', {
            method: 'POST',
            body: JSON.stringify({ token, senha })
        });
        
        // Mostrar mensagem de sucesso
        mensagemSucesso.textContent = 'Senha definida com sucesso! Redirecionando para login...';
        mensagemSucesso.classList.remove('d-none');
        
        // Redirecionar para login após 2 segundos
        setTimeout(() => {
            window.location.href = 'login.html';
        }, 2000);
    } catch (error) {
        mostrarErro(mensagemErro, error.message || 'Erro ao definir senha');
        btnDefinir.disabled = false;
        btnDefinir.textContent = 'Definir Senha';
    }
});

