/**
 * Configurações globais da aplicação
 */

// URL base da API (ajustar conforme ambiente)
const API_BASE_URL = window.location.hostname === 'localhost' 
    ? 'http://localhost:8000/api' 
    : '/api';

// Chave para armazenar o token no localStorage
const TOKEN_KEY = 'auth_token';

// Chave para armazenar dados do usuário no localStorage
const USER_KEY = 'user_data';

/**
 * Função auxiliar para fazer requisições à API
 */
async function apiRequest(endpoint, options = {}) {
    const token = localStorage.getItem(TOKEN_KEY);
    
    const defaultHeaders = {
        'Content-Type': 'application/json'
    };
    
    if (token) {
        defaultHeaders['Authorization'] = `Bearer ${token}`;
    }
    
    const config = {
        ...options,
        headers: {
            ...defaultHeaders,
            ...options.headers
        }
    };
    
    try {
        const response = await fetch(`${API_BASE_URL}${endpoint}`, config);
        
        // Se não autorizado, redirecionar para login
        if (response.status === 401) {
            localStorage.removeItem(TOKEN_KEY);
            localStorage.removeItem(USER_KEY);
            window.location.href = 'login.html';
            return;
        }
        
        // Se for um erro, lançar exceção
        if (!response.ok) {
            const error = await response.json().catch(() => ({ detail: 'Erro desconhecido' }));
            throw new Error(error.detail || `Erro: ${response.status}`);
        }
        
        // Se for download de arquivo, retornar o blob
        const contentType = response.headers.get('content-type');
        if (contentType && (contentType.includes('text/csv') || contentType.includes('spreadsheet'))) {
            return response.blob();
        }
        
        // Retornar JSON
        return await response.json();
    } catch (error) {
        console.error('Erro na requisição:', error);
        throw error;
    }
}

/**
 * Função para baixar arquivo
 */
function downloadFile(blob, filename) {
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    window.URL.revokeObjectURL(url);
    document.body.removeChild(a);
}

/**
 * Função para formatar data
 */
function formatarData(dataISO) {
    if (!dataISO) return '-';
    const data = new Date(dataISO);
    return data.toLocaleDateString('pt-BR');
}

/**
 * Função para formatar data e hora
 */
function formatarDataHora(dataISO) {
    if (!dataISO) return '-';
    const data = new Date(dataISO);
    return data.toLocaleString('pt-BR');
}

/**
 * Função para mostrar mensagem de erro
 */
function mostrarErro(elemento, mensagem) {
    elemento.textContent = mensagem;
    elemento.classList.remove('d-none');
}

/**
 * Função para esconder mensagem de erro
 */
function esconderErro(elemento) {
    elemento.classList.add('d-none');
}

/**
 * Função para obter parâmetro da URL
 */
function getURLParameter(name) {
    const urlParams = new URLSearchParams(window.location.search);
    return urlParams.get(name);
}

