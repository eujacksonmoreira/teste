/**
 * Script da página de simulação
 */

// Carregar dados ao carregar a página
document.addEventListener('DOMContentLoaded', () => {
    carregarSimulacoes();
    carregarConfiguracoes();
});

/**
 * Formulário de simulação
 */
document.getElementById('formSimulacao').addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const nome = document.getElementById('nomeSimulacao').value;
    const efetivos = parseInt(document.getElementById('qtdEfetivos').value);
    const estagiarios = parseInt(document.getElementById('qtdEstagiarios').value);
    
    try {
        const resultado = await apiRequest('/simulacao/', {
            method: 'POST',
            body: JSON.stringify({ nome, efetivos, estagiarios })
        });
        
        // Mostrar resultado
        mostrarResultado(resultado);
        
        // Recarregar histórico
        carregarSimulacoes();
        
        // Limpar formulário
        document.getElementById('formSimulacao').reset();
        document.getElementById('qtdEfetivos').value = 5;
        document.getElementById('qtdEstagiarios').value = 3;
    } catch (error) {
        console.error('Erro ao criar simulação:', error);
        alert('Erro ao criar simulação: ' + error.message);
    }
});

/**
 * Mostra o resultado da simulação
 */
function mostrarResultado(resultado) {
    const resultadoDiv = document.getElementById('resultadoSimulacao');
    resultadoDiv.style.display = 'block';
    
    document.getElementById('capacidadeMensal').textContent = resultado.capacidade_mensal_estimada.toLocaleString('pt-BR');
    document.getElementById('demandaPrevista').textContent = resultado.demanda_prevista.toLocaleString('pt-BR');
    
    const percentual = resultado.percentual_atendimento;
    const barra = document.getElementById('barraAtendimento');
    const percentualSpan = document.getElementById('percentualAtendimento');
    
    barra.style.width = `${Math.min(percentual, 100)}%`;
    percentualSpan.textContent = `${percentual.toFixed(1)}%`;
    
    // Definir cor da barra
    if (percentual >= 100) {
        barra.className = 'progress-bar bg-success';
    } else if (percentual >= 80) {
        barra.className = 'progress-bar bg-warning';
    } else {
        barra.className = 'progress-bar bg-danger';
    }
    
    // Mensagem
    const mensagem = document.getElementById('mensagemResultado');
    if (percentual >= 100) {
        mensagem.className = 'alert alert-success';
        mensagem.textContent = 'Capacidade suficiente para atender a demanda prevista!';
    } else if (percentual >= 80) {
        mensagem.className = 'alert alert-warning';
        mensagem.textContent = 'Capacidade próxima da demanda. Considere aumentar a equipe.';
    } else {
        mensagem.className = 'alert alert-danger';
        mensagem.textContent = 'Capacidade insuficiente! É necessário aumentar significativamente a equipe.';
    }
}

/**
 * Carrega o histórico de simulações
 */
async function carregarSimulacoes() {
    try {
        const simulacoes = await apiRequest('/simulacao/');
        
        const tbody = document.getElementById('tabelaSimulacoes');
        tbody.innerHTML = '';
        
        if (simulacoes.length === 0) {
            tbody.innerHTML = '<tr><td colspan="5" class="text-center">Nenhuma simulação encontrada</td></tr>';
            return;
        }
        
        simulacoes.forEach(sim => {
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td>${sim.nome}</td>
                <td>${sim.efetivos}</td>
                <td>${sim.estagiarios}</td>
                <td>${sim.capacidade_mensal_estimada}</td>
                <td><span class="badge bg-${sim.percentual_atendimento >= 100 ? 'success' : sim.percentual_atendimento >= 80 ? 'warning' : 'danger'}">${sim.percentual_atendimento.toFixed(1)}%</span></td>
            `;
            tbody.appendChild(tr);
        });
    } catch (error) {
        console.error('Erro ao carregar simulações:', error);
    }
}

/**
 * Carrega as configurações de jornada
 */
async function carregarConfiguracoes() {
    try {
        const response = await apiRequest('/simulacao/configuracoes');
        const configs = response.configuracoes;
        
        configs.forEach(config => {
            const elemento = document.getElementById(config.chave.replace(/_/g, ''));
            if (elemento) {
                elemento.value = config.valor;
            }
        });
    } catch (error) {
        console.error('Erro ao carregar configurações:', error);
    }
}

/**
 * Salva as configurações de jornada
 */
async function salvarConfiguracoes() {
    try {
        const configs = [
            { chave: 'jornada_efetivo_inicio', valor: document.getElementById('jornadaEfetivoInicio').value },
            { chave: 'jornada_efetivo_fim', valor: document.getElementById('jornadaEfetivoFim').value },
            { chave: 'jornada_estagiario_inicio', valor: document.getElementById('jornadaEstagiarioInicio').value },
            { chave: 'jornada_estagiario_fim', valor: document.getElementById('jornadaEstagiarioFim').value },
            { chave: 'tempo_almoco_minutos', valor: document.getElementById('tempoAlmoco').value }
        ];
        
        for (const config of configs) {
            await apiRequest(`/simulacao/configuracoes/${config.chave}`, {
                method: 'PUT',
                body: JSON.stringify({ valor: config.valor })
            });
        }
        
        alert('Configurações salvas com sucesso!');
    } catch (error) {
        console.error('Erro ao salvar configurações:', error);
        alert('Erro ao salvar configurações: ' + error.message);
    }
}

