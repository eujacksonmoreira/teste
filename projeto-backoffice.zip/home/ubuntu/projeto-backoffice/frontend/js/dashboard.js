/**
 * Script do dashboard
 */

let graficoVolume, graficoPorTipo, graficoPorUnidade;

// Carregar dados do dashboard ao carregar a página
document.addEventListener('DOMContentLoaded', async () => {
    await carregarCardsResumo();
    await carregarGraficoVolumeMensal();
    await carregarGraficoPorTipo();
    await carregarGraficoPorUnidade();
    await carregarCapacidadeBackoffice();
});

/**
 * Carrega os cards de resumo
 */
async function carregarCardsResumo() {
    try {
        const dados = await apiRequest('/dashboard/cards-resumo');
        
        document.getElementById('totalProcessos').textContent = dados.total_processos.toLocaleString('pt-BR');
        document.getElementById('processosMes').textContent = dados.processos_mes.toLocaleString('pt-BR');
        document.getElementById('taxaConclusao').textContent = `${dados.taxa_conclusao}%`;
        document.getElementById('tempoMedio').textContent = Math.round(dados.tempo_medio_processamento);
    } catch (error) {
        console.error('Erro ao carregar cards de resumo:', error);
    }
}

/**
 * Carrega o gráfico de volume mensal
 */
async function carregarGraficoVolumeMensal() {
    try {
        const response = await apiRequest('/dashboard/grafico-volume-mensal?meses=12');
        
        const labels = response.dados.map(d => {
            const [ano, mes] = d.mes.split('-');
            return `${mes}/${ano}`;
        });
        const valores = response.dados.map(d => d.quantidade);
        
        const ctx = document.getElementById('graficoVolumeMensal').getContext('2d');
        graficoVolume = new Chart(ctx, {
            type: 'line',
            data: {
                labels: labels,
                datasets: [{
                    label: 'Processos',
                    data: valores,
                    borderColor: '#0066cc',
                    backgroundColor: 'rgba(0, 102, 204, 0.1)',
                    tension: 0.4,
                    fill: true
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: true,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
        
        // Atualizar comentário IA
        document.getElementById('comentarioVolumeMensal').textContent = response.comentario_ia;
    } catch (error) {
        console.error('Erro ao carregar gráfico de volume mensal:', error);
        document.getElementById('comentarioVolumeMensal').textContent = 'Erro ao carregar dados';
    }
}

/**
 * Carrega o gráfico por tipo
 */
async function carregarGraficoPorTipo() {
    try {
        const response = await apiRequest('/dashboard/grafico-por-tipo');
        
        const labels = response.dados.map(d => d.tipo);
        const valores = response.dados.map(d => d.quantidade);
        
        const ctx = document.getElementById('graficoPorTipo').getContext('2d');
        graficoPorTipo = new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: labels,
                datasets: [{
                    data: valores,
                    backgroundColor: [
                        '#0066cc',
                        '#28a745',
                        '#ffc107',
                        '#dc3545',
                        '#17a2b8',
                        '#6c757d'
                    ]
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: true,
                plugins: {
                    legend: {
                        position: 'bottom'
                    }
                }
            }
        });
        
        // Atualizar comentário IA
        document.getElementById('comentarioPorTipo').textContent = response.comentario_ia;
    } catch (error) {
        console.error('Erro ao carregar gráfico por tipo:', error);
        document.getElementById('comentarioPorTipo').textContent = 'Erro ao carregar dados';
    }
}

/**
 * Carrega o gráfico por unidade
 */
async function carregarGraficoPorUnidade() {
    try {
        const response = await apiRequest('/dashboard/grafico-por-unidade');
        
        const labels = response.dados.map(d => d.unidade);
        const valores = response.dados.map(d => d.quantidade);
        
        const ctx = document.getElementById('graficoPorUnidade').getContext('2d');
        graficoPorUnidade = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: labels,
                datasets: [{
                    label: 'Processos',
                    data: valores,
                    backgroundColor: '#28a745'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: true,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
        
        // Atualizar comentário IA
        document.getElementById('comentarioPorUnidade').textContent = response.comentario_ia;
    } catch (error) {
        console.error('Erro ao carregar gráfico por unidade:', error);
        document.getElementById('comentarioPorUnidade').textContent = 'Erro ao carregar dados';
    }
}

/**
 * Carrega dados de capacidade do backoffice
 */
async function carregarCapacidadeBackoffice() {
    try {
        const response = await apiRequest('/dashboard/grafico-capacidade-backoffice');
        const dados = response.dados;
        
        document.getElementById('qtdEfetivos').textContent = dados.efetivos.quantidade;
        document.getElementById('capacidadeEfetivos').textContent = `${dados.efetivos.capacidade_diaria.toFixed(1)} proc/dia`;
        
        document.getElementById('qtdEstagiarios').textContent = dados.estagiarios.quantidade;
        document.getElementById('capacidadeEstagiarios').textContent = `${dados.estagiarios.capacidade_diaria.toFixed(1)} proc/dia`;
        
        document.getElementById('capacidadeTotal').textContent = Math.round(dados.total.capacidade_mensal);
        
        // Atualizar comentário IA
        document.getElementById('comentarioCapacidade').textContent = response.comentario_ia;
    } catch (error) {
        console.error('Erro ao carregar capacidade:', error);
        document.getElementById('comentarioCapacidade').textContent = 'Erro ao carregar dados';
    }
}

