/**
 * Script da página de processos
 */

let paginaAtual = 1;
const itensPorPagina = 50;

// Carregar processos ao carregar a página
document.addEventListener('DOMContentLoaded', () => {
    carregarProcessos();
});

/**
 * Carrega a lista de processos
 */
async function carregarProcessos(pagina = 1) {
    try {
        paginaAtual = pagina;
        const offset = (pagina - 1) * itensPorPagina;
        
        // Obter filtros
        const dataInicio = document.getElementById('filtroDataInicio').value;
        const dataFim = document.getElementById('filtroDataFim').value;
        const status = document.getElementById('filtroStatus').value;
        
        // Construir query string
        let queryParams = `limite=${itensPorPagina}&offset=${offset}`;
        if (dataInicio) queryParams += `&data_inicio=${dataInicio}`;
        if (dataFim) queryParams += `&data_fim=${dataFim}`;
        if (status) queryParams += `&status=${status}`;
        
        const processos = await apiRequest(`/processos/?${queryParams}`);
        
        // Atualizar tabela
        const tbody = document.getElementById('tabelaProcessos');
        tbody.innerHTML = '';
        
        if (processos.length === 0) {
            tbody.innerHTML = '<tr><td colspan="7" class="text-center">Nenhum processo encontrado</td></tr>';
            return;
        }
        
        processos.forEach(processo => {
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td>${processo.protocolo}</td>
                <td>${processo.tipo_processo || '-'}</td>
                <td>${processo.unidade || '-'}</td>
                <td>${processo.colaborador || '-'}</td>
                <td>${formatarDataHora(processo.data_abertura)}</td>
                <td><span class="badge bg-${getStatusColor(processo.status)}">${processo.status}</span></td>
                <td>${processo.tempo_processamento_minutos || '-'}</td>
            `;
            tbody.appendChild(tr);
        });
        
        // Atualizar paginação
        atualizarPaginacao(processos.length);
    } catch (error) {
        console.error('Erro ao carregar processos:', error);
        const tbody = document.getElementById('tabelaProcessos');
        tbody.innerHTML = '<tr><td colspan="7" class="text-center text-danger">Erro ao carregar processos</td></tr>';
    }
}

/**
 * Retorna a cor do badge de status
 */
function getStatusColor(status) {
    const cores = {
        'aberto': 'primary',
        'em_andamento': 'warning',
        'concluido': 'success',
        'cancelado': 'danger'
    };
    return cores[status] || 'secondary';
}

/**
 * Atualiza a paginação
 */
function atualizarPaginacao(quantidadeItens) {
    const paginacao = document.getElementById('paginacao');
    paginacao.innerHTML = '';
    
    // Botão anterior
    const liAnterior = document.createElement('li');
    liAnterior.className = `page-item ${paginaAtual === 1 ? 'disabled' : ''}`;
    liAnterior.innerHTML = `<a class="page-link" href="#" onclick="carregarProcessos(${paginaAtual - 1}); return false;">Anterior</a>`;
    paginacao.appendChild(liAnterior);
    
    // Número da página atual
    const liAtual = document.createElement('li');
    liAtual.className = 'page-item active';
    liAtual.innerHTML = `<a class="page-link" href="#">${paginaAtual}</a>`;
    paginacao.appendChild(liAtual);
    
    // Botão próximo (desabilitar se retornou menos itens que o limite)
    const liProximo = document.createElement('li');
    liProximo.className = `page-item ${quantidadeItens < itensPorPagina ? 'disabled' : ''}`;
    liProximo.innerHTML = `<a class="page-link" href="#" onclick="carregarProcessos(${paginaAtual + 1}); return false;">Próximo</a>`;
    paginacao.appendChild(liProximo);
}

/**
 * Aplica os filtros
 */
function aplicarFiltros() {
    carregarProcessos(1);
}

/**
 * Limpa os filtros
 */
function limparFiltros() {
    document.getElementById('filtroDataInicio').value = '';
    document.getElementById('filtroDataFim').value = '';
    document.getElementById('filtroStatus').value = '';
    carregarProcessos(1);
}

/**
 * Exporta processos para CSV
 */
async function exportarCSV() {
    try {
        const dataInicio = document.getElementById('filtroDataInicio').value;
        const dataFim = document.getElementById('filtroDataFim').value;
        
        let queryParams = '';
        if (dataInicio) queryParams += `?data_inicio=${dataInicio}`;
        if (dataFim) queryParams += `${queryParams ? '&' : '?'}data_fim=${dataFim}`;
        
        const blob = await apiRequest(`/relatorios/processos/csv${queryParams}`);
        downloadFile(blob, 'processos.csv');
    } catch (error) {
        console.error('Erro ao exportar CSV:', error);
        alert('Erro ao exportar CSV');
    }
}

