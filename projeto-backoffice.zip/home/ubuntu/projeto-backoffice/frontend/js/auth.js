/**
 * Módulo de autenticação
 */

/**
 * Verifica se o usuário está autenticado
 */
function verificarAutenticacao() {
    const token = localStorage.getItem(TOKEN_KEY);
    const userData = localStorage.getItem(USER_KEY);
    
    // Se não houver token e não estiver na página de login ou definir senha
    if (!token && !window.location.pathname.includes('login.html') && !window.location.pathname.includes('definir-senha.html')) {
        window.location.href = 'login.html';
        return false;
    }
    
    // Se houver token e estiver na página de login, redirecionar para dashboard
    if (token && window.location.pathname.includes('login.html')) {
        window.location.href = 'index.html';
        return false;
    }
    
    // Atualizar informações do usuário na navbar
    if (token && userData) {
        const user = JSON.parse(userData);
        const nomeUsuarioElement = document.getElementById('nomeUsuario');
        if (nomeUsuarioElement) {
            nomeUsuarioElement.textContent = user.nome;
        }
        
        // Mostrar menu admin se for administrador
        if (user.perfil === 'administrador') {
            const menuAdmin = document.getElementById('menuAdmin');
            if (menuAdmin) {
                menuAdmin.style.display = 'block';
            }
        }
    }
    
    return true;
}

/**
 * Faz logout do usuário
 */
async function fazerLogout() {
    try {
        await apiRequest('/auth/logout', { method: 'POST' });
    } catch (error) {
        console.error('Erro ao fazer logout:', error);
    } finally {
        localStorage.removeItem(TOKEN_KEY);
        localStorage.removeItem(USER_KEY);
        window.location.href = 'login.html';
    }
}

/**
 * Obtém dados do usuário atual
 */
function obterUsuarioAtual() {
    const userData = localStorage.getItem(USER_KEY);
    return userData ? JSON.parse(userData) : null;
}

/**
 * Verifica se o usuário é administrador
 */
function isAdmin() {
    const user = obterUsuarioAtual();
    return user && user.perfil === 'administrador';
}

// Verificar autenticação ao carregar a página
document.addEventListener('DOMContentLoaded', verificarAutenticacao);

