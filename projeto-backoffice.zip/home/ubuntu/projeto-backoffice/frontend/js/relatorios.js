/**
 * Script da página de relatórios
 */

// Verificar se é admin e mostrar seção de importação
document.addEventListener('DOMContentLoaded', () => {
    if (isAdmin()) {
        document.getElementById('cardImportacao').style.display = 'block';
        carregarLogsImportacao();
    }
    
    // Definir datas padrão (último mês)
    const hoje = new Date();
    const umMesAtras = new Date();
    umMesAtras.setMonth(umMesAtras.getMonth() - 1);
    
    document.getElementById('relProcessosDataInicio').value = umMesAtras.toISOString().split('T')[0];
    document.getElementById('relProcessosDataFim').value = hoje.toISOString().split('T')[0];
    
    document.getElementById('importDataInicio').value = umMesAtras.toISOString().split('T')[0];
    document.getElementById('importDataFim').value = hoje.toISOString().split('T')[0];
});

/**
 * Exporta processos para CSV
 */
async function exportarProcessosCSV() {
    try {
        const dataInicio = document.getElementById('relProcessosDataInicio').value;
        const dataFim = document.getElementById('relProcessosDataFim').value;
        
        let queryParams = '';
        if (dataInicio) queryParams += `?data_inicio=${dataInicio}`;
        if (dataFim) queryParams += `${queryParams ? '&' : '?'}data_fim=${dataFim}`;
        
        const blob = await apiRequest(`/relatorios/processos/csv${queryParams}`);
        downloadFile(blob, 'processos.csv');
    } catch (error) {
        console.error('Erro ao exportar CSV:', error);
        alert('Erro ao exportar CSV: ' + error.message);
    }
}

/**
 * Exporta processos para Excel
 */
async function exportarProcessosExcel() {
    try {
        const dataInicio = document.getElementById('relProcessosDataInicio').value;
        const dataFim = document.getElementById('relProcessosDataFim').value;
        
        let queryParams = '';
        if (dataInicio) queryParams += `?data_inicio=${dataInicio}`;
        if (dataFim) queryParams += `${queryParams ? '&' : '?'}data_fim=${dataFim}`;
        
        const blob = await apiRequest(`/relatorios/processos/excel${queryParams}`);
        downloadFile(blob, 'processos.xlsx');
    } catch (error) {
        console.error('Erro ao exportar Excel:', error);
        alert('Erro ao exportar Excel: ' + error.message);
    }
}

/**
 * Exporta capacidade para CSV
 */
async function exportarCapacidadeCSV() {
    try {
        const blob = await apiRequest('/relatorios/capacidade/csv');
        downloadFile(blob, 'capacidade.csv');
    } catch (error) {
        console.error('Erro ao exportar CSV:', error);
        alert('Erro ao exportar CSV: ' + error.message);
    }
}

/**
 * Exporta simulações para CSV
 */
async function exportarSimulacoesCSV() {
    try {
        const blob = await apiRequest('/relatorios/simulacoes/csv');
        downloadFile(blob, 'simulacoes.csv');
    } catch (error) {
        console.error('Erro ao exportar CSV:', error);
        alert('Erro ao exportar CSV: ' + error.message);
    }
}

/**
 * Exporta resumo por agência para CSV
 */
async function exportarResumoAgenciaCSV() {
    try {
        const blob = await apiRequest('/relatorios/resumo-agencia/csv');
        downloadFile(blob, 'resumo_agencia.csv');
    } catch (error) {
        console.error('Erro ao exportar CSV:', error);
        alert('Erro ao exportar CSV: ' + error.message);
    }
}

/**
 * Importa dados da API externa
 */
async function importarDados() {
    if (!confirm('Tem certeza que deseja importar dados? Esta operação pode demorar alguns minutos.')) {
        return;
    }
    
    try {
        const reportId = parseInt(document.getElementById('reportId').value);
        const dataInicio = document.getElementById('importDataInicio').value;
        const dataFim = document.getElementById('importDataFim').value;
        
        if (!dataInicio || !dataFim) {
            alert('Por favor, preencha as datas de início e fim');
            return;
        }
        
        const response = await apiRequest('/importacao/importar', {
            method: 'POST',
            body: JSON.stringify({
                report_id: reportId,
                data_inicio: dataInicio,
                data_fim: dataFim,
                situacao: 0
            })
        });
        
        alert(`Importação concluída!\nRegistros importados: ${response.registros_importados}\nErros: ${response.registros_erro}`);
        
        // Recarregar logs
        carregarLogsImportacao();
    } catch (error) {
        console.error('Erro ao importar dados:', error);
        alert('Erro ao importar dados: ' + error.message);
    }
}

/**
 * Carrega os logs de importação
 */
async function carregarLogsImportacao() {
    try {
        const response = await apiRequest('/importacao/logs');
        const logs = response.logs;
        
        const tbody = document.getElementById('tabelaLogs');
        tbody.innerHTML = '';
        
        if (logs.length === 0) {
            tbody.innerHTML = '<tr><td colspan="4" class="text-center">Nenhum log encontrado</td></tr>';
            return;
        }
        
        logs.forEach(log => {
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td>${formatarDataHora(log.data_importacao)}</td>
                <td>${log.registros_importados}</td>
                <td>${log.registros_erro}</td>
                <td><span class="badge bg-${log.status === 'sucesso' ? 'success' : 'danger'}">${log.status}</span></td>
            `;
            tbody.appendChild(tr);
        });
    } catch (error) {
        console.error('Erro ao carregar logs:', error);
    }
}

