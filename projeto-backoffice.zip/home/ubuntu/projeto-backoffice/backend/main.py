"""
Aplicação principal do backend - Sistema de Gestão de Processos Backoffice
"""
from fastapi import FastAPI, Depends, HTTPException, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.trustedhost import TrustedHostMiddleware
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from contextlib import asynccontextmanager
import os
from dotenv import load_dotenv

from rotas import auth, usuarios, processos, dashboard, simulacao, relatorios, importacao
from database import inicializar_banco
from agendador import iniciar_agendador, parar_agendador

load_dotenv()

@asynccontextmanager
async def lifespan(app: FastAPI):
    """Gerencia o ciclo de vida da aplicação"""
    # Inicialização
    await inicializar_banco()
    iniciar_agendador()
    yield
    # Encerramento
    parar_agendador()

app = FastAPI(
    title="Sistema de Gestão de Processos Backoffice",
    description="API para gestão e análise de processos backoffice com IA",
    version="1.0.0",
    lifespan=lifespan
)

# Configurar CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Configurar Trusted Hosts
trusted_hosts = os.getenv("TRUSTED_HOSTS", "localhost,127.0.0.1").split(",")
app.add_middleware(
    TrustedHostMiddleware,
    allowed_hosts=trusted_hosts
)

# Registrar rotas
app.include_router(auth.router, prefix="/api/auth", tags=["Autenticação"])
app.include_router(usuarios.router, prefix="/api/usuarios", tags=["Usuários"])
app.include_router(processos.router, prefix="/api/processos", tags=["Processos"])
app.include_router(dashboard.router, prefix="/api/dashboard", tags=["Dashboard"])
app.include_router(simulacao.router, prefix="/api/simulacao", tags=["Simulação"])
app.include_router(relatorios.router, prefix="/api/relatorios", tags=["Relatórios"])
app.include_router(importacao.router, prefix="/api/importacao", tags=["Importação"])

@app.get("/")
async def raiz():
    """Endpoint raiz da API"""
    return {
        "mensagem": "API do Sistema de Gestão de Processos Backoffice",
        "versao": "1.0.0",
        "status": "operacional"
    }

@app.get("/health")
async def verificar_saude():
    """Endpoint de verificação de saúde da aplicação"""
    return {"status": "saudavel"}

