"""
Módulo de agendamento de tarefas periódicas
"""
import os
from apscheduler.schedulers.asyncio import AsyncIOScheduler
from apscheduler.triggers.cron import CronTrigger
from datetime import datetime, timedelta
from rotas.importacao import importar_dados_api

# Scheduler global
scheduler = AsyncIOScheduler(timezone="America/Sao_Paulo")

async def tarefa_importacao_periodica():
    """
    Tarefa agendada para importação periódica de dados
    """
    print(f"[{datetime.now()}] Executando importação periódica...")
    
    try:
        # Configurações da importação
        report_id = int(os.getenv("AUTO_IMPORT_REPORT_ID", "916"))
        
        # Importar dados dos últimos 7 dias
        data_fim = datetime.now().strftime("%Y-%m-%d")
        data_inicio = (datetime.now() - timedelta(days=7)).strftime("%Y-%m-%d")
        
        resultado = await importar_dados_api(
            report_id=report_id,
            data_inicio=data_inicio,
            data_fim=data_fim,
            situacao=0
        )
        
        print(f"✓ Importação concluída: {resultado['registros_importados']} registros importados, {resultado['registros_erro']} erros")
    
    except Exception as e:
        print(f"✗ Erro na importação periódica: {e}")

def iniciar_agendador():
    """
    Inicia o agendador de tarefas
    """
    # Verificar se a importação automática está habilitada
    auto_import_enabled = os.getenv("AUTO_IMPORT_ENABLED", "false").lower() == "true"
    
    if not auto_import_enabled:
        print("⚠ Importação automática desabilitada")
        return
    
    # Configurar horário da importação (padrão: todos os dias às 2h da manhã)
    import_hour = int(os.getenv("AUTO_IMPORT_HOUR", "2"))
    import_minute = int(os.getenv("AUTO_IMPORT_MINUTE", "0"))
    
    # Adicionar job de importação periódica
    scheduler.add_job(
        tarefa_importacao_periodica,
        trigger=CronTrigger(hour=import_hour, minute=import_minute, timezone="America/Sao_Paulo"),
        id="importacao_periodica",
        name="Importação Periódica de Dados",
        replace_existing=True
    )
    
    # Iniciar scheduler
    scheduler.start()
    print(f"✓ Agendador iniciado - Importação automática configurada para {import_hour:02d}:{import_minute:02d}")

def parar_agendador():
    """
    Para o agendador de tarefas
    """
    if scheduler.running:
        scheduler.shutdown()
        print("✓ Agendador encerrado")

