"""
Rotas de relatórios e exportação de dados
"""
from fastapi import APIRouter, Depends, Response
from typing import Optional
import csv
import io
from openpyxl import Workbook
from database import obter_db
from autenticacao import obter_usuario_atual, UsuarioAtual

router = APIRouter()

@router.get("/processos/csv")
async def exportar_processos_csv(
    unidade_id: Optional[int] = None,
    data_inicio: Optional[str] = None,
    data_fim: Optional[str] = None,
    usuario_atual: UsuarioAtual = Depends(obter_usuario_atual)
):
    """Exporta processos para CSV"""
    async with obter_db() as db:
        # Construir query
        query = """
            SELECT 
                p.protocolo,
                tp.descricao as tipo_processo,
                u.nome as unidade,
                c.nome as colaborador,
                p.data_abertura,
                p.data_conclusao,
                p.tempo_processamento_minutos,
                p.status
            FROM processos p
            LEFT JOIN tipos_processo tp ON p.tipo_processo_id = tp.id
            LEFT JOIN unidades u ON p.unidade_id = u.id
            LEFT JOIN colaboradores c ON p.colaborador_id = c.id
            WHERE 1=1
        """
        params = []
        
        if unidade_id:
            query += " AND p.unidade_id = ?"
            params.append(unidade_id)
        
        if data_inicio:
            query += " AND p.data_abertura >= ?"
            params.append(data_inicio)
        
        if data_fim:
            query += " AND p.data_abertura <= ?"
            params.append(data_fim)
        
        query += " ORDER BY p.data_abertura DESC"
        
        cursor = await db.execute(query, params)
        processos = await cursor.fetchall()
        
        # Criar CSV
        output = io.StringIO()
        writer = csv.writer(output)
        
        # Cabeçalho
        writer.writerow([
            'Protocolo',
            'Tipo de Processo',
            'Unidade',
            'Colaborador',
            'Data Abertura',
            'Data Conclusão',
            'Tempo Processamento (min)',
            'Status'
        ])
        
        # Dados
        for p in processos:
            writer.writerow([
                p['protocolo'],
                p['tipo_processo'] or '',
                p['unidade'] or '',
                p['colaborador'] or '',
                p['data_abertura'],
                p['data_conclusao'] or '',
                p['tempo_processamento_minutos'] or '',
                p['status']
            ])
        
        # Retornar CSV
        return Response(
            content=output.getvalue(),
            media_type="text/csv",
            headers={"Content-Disposition": "attachment; filename=processos.csv"}
        )

@router.get("/processos/excel")
async def exportar_processos_excel(
    unidade_id: Optional[int] = None,
    data_inicio: Optional[str] = None,
    data_fim: Optional[str] = None,
    usuario_atual: UsuarioAtual = Depends(obter_usuario_atual)
):
    """Exporta processos para Excel"""
    async with obter_db() as db:
        # Construir query
        query = """
            SELECT 
                p.protocolo,
                tp.descricao as tipo_processo,
                u.nome as unidade,
                c.nome as colaborador,
                p.data_abertura,
                p.data_conclusao,
                p.tempo_processamento_minutos,
                p.status
            FROM processos p
            LEFT JOIN tipos_processo tp ON p.tipo_processo_id = tp.id
            LEFT JOIN unidades u ON p.unidade_id = u.id
            LEFT JOIN colaboradores c ON p.colaborador_id = c.id
            WHERE 1=1
        """
        params = []
        
        if unidade_id:
            query += " AND p.unidade_id = ?"
            params.append(unidade_id)
        
        if data_inicio:
            query += " AND p.data_abertura >= ?"
            params.append(data_inicio)
        
        if data_fim:
            query += " AND p.data_abertura <= ?"
            params.append(data_fim)
        
        query += " ORDER BY p.data_abertura DESC"
        
        cursor = await db.execute(query, params)
        processos = await cursor.fetchall()
        
        # Criar Excel
        wb = Workbook()
        ws = wb.active
        ws.title = "Processos"
        
        # Cabeçalho
        ws.append([
            'Protocolo',
            'Tipo de Processo',
            'Unidade',
            'Colaborador',
            'Data Abertura',
            'Data Conclusão',
            'Tempo Processamento (min)',
            'Status'
        ])
        
        # Dados
        for p in processos:
            ws.append([
                p['protocolo'],
                p['tipo_processo'] or '',
                p['unidade'] or '',
                p['colaborador'] or '',
                p['data_abertura'],
                p['data_conclusao'] or '',
                p['tempo_processamento_minutos'] or '',
                p['status']
            ])
        
        # Salvar em memória
        output = io.BytesIO()
        wb.save(output)
        output.seek(0)
        
        # Retornar Excel
        return Response(
            content=output.getvalue(),
            media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            headers={"Content-Disposition": "attachment; filename=processos.xlsx"}
        )

@router.get("/capacidade/csv")
async def exportar_capacidade_csv(
    usuario_atual: UsuarioAtual = Depends(obter_usuario_atual)
):
    """Exporta análise de capacidade para CSV"""
    async with obter_db() as db:
        cursor = await db.execute(
            """
            SELECT 
                c.nome as colaborador,
                c.cargo,
                COUNT(p.id) as quantidade_processos,
                AVG(p.tempo_processamento_minutos) as tempo_medio
            FROM colaboradores c
            LEFT JOIN processos p ON c.id = p.colaborador_id
            WHERE c.ativo = 1
            GROUP BY c.nome, c.cargo
            ORDER BY c.cargo, c.nome
            """
        )
        dados = await cursor.fetchall()
        
        # Criar CSV
        output = io.StringIO()
        writer = csv.writer(output)
        
        writer.writerow(['Colaborador', 'Cargo', 'Quantidade Processos', 'Tempo Médio (min)'])
        
        for d in dados:
            writer.writerow([
                d['colaborador'],
                d['cargo'],
                d['quantidade_processos'],
                round(d['tempo_medio'], 2) if d['tempo_medio'] else 0
            ])
        
        return Response(
            content=output.getvalue(),
            media_type="text/csv",
            headers={"Content-Disposition": "attachment; filename=capacidade.csv"}
        )

@router.get("/simulacoes/csv")
async def exportar_simulacoes_csv(
    usuario_atual: UsuarioAtual = Depends(obter_usuario_atual)
):
    """Exporta simulações para CSV"""
    async with obter_db() as db:
        cursor = await db.execute(
            """
            SELECT 
                nome,
                efetivos,
                estagiarios,
                capacidade_mensal_estimada,
                demanda_prevista,
                percentual_atendimento,
                criado_em
            FROM simulacoes
            ORDER BY criado_em DESC
            """
        )
        simulacoes = await cursor.fetchall()
        
        # Criar CSV
        output = io.StringIO()
        writer = csv.writer(output)
        
        writer.writerow([
            'Nome',
            'Efetivos',
            'Estagiários',
            'Capacidade Mensal',
            'Demanda Prevista',
            'Percentual Atendimento (%)',
            'Criado Em'
        ])
        
        for s in simulacoes:
            writer.writerow([
                s['nome'],
                s['efetivos'],
                s['estagiarios'],
                s['capacidade_mensal_estimada'],
                s['demanda_prevista'],
                round(s['percentual_atendimento'], 2),
                s['criado_em']
            ])
        
        return Response(
            content=output.getvalue(),
            media_type="text/csv",
            headers={"Content-Disposition": "attachment; filename=simulacoes.csv"}
        )

@router.get("/resumo-agencia/csv")
async def exportar_resumo_agencia_csv(
    usuario_atual: UsuarioAtual = Depends(obter_usuario_atual)
):
    """Exporta resumo por agência/unidade para CSV"""
    async with obter_db() as db:
        cursor = await db.execute(
            """
            SELECT 
                u.nome as unidade,
                COUNT(p.id) as total_processos,
                SUM(CASE WHEN p.status = 'concluido' THEN 1 ELSE 0 END) as concluidos,
                AVG(p.tempo_processamento_minutos) as tempo_medio
            FROM unidades u
            LEFT JOIN processos p ON u.id = p.unidade_id
            GROUP BY u.nome
            ORDER BY total_processos DESC
            """
        )
        dados = await cursor.fetchall()
        
        # Criar CSV
        output = io.StringIO()
        writer = csv.writer(output)
        
        writer.writerow([
            'Unidade',
            'Total Processos',
            'Concluídos',
            'Tempo Médio (min)',
            'Taxa Conclusão (%)'
        ])
        
        for d in dados:
            taxa_conclusao = (d['concluidos'] / d['total_processos'] * 100) if d['total_processos'] > 0 else 0
            writer.writerow([
                d['unidade'],
                d['total_processos'],
                d['concluidos'],
                round(d['tempo_medio'], 2) if d['tempo_medio'] else 0,
                round(taxa_conclusao, 2)
            ])
        
        return Response(
            content=output.getvalue(),
            media_type="text/csv",
            headers={"Content-Disposition": "attachment; filename=resumo_agencia.csv"}
        )

