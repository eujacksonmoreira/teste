"""
Rotas do dashboard com indicadores e gráficos
"""
from fastapi import APIRouter, Depends, Query
from typing import Optional, List, Dict
from datetime import datetime, timedelta
from database import obter_db
from autenticacao import obter_usuario_atual, UsuarioAtual
from ia_comentarios import gerar_comentario_ia

router = APIRouter()

@router.get("/cards-resumo")
async def obter_cards_resumo(
    usuario_atual: UsuarioAtual = Depends(obter_usuario_atual)
):
    """Obtém cards de resumo para o dashboard"""
    async with obter_db() as db:
        # Total de processos
        cursor = await db.execute("SELECT COUNT(*) as total FROM processos")
        total_processos = (await cursor.fetchone())['total']
        
        # Processos do mês atual
        inicio_mes = datetime.now().replace(day=1, hour=0, minute=0, second=0).isoformat()
        cursor = await db.execute(
            "SELECT COUNT(*) as total FROM processos WHERE data_abertura >= ?",
            (inicio_mes,)
        )
        processos_mes = (await cursor.fetchone())['total']
        
        # Taxa de conclusão (processos concluídos vs total)
        cursor = await db.execute(
            """
            SELECT 
                COUNT(*) as total,
                SUM(CASE WHEN status = 'concluido' THEN 1 ELSE 0 END) as concluidos
            FROM processos
            """
        )
        row = await cursor.fetchone()
        taxa_conclusao = (row['concluidos'] / row['total'] * 100) if row['total'] > 0 else 0
        
        # Tempo médio de processamento
        cursor = await db.execute(
            """
            SELECT AVG(tempo_processamento_minutos) as media
            FROM processos
            WHERE tempo_processamento_minutos IS NOT NULL
            """
        )
        tempo_medio = (await cursor.fetchone())['media'] or 0
        
        return {
            "total_processos": total_processos,
            "processos_mes": processos_mes,
            "taxa_conclusao": round(taxa_conclusao, 2),
            "tempo_medio_processamento": round(tempo_medio, 2)
        }

@router.get("/grafico-volume-mensal")
async def obter_grafico_volume_mensal(
    meses: int = Query(12, ge=1, le=24),
    usuario_atual: UsuarioAtual = Depends(obter_usuario_atual)
):
    """Obtém dados para gráfico de volume mensal de processos"""
    async with obter_db() as db:
        cursor = await db.execute(
            f"""
            SELECT 
                strftime('%Y-%m', data_abertura) as mes,
                COUNT(*) as quantidade
            FROM processos
            WHERE data_abertura >= date('now', '-{meses} months')
            GROUP BY mes
            ORDER BY mes
            """
        )
        dados = [{"mes": row['mes'], "quantidade": row['quantidade']} for row in await cursor.fetchall()]
        
        # Gerar comentário IA
        comentario = await gerar_comentario_ia(
            tipo_grafico="volume_mensal",
            dados=dados,
            contexto=f"Volume mensal de processos nos últimos {meses} meses"
        )
        
        return {
            "dados": dados,
            "comentario_ia": comentario
        }

@router.get("/grafico-por-tipo")
async def obter_grafico_por_tipo(
    usuario_atual: UsuarioAtual = Depends(obter_usuario_atual)
):
    """Obtém dados para gráfico de processos por tipo"""
    async with obter_db() as db:
        cursor = await db.execute(
            """
            SELECT 
                tp.descricao as tipo,
                COUNT(*) as quantidade
            FROM processos p
            JOIN tipos_processo tp ON p.tipo_processo_id = tp.id
            GROUP BY tp.descricao
            ORDER BY quantidade DESC
            """
        )
        dados = [{"tipo": row['tipo'], "quantidade": row['quantidade']} for row in await cursor.fetchall()]
        
        # Gerar comentário IA
        comentario = await gerar_comentario_ia(
            tipo_grafico="por_tipo",
            dados=dados,
            contexto="Distribuição de processos por tipo"
        )
        
        return {
            "dados": dados,
            "comentario_ia": comentario
        }

@router.get("/grafico-por-unidade")
async def obter_grafico_por_unidade(
    usuario_atual: UsuarioAtual = Depends(obter_usuario_atual)
):
    """Obtém dados para gráfico de processos por unidade"""
    async with obter_db() as db:
        cursor = await db.execute(
            """
            SELECT 
                u.nome as unidade,
                COUNT(*) as quantidade
            FROM processos p
            JOIN unidades u ON p.unidade_id = u.id
            GROUP BY u.nome
            ORDER BY quantidade DESC
            LIMIT 10
            """
        )
        dados = [{"unidade": row['unidade'], "quantidade": row['quantidade']} for row in await cursor.fetchall()]
        
        # Gerar comentário IA
        comentario = await gerar_comentario_ia(
            tipo_grafico="por_unidade",
            dados=dados,
            contexto="Top 10 unidades por volume de processos"
        )
        
        return {
            "dados": dados,
            "comentario_ia": comentario
        }

@router.get("/grafico-tempo-medio-colaborador")
async def obter_grafico_tempo_medio_colaborador(
    usuario_atual: UsuarioAtual = Depends(obter_usuario_atual)
):
    """Obtém dados para gráfico de tempo médio por colaborador"""
    async with obter_db() as db:
        cursor = await db.execute(
            """
            SELECT 
                c.nome as colaborador,
                c.cargo,
                AVG(p.tempo_processamento_minutos) as tempo_medio,
                COUNT(*) as quantidade_processos
            FROM processos p
            JOIN colaboradores c ON p.colaborador_id = c.id
            WHERE p.tempo_processamento_minutos IS NOT NULL
            GROUP BY c.nome, c.cargo
            ORDER BY tempo_medio
            LIMIT 15
            """
        )
        dados = [
            {
                "colaborador": row['colaborador'],
                "cargo": row['cargo'],
                "tempo_medio": round(row['tempo_medio'], 2),
                "quantidade_processos": row['quantidade_processos']
            }
            for row in await cursor.fetchall()
        ]
        
        # Gerar comentário IA
        comentario = await gerar_comentario_ia(
            tipo_grafico="tempo_medio_colaborador",
            dados=dados,
            contexto="Tempo médio de processamento por colaborador"
        )
        
        return {
            "dados": dados,
            "comentario_ia": comentario
        }

@router.get("/grafico-capacidade-backoffice")
async def obter_grafico_capacidade_backoffice(
    usuario_atual: UsuarioAtual = Depends(obter_usuario_atual)
):
    """Obtém dados para gráfico de capacidade do backoffice"""
    async with obter_db() as db:
        # Obter configurações de jornada
        cursor = await db.execute(
            "SELECT chave, valor FROM configuracoes WHERE chave LIKE 'jornada_%' OR chave = 'tempo_almoco_minutos'"
        )
        configs = {row['chave']: row['valor'] for row in await cursor.fetchall()}
        
        # Calcular capacidade por cargo
        tempo_almoco = int(configs.get('tempo_almoco_minutos', 60))
        
        # Jornada efetivos (em minutos)
        inicio_efetivo = configs.get('jornada_efetivo_inicio', '08:30').split(':')
        fim_efetivo = configs.get('jornada_efetivo_fim', '17:30').split(':')
        minutos_efetivo = (int(fim_efetivo[0]) * 60 + int(fim_efetivo[1])) - (int(inicio_efetivo[0]) * 60 + int(inicio_efetivo[1])) - tempo_almoco
        
        # Jornada estagiários (em minutos)
        inicio_estagiario = configs.get('jornada_estagiario_inicio', '09:00').split(':')
        fim_estagiario = configs.get('jornada_estagiario_fim', '16:00').split(':')
        minutos_estagiario = (int(fim_estagiario[0]) * 60 + int(fim_estagiario[1])) - (int(inicio_estagiario[0]) * 60 + int(inicio_estagiario[1])) - tempo_almoco
        
        # Contar colaboradores por cargo
        cursor = await db.execute(
            """
            SELECT cargo, COUNT(*) as quantidade
            FROM colaboradores
            WHERE ativo = 1
            GROUP BY cargo
            """
        )
        colaboradores = {row['cargo']: row['quantidade'] for row in await cursor.fetchall()}
        
        # Tempo médio de processamento
        cursor = await db.execute(
            """
            SELECT AVG(tempo_processamento_minutos) as media
            FROM processos
            WHERE tempo_processamento_minutos IS NOT NULL
            """
        )
        tempo_medio_processo = (await cursor.fetchone())['media'] or 30
        
        # Calcular capacidade diária
        efetivos = colaboradores.get('efetivo', 0)
        estagiarios = colaboradores.get('estagiario', 0)
        
        capacidade_efetivos = (efetivos * minutos_efetivo) / tempo_medio_processo
        capacidade_estagiarios = (estagiarios * minutos_estagiario) / tempo_medio_processo
        capacidade_total = capacidade_efetivos + capacidade_estagiarios
        
        dados = {
            "efetivos": {
                "quantidade": efetivos,
                "capacidade_diaria": round(capacidade_efetivos, 2),
                "minutos_disponiveis": minutos_efetivo
            },
            "estagiarios": {
                "quantidade": estagiarios,
                "capacidade_diaria": round(capacidade_estagiarios, 2),
                "minutos_disponiveis": minutos_estagiario
            },
            "total": {
                "capacidade_diaria": round(capacidade_total, 2),
                "capacidade_mensal": round(capacidade_total * 22, 2)  # 22 dias úteis
            }
        }
        
        # Gerar comentário IA
        comentario = await gerar_comentario_ia(
            tipo_grafico="capacidade_backoffice",
            dados=dados,
            contexto="Análise de capacidade do backoffice"
        )
        
        return {
            "dados": dados,
            "comentario_ia": comentario
        }

