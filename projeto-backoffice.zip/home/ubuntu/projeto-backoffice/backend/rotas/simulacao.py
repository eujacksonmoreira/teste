"""
Rotas de simulação de capacidade
"""
from fastapi import APIRouter, Depends
from pydantic import BaseModel
from typing import List
from database import obter_db
from autenticacao import obter_usuario_atual, UsuarioAtual

router = APIRouter()

class SimulacaoRequest(BaseModel):
    """Modelo de requisição de simulação"""
    nome: str
    efetivos: int
    estagiarios: int

class SimulacaoResponse(BaseModel):
    """Modelo de resposta de simulação"""
    id: int
    nome: str
    efetivos: int
    estagiarios: int
    capacidade_mensal_estimada: int
    demanda_prevista: int
    percentual_atendimento: float
    criado_em: str

@router.post("/", response_model=SimulacaoResponse)
async def criar_simulacao(
    dados: SimulacaoRequest,
    usuario_atual: UsuarioAtual = Depends(obter_usuario_atual)
):
    """
    Cria uma nova simulação de capacidade
    """
    async with obter_db() as db:
        # Obter configurações de jornada
        cursor = await db.execute(
            "SELECT chave, valor FROM configuracoes WHERE chave LIKE 'jornada_%' OR chave = 'tempo_almoco_minutos'"
        )
        configs = {row['chave']: row['valor'] for row in await cursor.fetchall()}
        
        # Calcular capacidade
        tempo_almoco = int(configs.get('tempo_almoco_minutos', 60))
        
        # Jornada efetivos (em minutos)
        inicio_efetivo = configs.get('jornada_efetivo_inicio', '08:30').split(':')
        fim_efetivo = configs.get('jornada_efetivo_fim', '17:30').split(':')
        minutos_efetivo = (int(fim_efetivo[0]) * 60 + int(fim_efetivo[1])) - (int(inicio_efetivo[0]) * 60 + int(inicio_efetivo[1])) - tempo_almoco
        
        # Jornada estagiários (em minutos)
        inicio_estagiario = configs.get('jornada_estagiario_inicio', '09:00').split(':')
        fim_estagiario = configs.get('jornada_estagiario_fim', '16:00').split(':')
        minutos_estagiario = (int(fim_estagiario[0]) * 60 + int(fim_estagiario[1])) - (int(inicio_estagiario[0]) * 60 + int(inicio_estagiario[1])) - tempo_almoco
        
        # Tempo médio de processamento
        cursor = await db.execute(
            """
            SELECT AVG(tempo_processamento_minutos) as media
            FROM processos
            WHERE tempo_processamento_minutos IS NOT NULL
            """
        )
        tempo_medio_processo = (await cursor.fetchone())['media'] or 30
        
        # Calcular capacidade diária
        capacidade_efetivos = (dados.efetivos * minutos_efetivo) / tempo_medio_processo
        capacidade_estagiarios = (dados.estagiarios * minutos_estagiario) / tempo_medio_processo
        capacidade_diaria = capacidade_efetivos + capacidade_estagiarios
        capacidade_mensal = int(capacidade_diaria * 22)  # 22 dias úteis
        
        # Estimar demanda prevista (média dos últimos 3 meses)
        cursor = await db.execute(
            """
            SELECT COUNT(*) / 3.0 as media_mensal
            FROM processos
            WHERE data_abertura >= date('now', '-3 months')
            """
        )
        demanda_prevista = int((await cursor.fetchone())['media_mensal'] or 0)
        
        # Calcular percentual de atendimento
        percentual_atendimento = (capacidade_mensal / demanda_prevista * 100) if demanda_prevista > 0 else 100
        
        # Salvar simulação
        cursor = await db.execute(
            """
            INSERT INTO simulacoes 
            (nome, efetivos, estagiarios, capacidade_mensal_estimada, demanda_prevista, percentual_atendimento, usuario_id)
            VALUES (?, ?, ?, ?, ?, ?, ?)
            """,
            (dados.nome, dados.efetivos, dados.estagiarios, capacidade_mensal, demanda_prevista, percentual_atendimento, usuario_atual.id)
        )
        simulacao_id = cursor.lastrowid
        await db.commit()
        
        # Buscar simulação criada
        cursor = await db.execute(
            "SELECT * FROM simulacoes WHERE id = ?",
            (simulacao_id,)
        )
        simulacao = await cursor.fetchone()
        
        return SimulacaoResponse(
            id=simulacao['id'],
            nome=simulacao['nome'],
            efetivos=simulacao['efetivos'],
            estagiarios=simulacao['estagiarios'],
            capacidade_mensal_estimada=simulacao['capacidade_mensal_estimada'],
            demanda_prevista=simulacao['demanda_prevista'],
            percentual_atendimento=round(simulacao['percentual_atendimento'], 2),
            criado_em=simulacao['criado_em']
        )

@router.get("/", response_model=List[SimulacaoResponse])
async def listar_simulacoes(
    usuario_atual: UsuarioAtual = Depends(obter_usuario_atual)
):
    """Lista todas as simulações"""
    async with obter_db() as db:
        cursor = await db.execute(
            """
            SELECT * FROM simulacoes
            ORDER BY criado_em DESC
            LIMIT 50
            """
        )
        simulacoes = await cursor.fetchall()
        
        return [
            SimulacaoResponse(
                id=s['id'],
                nome=s['nome'],
                efetivos=s['efetivos'],
                estagiarios=s['estagiarios'],
                capacidade_mensal_estimada=s['capacidade_mensal_estimada'],
                demanda_prevista=s['demanda_prevista'],
                percentual_atendimento=round(s['percentual_atendimento'], 2),
                criado_em=s['criado_em']
            )
            for s in simulacoes
        ]

@router.get("/configuracoes")
async def obter_configuracoes(
    usuario_atual: UsuarioAtual = Depends(obter_usuario_atual)
):
    """Obtém as configurações de jornada"""
    async with obter_db() as db:
        cursor = await db.execute(
            "SELECT chave, valor, descricao FROM configuracoes WHERE chave LIKE 'jornada_%' OR chave LIKE '%_simulacao' OR chave = 'tempo_almoco_minutos'"
        )
        configs = [
            {"chave": row['chave'], "valor": row['valor'], "descricao": row['descricao']}
            for row in await cursor.fetchall()
        ]
        
        return {"configuracoes": configs}

@router.put("/configuracoes/{chave}")
async def atualizar_configuracao(
    chave: str,
    valor: str,
    usuario_atual: UsuarioAtual = Depends(obter_usuario_atual)
):
    """Atualiza uma configuração"""
    async with obter_db() as db:
        await db.execute(
            "UPDATE configuracoes SET valor = ?, atualizado_em = CURRENT_TIMESTAMP WHERE chave = ?",
            (valor, chave)
        )
        await db.commit()
        
        return {"mensagem": "Configuração atualizada com sucesso"}

