"""
Rotas de importação de dados da API externa
"""
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from typing import Optional, List
from datetime import datetime
import httpx
import os
import re
from database import obter_db
from autenticacao import obter_usuario_atual, UsuarioAtual, requer_admin

router = APIRouter()

# Configurações da API externa
API_URL = os.getenv("API_URL", "https://3021.fluid.sicredi.io/pato/process/api/v2/process/reports")
API_TOKEN = os.getenv("API_TOKEN", "")

class ImportacaoRequest(BaseModel):
    """Modelo de requisição de importação"""
    report_id: int
    data_inicio: str  # formato: YYYY-MM-DD
    data_fim: str  # formato: YYYY-MM-DD
    situacao: int = 0

def limpar_html(texto: str) -> str:
    """Remove tags HTML de um texto"""
    if not texto:
        return ""
    # Remove tags HTML
    texto_limpo = re.sub(r'<[^>]+>', '', texto)
    # Remove espaços extras
    texto_limpo = ' '.join(texto_limpo.split())
    return texto_limpo

def parsear_data(data_str: str) -> Optional[str]:
    """
    Converte data do formato dd/mm/yyyy HH:MM:SS para ISO format
    """
    if not data_str:
        return None
    
    try:
        # Formato esperado: dd/mm/yyyy HH:MM:SS
        dt = datetime.strptime(data_str, "%d/%m/%Y %H:%M:%S")
        return dt.isoformat()
    except ValueError:
        try:
            # Tentar formato alternativo: dd/mm/yyyy
            dt = datetime.strptime(data_str, "%d/%m/%Y")
            return dt.isoformat()
        except ValueError:
            return None

async def importar_dados_api(
    report_id: int,
    data_inicio: str,
    data_fim: str,
    situacao: int = 0
) -> dict:
    """
    Importa dados da API externa
    
    Args:
        report_id: ID do relatório
        data_inicio: Data de início (YYYY-MM-DD)
        data_fim: Data de fim (YYYY-MM-DD)
        situacao: Situação do processo (0 = todos)
    
    Returns:
        Dicionário com estatísticas da importação
    """
    if not API_TOKEN:
        raise HTTPException(
            status_code=500,
            detail="Token da API não configurado"
        )
    
    registros_importados = 0
    registros_erro = 0
    
    async with obter_db() as db:
        # Fazer requisição à API
        url = f"{API_URL}/{report_id}/period/{data_inicio}/{data_fim}"
        params = {"page": 1, "situation": situacao}
        headers = {
            "accept": "application/json",
            "Authorization": f"token {API_TOKEN}"
        }
        
        try:
            async with httpx.AsyncClient(timeout=60.0) as client:
                response = await client.get(url, params=params, headers=headers)
                
                if response.status_code != 200:
                    raise HTTPException(
                        status_code=response.status_code,
                        detail=f"Erro na API externa: {response.text}"
                    )
                
                dados = response.json()
                
                # Processar dados (estrutura pode variar, ajustar conforme necessário)
                processos = dados.get('data', []) if isinstance(dados, dict) else dados
                
                for processo_data in processos:
                    try:
                        # Extrair dados do processo
                        protocolo = processo_data.get('protocolo') or processo_data.get('protocol')
                        tipo_codigo = processo_data.get('tipo_codigo') or processo_data.get('type_code')
                        tipo_descricao = processo_data.get('tipo_descricao') or processo_data.get('type_description')
                        unidade_codigo = processo_data.get('unidade_codigo') or processo_data.get('unit_code')
                        unidade_nome = processo_data.get('unidade_nome') or processo_data.get('unit_name')
                        colaborador_nome = processo_data.get('colaborador') or processo_data.get('employee')
                        data_abertura_str = processo_data.get('data_abertura') or processo_data.get('open_date')
                        data_conclusao_str = processo_data.get('data_conclusao') or processo_data.get('close_date')
                        status = processo_data.get('status') or 'aberto'
                        observacao = processo_data.get('observacao') or processo_data.get('observation', '')
                        
                        # Validar dados obrigatórios
                        if not protocolo or not data_abertura_str:
                            registros_erro += 1
                            continue
                        
                        # Parsear datas
                        data_abertura = parsear_data(data_abertura_str)
                        data_conclusao = parsear_data(data_conclusao_str) if data_conclusao_str else None
                        
                        if not data_abertura:
                            registros_erro += 1
                            continue
                        
                        # Limpar observação HTML
                        observacao_limpa = limpar_html(observacao)
                        
                        # Calcular tempo de processamento
                        tempo_processamento = None
                        if data_conclusao:
                            dt_abertura = datetime.fromisoformat(data_abertura)
                            dt_conclusao = datetime.fromisoformat(data_conclusao)
                            tempo_processamento = int((dt_conclusao - dt_abertura).total_seconds() / 60)
                        
                        # Inserir ou atualizar tipo de processo
                        tipo_processo_id = None
                        if tipo_codigo and tipo_descricao:
                            cursor = await db.execute(
                                "SELECT id FROM tipos_processo WHERE codigo = ?",
                                (tipo_codigo,)
                            )
                            tipo = await cursor.fetchone()
                            
                            if tipo:
                                tipo_processo_id = tipo['id']
                            else:
                                cursor = await db.execute(
                                    "INSERT INTO tipos_processo (codigo, descricao) VALUES (?, ?)",
                                    (tipo_codigo, tipo_descricao)
                                )
                                tipo_processo_id = cursor.lastrowid
                        
                        # Inserir ou atualizar unidade
                        unidade_id = None
                        if unidade_codigo and unidade_nome:
                            cursor = await db.execute(
                                "SELECT id FROM unidades WHERE codigo = ?",
                                (unidade_codigo,)
                            )
                            unidade = await cursor.fetchone()
                            
                            if unidade:
                                unidade_id = unidade['id']
                            else:
                                cursor = await db.execute(
                                    "INSERT INTO unidades (codigo, nome) VALUES (?, ?)",
                                    (unidade_codigo, unidade_nome)
                                )
                                unidade_id = cursor.lastrowid
                        
                        # Inserir ou atualizar colaborador
                        colaborador_id = None
                        if colaborador_nome:
                            cursor = await db.execute(
                                "SELECT id FROM colaboradores WHERE nome = ?",
                                (colaborador_nome,)
                            )
                            colaborador = await cursor.fetchone()
                            
                            if colaborador:
                                colaborador_id = colaborador['id']
                            else:
                                # Assumir cargo 'efetivo' por padrão
                                cursor = await db.execute(
                                    "INSERT INTO colaboradores (nome, cargo, unidade_id) VALUES (?, ?, ?)",
                                    (colaborador_nome, 'efetivo', unidade_id)
                                )
                                colaborador_id = cursor.lastrowid
                        
                        # Inserir ou atualizar processo
                        cursor = await db.execute(
                            "SELECT id FROM processos WHERE protocolo = ?",
                            (protocolo,)
                        )
                        processo_existente = await cursor.fetchone()
                        
                        if processo_existente:
                            # Atualizar
                            await db.execute(
                                """
                                UPDATE processos
                                SET tipo_processo_id = ?, unidade_id = ?, colaborador_id = ?,
                                    data_abertura = ?, data_conclusao = ?, tempo_processamento_minutos = ?,
                                    status = ?, observacao = ?
                                WHERE protocolo = ?
                                """,
                                (tipo_processo_id, unidade_id, colaborador_id, data_abertura,
                                 data_conclusao, tempo_processamento, status, observacao_limpa, protocolo)
                            )
                        else:
                            # Inserir
                            await db.execute(
                                """
                                INSERT INTO processos
                                (protocolo, tipo_processo_id, unidade_id, colaborador_id, data_abertura,
                                 data_conclusao, tempo_processamento_minutos, status, observacao)
                                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                                """,
                                (protocolo, tipo_processo_id, unidade_id, colaborador_id, data_abertura,
                                 data_conclusao, tempo_processamento, status, observacao_limpa)
                            )
                        
                        registros_importados += 1
                    
                    except Exception as e:
                        print(f"Erro ao processar registro: {e}")
                        registros_erro += 1
                        continue
                
                await db.commit()
        
        except Exception as e:
            print(f"Erro na importação: {e}")
            raise HTTPException(
                status_code=500,
                detail=f"Erro ao importar dados: {str(e)}"
            )
        
        # Registrar log de importação
        await db.execute(
            """
            INSERT INTO logs_importacao
            (registros_importados, registros_erro, status, mensagem)
            VALUES (?, ?, ?, ?)
            """,
            (registros_importados, registros_erro, 'sucesso', f'Importação concluída')
        )
        await db.commit()
    
    return {
        "registros_importados": registros_importados,
        "registros_erro": registros_erro
    }

@router.post("/importar")
async def importar_dados(
    dados: ImportacaoRequest,
    usuario_atual: UsuarioAtual = Depends(requer_admin)
):
    """
    Importa dados da API externa (apenas administradores)
    """
    resultado = await importar_dados_api(
        report_id=dados.report_id,
        data_inicio=dados.data_inicio,
        data_fim=dados.data_fim,
        situacao=dados.situacao
    )
    
    return {
        "mensagem": "Importação concluída",
        **resultado
    }

@router.get("/logs")
async def listar_logs_importacao(
    usuario_atual: UsuarioAtual = Depends(obter_usuario_atual)
):
    """Lista os logs de importação"""
    async with obter_db() as db:
        cursor = await db.execute(
            """
            SELECT * FROM logs_importacao
            ORDER BY data_importacao DESC
            LIMIT 50
            """
        )
        logs = await cursor.fetchall()
        
        return {
            "logs": [
                {
                    "id": log['id'],
                    "data_importacao": log['data_importacao'],
                    "registros_importados": log['registros_importados'],
                    "registros_erro": log['registros_erro'],
                    "status": log['status'],
                    "mensagem": log['mensagem']
                }
                for log in logs
            ]
        }

