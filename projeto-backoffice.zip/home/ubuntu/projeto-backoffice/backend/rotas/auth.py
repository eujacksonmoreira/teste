"""
Rotas de autenticação - Login e Logout
"""
from fastapi import APIRouter, HTTPException, status, Depends
from pydantic import BaseModel, EmailStr
from datetime import timedelta
from database import obter_db
from autenticacao import (
    verificar_senha,
    criar_token_acesso,
    ACCESS_TOKEN_EXPIRE_MINUTES
)

router = APIRouter()

class LoginRequest(BaseModel):
    """Modelo de requisição de login"""
    email: EmailStr
    senha: str

class LoginResponse(BaseModel):
    """Modelo de resposta de login"""
    token: str
    tipo: str
    usuario: dict

@router.post("/login", response_model=LoginResponse)
async def fazer_login(dados: LoginRequest):
    """
    Endpoint de login - autentica o usuário e retorna um token JWT
    """
    async with obter_db() as db:
        # Buscar usuário por email
        cursor = await db.execute(
            "SELECT id, nome, email, senha_hash, perfil, ativo FROM usuarios WHERE email = ?",
            (dados.email,)
        )
        usuario = await cursor.fetchone()
        
        if not usuario:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Email ou senha incorretos"
            )
        
        # Verificar se o usuário está ativo
        if not usuario['ativo']:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Usuário inativo. Entre em contato com o administrador."
            )
        
        # Verificar senha
        if not verificar_senha(dados.senha, usuario['senha_hash']):
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Email ou senha incorretos"
            )
        
        # Criar token de acesso
        token_data = {
            "sub": usuario['email'],
            "id": usuario['id'],
            "nome": usuario['nome'],
            "perfil": usuario['perfil']
        }
        token = criar_token_acesso(
            data=token_data,
            expires_delta=timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
        )
        
        return LoginResponse(
            token=token,
            tipo="bearer",
            usuario={
                "id": usuario['id'],
                "nome": usuario['nome'],
                "email": usuario['email'],
                "perfil": usuario['perfil']
            }
        )

@router.post("/logout")
async def fazer_logout():
    """
    Endpoint de logout - no caso de JWT, o logout é feito no cliente
    removendo o token armazenado
    """
    return {"mensagem": "Logout realizado com sucesso"}

