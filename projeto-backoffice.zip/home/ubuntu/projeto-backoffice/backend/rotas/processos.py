"""
Rotas de gerenciamento de processos
"""
from fastapi import APIRouter, HTTPException, status, Depends, Query
from pydantic import BaseModel
from typing import List, Optional
from datetime import datetime
from database import obter_db
from autenticacao import obter_usuario_atual, UsuarioAtual

router = APIRouter()

class ProcessoResponse(BaseModel):
    """Modelo de resposta de processo"""
    id: int
    protocolo: str
    tipo_processo: Optional[str]
    unidade: Optional[str]
    colaborador: Optional[str]
    data_abertura: str
    data_conclusao: Optional[str]
    tempo_processamento_minutos: Optional[int]
    status: str
    observacao: Optional[str]

@router.get("/", response_model=List[ProcessoResponse])
async def listar_processos(
    unidade_id: Optional[int] = None,
    tipo_processo_id: Optional[int] = None,
    colaborador_id: Optional[int] = None,
    data_inicio: Optional[str] = None,
    data_fim: Optional[str] = None,
    status: Optional[str] = None,
    limite: int = Query(100, le=1000),
    offset: int = Query(0, ge=0),
    usuario_atual: UsuarioAtual = Depends(obter_usuario_atual)
):
    """
    Lista processos com filtros opcionais
    """
    async with obter_db() as db:
        # Construir query dinâmica
        query = """
            SELECT 
                p.id,
                p.protocolo,
                tp.descricao as tipo_processo,
                u.nome as unidade,
                c.nome as colaborador,
                p.data_abertura,
                p.data_conclusao,
                p.tempo_processamento_minutos,
                p.status,
                p.observacao
            FROM processos p
            LEFT JOIN tipos_processo tp ON p.tipo_processo_id = tp.id
            LEFT JOIN unidades u ON p.unidade_id = u.id
            LEFT JOIN colaboradores c ON p.colaborador_id = c.id
            WHERE 1=1
        """
        params = []
        
        if unidade_id:
            query += " AND p.unidade_id = ?"
            params.append(unidade_id)
        
        if tipo_processo_id:
            query += " AND p.tipo_processo_id = ?"
            params.append(tipo_processo_id)
        
        if colaborador_id:
            query += " AND p.colaborador_id = ?"
            params.append(colaborador_id)
        
        if data_inicio:
            query += " AND p.data_abertura >= ?"
            params.append(data_inicio)
        
        if data_fim:
            query += " AND p.data_abertura <= ?"
            params.append(data_fim)
        
        if status:
            query += " AND p.status = ?"
            params.append(status)
        
        query += " ORDER BY p.data_abertura DESC LIMIT ? OFFSET ?"
        params.extend([limite, offset])
        
        cursor = await db.execute(query, params)
        processos = await cursor.fetchall()
        
        return [
            ProcessoResponse(
                id=p['id'],
                protocolo=p['protocolo'],
                tipo_processo=p['tipo_processo'],
                unidade=p['unidade'],
                colaborador=p['colaborador'],
                data_abertura=p['data_abertura'],
                data_conclusao=p['data_conclusao'],
                tempo_processamento_minutos=p['tempo_processamento_minutos'],
                status=p['status'],
                observacao=p['observacao']
            )
            for p in processos
        ]

@router.get("/{processo_id}", response_model=ProcessoResponse)
async def obter_processo(
    processo_id: int,
    usuario_atual: UsuarioAtual = Depends(obter_usuario_atual)
):
    """Obtém detalhes de um processo específico"""
    async with obter_db() as db:
        cursor = await db.execute(
            """
            SELECT 
                p.id,
                p.protocolo,
                tp.descricao as tipo_processo,
                u.nome as unidade,
                c.nome as colaborador,
                p.data_abertura,
                p.data_conclusao,
                p.tempo_processamento_minutos,
                p.status,
                p.observacao
            FROM processos p
            LEFT JOIN tipos_processo tp ON p.tipo_processo_id = tp.id
            LEFT JOIN unidades u ON p.unidade_id = u.id
            LEFT JOIN colaboradores c ON p.colaborador_id = c.id
            WHERE p.id = ?
            """,
            (processo_id,)
        )
        processo = await cursor.fetchone()
        
        if not processo:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Processo não encontrado"
            )
        
        return ProcessoResponse(
            id=processo['id'],
            protocolo=processo['protocolo'],
            tipo_processo=processo['tipo_processo'],
            unidade=processo['unidade'],
            colaborador=processo['colaborador'],
            data_abertura=processo['data_abertura'],
            data_conclusao=processo['data_conclusao'],
            tempo_processamento_minutos=processo['tempo_processamento_minutos'],
            status=processo['status'],
            observacao=processo['observacao']
        )

@router.get("/estatisticas/resumo")
async def obter_estatisticas_resumo(
    usuario_atual: UsuarioAtual = Depends(obter_usuario_atual)
):
    """Obtém estatísticas resumidas dos processos"""
    async with obter_db() as db:
        # Total de processos
        cursor = await db.execute("SELECT COUNT(*) as total FROM processos")
        total = (await cursor.fetchone())['total']
        
        # Processos por status
        cursor = await db.execute(
            """
            SELECT status, COUNT(*) as quantidade
            FROM processos
            GROUP BY status
            """
        )
        por_status = {row['status']: row['quantidade'] for row in await cursor.fetchall()}
        
        # Tempo médio de processamento
        cursor = await db.execute(
            """
            SELECT AVG(tempo_processamento_minutos) as media
            FROM processos
            WHERE tempo_processamento_minutos IS NOT NULL
            """
        )
        tempo_medio = (await cursor.fetchone())['media'] or 0
        
        # Processos por unidade (top 5)
        cursor = await db.execute(
            """
            SELECT u.nome, COUNT(*) as quantidade
            FROM processos p
            JOIN unidades u ON p.unidade_id = u.id
            GROUP BY u.nome
            ORDER BY quantidade DESC
            LIMIT 5
            """
        )
        por_unidade = [
            {"unidade": row['nome'], "quantidade": row['quantidade']}
            for row in await cursor.fetchall()
        ]
        
        return {
            "total_processos": total,
            "por_status": por_status,
            "tempo_medio_processamento_minutos": round(tempo_medio, 2),
            "top_unidades": por_unidade
        }

