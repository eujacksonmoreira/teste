"""
Rotas de gerenciamento de usuários
"""
from fastapi import APIRouter, HTTPException, status, Depends
from pydantic import BaseModel, EmailStr
from typing import List, Optional
from datetime import datetime, timedelta
import secrets
from database import obter_db
from autenticacao import (
    criar_hash_senha,
    obter_usuario_atual,
    requer_admin,
    UsuarioAtual
)
from email_service import enviar_email_convite

router = APIRouter()

class CriarUsuarioRequest(BaseModel):
    """Modelo de requisição para criar usuário"""
    nome: str
    email: EmailStr
    perfil: str  # 'administrador' ou 'comum'

class DefinirSenhaRequest(BaseModel):
    """Modelo de requisição para definir senha"""
    token: str
    senha: str

class UsuarioResponse(BaseModel):
    """Modelo de resposta de usuário"""
    id: int
    nome: str
    email: str
    perfil: str
    ativo: bool
    criado_em: str

@router.get("/me", response_model=UsuarioResponse)
async def obter_meu_perfil(usuario_atual: UsuarioAtual = Depends(obter_usuario_atual)):
    """Obtém o perfil do usuário autenticado"""
    async with obter_db() as db:
        cursor = await db.execute(
            "SELECT id, nome, email, perfil, ativo, criado_em FROM usuarios WHERE id = ?",
            (usuario_atual.id,)
        )
        usuario = await cursor.fetchone()
        
        if not usuario:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Usuário não encontrado"
            )
        
        return UsuarioResponse(
            id=usuario['id'],
            nome=usuario['nome'],
            email=usuario['email'],
            perfil=usuario['perfil'],
            ativo=usuario['ativo'],
            criado_em=usuario['criado_em']
        )

@router.get("/", response_model=List[UsuarioResponse])
async def listar_usuarios(
    usuario_atual: UsuarioAtual = Depends(requer_admin)
):
    """Lista todos os usuários (apenas administradores)"""
    async with obter_db() as db:
        cursor = await db.execute(
            "SELECT id, nome, email, perfil, ativo, criado_em FROM usuarios ORDER BY nome"
        )
        usuarios = await cursor.fetchall()
        
        return [
            UsuarioResponse(
                id=u['id'],
                nome=u['nome'],
                email=u['email'],
                perfil=u['perfil'],
                ativo=u['ativo'],
                criado_em=u['criado_em']
            )
            for u in usuarios
        ]

@router.post("/", status_code=status.HTTP_201_CREATED)
async def criar_usuario(
    dados: CriarUsuarioRequest,
    usuario_atual: UsuarioAtual = Depends(requer_admin)
):
    """
    Cria um novo usuário e envia email de convite (apenas administradores)
    """
    # Validar perfil
    if dados.perfil not in ['administrador', 'comum']:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Perfil inválido. Use 'administrador' ou 'comum'."
        )
    
    async with obter_db() as db:
        # Verificar se o email já existe
        cursor = await db.execute(
            "SELECT id FROM usuarios WHERE email = ?",
            (dados.email,)
        )
        if await cursor.fetchone():
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Email já cadastrado"
            )
        
        # Criar usuário com senha temporária
        senha_temporaria = secrets.token_urlsafe(16)
        senha_hash = criar_hash_senha(senha_temporaria)
        
        cursor = await db.execute(
            """
            INSERT INTO usuarios (nome, email, senha_hash, perfil, ativo)
            VALUES (?, ?, ?, ?, 0)
            """,
            (dados.nome, dados.email, senha_hash, dados.perfil)
        )
        usuario_id = cursor.lastrowid
        
        # Criar token de convite
        token = secrets.token_urlsafe(32)
        expira_em = datetime.utcnow() + timedelta(days=7)
        
        await db.execute(
            """
            INSERT INTO tokens_convite (usuario_id, token, expira_em)
            VALUES (?, ?, ?)
            """,
            (usuario_id, token, expira_em.isoformat())
        )
        
        await db.commit()
        
        # Enviar email de convite
        try:
            await enviar_email_convite(dados.email, dados.nome, token)
        except Exception as e:
            print(f"Erro ao enviar email: {e}")
            # Não falha a criação do usuário se o email falhar
        
        return {
            "mensagem": "Usuário criado com sucesso",
            "usuario_id": usuario_id,
            "token_convite": token  # Em produção, não retornar o token aqui
        }

@router.post("/definir-senha")
async def definir_senha(dados: DefinirSenhaRequest):
    """
    Define a senha do usuário usando o token de convite
    """
    async with obter_db() as db:
        # Verificar token
        cursor = await db.execute(
            """
            SELECT id, usuario_id, expira_em, usado
            FROM tokens_convite
            WHERE token = ?
            """,
            (dados.token,)
        )
        token_info = await cursor.fetchone()
        
        if not token_info:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Token inválido"
            )
        
        if token_info['usado']:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Token já utilizado"
            )
        
        # Verificar expiração
        expira_em = datetime.fromisoformat(token_info['expira_em'])
        if datetime.utcnow() > expira_em:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Token expirado"
            )
        
        # Atualizar senha do usuário
        senha_hash = criar_hash_senha(dados.senha)
        await db.execute(
            "UPDATE usuarios SET senha_hash = ?, ativo = 1 WHERE id = ?",
            (senha_hash, token_info['usuario_id'])
        )
        
        # Marcar token como usado
        await db.execute(
            "UPDATE tokens_convite SET usado = 1 WHERE id = ?",
            (token_info['id'],)
        )
        
        await db.commit()
        
        return {"mensagem": "Senha definida com sucesso"}

@router.delete("/{usuario_id}")
async def desativar_usuario(
    usuario_id: int,
    usuario_atual: UsuarioAtual = Depends(requer_admin)
):
    """Desativa um usuário (apenas administradores)"""
    async with obter_db() as db:
        cursor = await db.execute(
            "SELECT id FROM usuarios WHERE id = ?",
            (usuario_id,)
        )
        if not await cursor.fetchone():
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Usuário não encontrado"
            )
        
        await db.execute(
            "UPDATE usuarios SET ativo = 0 WHERE id = ?",
            (usuario_id,)
        )
        await db.commit()
        
        return {"mensagem": "Usuário desativado com sucesso"}

