"""
Módulo de configuração e gerenciamento do banco de dados
"""
import os
import aiosqlite
from typing import Optional
from contextlib import asynccontextmanager

# Caminho do banco de dados SQLite
DB_PATH = os.getenv("DATABASE_PATH", "/app/data/backoffice.db")

# Pool de conexões (simulado com uma conexão global para SQLite)
_conexao_global: Optional[aiosqlite.Connection] = None

async def obter_conexao() -> aiosqlite.Connection:
    """Obtém uma conexão com o banco de dados"""
    global _conexao_global
    if _conexao_global is None:
        _conexao_global = await aiosqlite.connect(DB_PATH)
        _conexao_global.row_factory = aiosqlite.Row
    return _conexao_global

@asynccontextmanager
async def obter_db():
    """Context manager para obter conexão com o banco de dados"""
    conn = await obter_conexao()
    try:
        yield conn
    finally:
        pass  # Não fechamos a conexão global aqui

async def inicializar_banco():
    """Inicializa o banco de dados criando as tabelas necessárias"""
    conn = await obter_conexao()
    
    # Criar tabela de usuários
    await conn.execute("""
        CREATE TABLE IF NOT EXISTS usuarios (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nome TEXT NOT NULL,
            email TEXT UNIQUE NOT NULL,
            senha_hash TEXT NOT NULL,
            perfil TEXT NOT NULL CHECK(perfil IN ('administrador', 'comum')),
            ativo BOOLEAN DEFAULT 1,
            criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            atualizado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)
    
    # Criar tabela de tokens de convite
    await conn.execute("""
        CREATE TABLE IF NOT EXISTS tokens_convite (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            usuario_id INTEGER NOT NULL,
            token TEXT UNIQUE NOT NULL,
            expira_em TIMESTAMP NOT NULL,
            usado BOOLEAN DEFAULT 0,
            criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
        )
    """)
    
    # Criar tabela de unidades
    await conn.execute("""
        CREATE TABLE IF NOT EXISTS unidades (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            codigo TEXT UNIQUE NOT NULL,
            nome TEXT NOT NULL,
            ativo BOOLEAN DEFAULT 1
        )
    """)
    
    # Criar tabela de colaboradores
    await conn.execute("""
        CREATE TABLE IF NOT EXISTS colaboradores (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nome TEXT NOT NULL,
            cargo TEXT NOT NULL CHECK(cargo IN ('estagiario', 'efetivo')),
            unidade_id INTEGER,
            ativo BOOLEAN DEFAULT 1,
            FOREIGN KEY (unidade_id) REFERENCES unidades(id)
        )
    """)
    
    # Criar tabela de tipos de processo
    await conn.execute("""
        CREATE TABLE IF NOT EXISTS tipos_processo (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            codigo TEXT UNIQUE NOT NULL,
            descricao TEXT NOT NULL,
            ativo BOOLEAN DEFAULT 1
        )
    """)
    
    # Criar tabela de processos
    await conn.execute("""
        CREATE TABLE IF NOT EXISTS processos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            protocolo TEXT UNIQUE NOT NULL,
            tipo_processo_id INTEGER,
            unidade_id INTEGER,
            colaborador_id INTEGER,
            data_abertura TIMESTAMP NOT NULL,
            data_conclusao TIMESTAMP,
            tempo_processamento_minutos INTEGER,
            status TEXT NOT NULL,
            observacao TEXT,
            criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (tipo_processo_id) REFERENCES tipos_processo(id),
            FOREIGN KEY (unidade_id) REFERENCES unidades(id),
            FOREIGN KEY (colaborador_id) REFERENCES colaboradores(id)
        )
    """)
    
    # Criar índices para melhor performance
    await conn.execute("CREATE INDEX IF NOT EXISTS idx_processos_data_abertura ON processos(data_abertura)")
    await conn.execute("CREATE INDEX IF NOT EXISTS idx_processos_unidade ON processos(unidade_id)")
    await conn.execute("CREATE INDEX IF NOT EXISTS idx_processos_tipo ON processos(tipo_processo_id)")
    await conn.execute("CREATE INDEX IF NOT EXISTS idx_processos_colaborador ON processos(colaborador_id)")
    
    # Criar tabela de logs de importação
    await conn.execute("""
        CREATE TABLE IF NOT EXISTS logs_importacao (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            data_importacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            registros_importados INTEGER,
            registros_erro INTEGER,
            status TEXT NOT NULL,
            mensagem TEXT
        )
    """)
    
    # Criar tabela de configurações
    await conn.execute("""
        CREATE TABLE IF NOT EXISTS configuracoes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            chave TEXT UNIQUE NOT NULL,
            valor TEXT NOT NULL,
            descricao TEXT,
            atualizado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)
    
    # Inserir configurações padrão
    await conn.execute("""
        INSERT OR IGNORE INTO configuracoes (chave, valor, descricao)
        VALUES 
            ('jornada_efetivo_inicio', '08:30', 'Horário de início da jornada de efetivos'),
            ('jornada_efetivo_fim', '17:30', 'Horário de fim da jornada de efetivos'),
            ('jornada_estagiario_inicio', '09:00', 'Horário de início da jornada de estagiários'),
            ('jornada_estagiario_fim', '16:00', 'Horário de fim da jornada de estagiários'),
            ('tempo_almoco_minutos', '60', 'Tempo de almoço em minutos'),
            ('efetivos_simulacao', '5', 'Quantidade de efetivos para simulação'),
            ('estagiarios_simulacao', '3', 'Quantidade de estagiários para simulação')
    """)
    
    # Criar tabela de simulações
    await conn.execute("""
        CREATE TABLE IF NOT EXISTS simulacoes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nome TEXT NOT NULL,
            efetivos INTEGER NOT NULL,
            estagiarios INTEGER NOT NULL,
            capacidade_mensal_estimada INTEGER,
            demanda_prevista INTEGER,
            percentual_atendimento REAL,
            criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            usuario_id INTEGER,
            FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
        )
    """)
    
    await conn.commit()
    print("✓ Banco de dados inicializado com sucesso")

async def fechar_conexao():
    """Fecha a conexão global com o banco de dados"""
    global _conexao_global
    if _conexao_global:
        await _conexao_global.close()
        _conexao_global = None

