"""
Módulo de integração com ChatGPT para geração de comentários em gráficos
"""
import os
import httpx
from typing import Dict, Any

OPENAI_API_KEY = os.getenv("OPENAI_API_KEY") or os.getenv("CHATGPT_API_KEY")
DISABLE_GPT_COMMENTS = os.getenv("DISABLE_GPT_COMMENTS", "false").lower() == "true"
OPENAI_API_URL = "https://api.openai.com/v1/chat/completions"
OPENAI_MODEL = os.getenv("OPENAI_MODEL", "gpt-4")

async def gerar_comentario_ia(
    tipo_grafico: str,
    dados: Any,
    contexto: str
) -> str:
    """
    Gera um comentário analítico usando ChatGPT
    
    Args:
        tipo_grafico: Tipo do gráfico (ex: volume_mensal, por_tipo, etc)
        dados: Dados do gráfico
        contexto: Contexto adicional para a análise
    
    Returns:
        Comentário gerado pela IA
    """
    if DISABLE_GPT_COMMENTS:
        return "Comentários de IA desabilitados."
    
    if not OPENAI_API_KEY:
        return "API Key do ChatGPT não configurada."
    
    # Construir prompt em português
    prompt = f"""
Você é um analista de dados especializado em processos de backoffice.

Analise os seguintes dados e forneça um comentário breve e objetivo (máximo 3 frases):

Tipo de análise: {contexto}
Dados: {dados}

Forneça insights relevantes, identifique padrões, tendências ou pontos de atenção.
Seja direto e use linguagem profissional em português do Brasil.
"""
    
    try:
        async with httpx.AsyncClient(timeout=30.0) as client:
            response = await client.post(
                OPENAI_API_URL,
                headers={
                    "Authorization": f"Bearer {OPENAI_API_KEY}",
                    "Content-Type": "application/json"
                },
                json={
                    "model": OPENAI_MODEL,
                    "messages": [
                        {
                            "role": "system",
                            "content": "Você é um analista de dados especializado em processos de backoffice. Forneça análises objetivas e profissionais em português do Brasil."
                        },
                        {
                            "role": "user",
                            "content": prompt
                        }
                    ],
                    "temperature": 0.7,
                    "max_tokens": 200
                }
            )
            
            if response.status_code == 200:
                resultado = response.json()
                comentario = resultado['choices'][0]['message']['content'].strip()
                return comentario
            else:
                print(f"Erro na API do ChatGPT: {response.status_code} - {response.text}")
                return "Não foi possível gerar comentário no momento."
    
    except Exception as e:
        print(f"Erro ao gerar comentário IA: {e}")
        return "Erro ao gerar comentário."

