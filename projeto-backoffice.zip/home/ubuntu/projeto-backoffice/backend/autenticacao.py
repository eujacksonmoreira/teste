"""
Módulo de autenticação e autorização com JWT
"""
from datetime import datetime, timedelta
from typing import Optional
from jose import JWTError, jwt
from passlib.context import CryptContext
from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
import os
from pydantic import BaseModel

# Configurações JWT
SECRET_KEY = os.getenv("SECRET_KEY", "chave-secreta-super-segura-mude-em-producao")
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = int(os.getenv("ACCESS_TOKEN_EXPIRE_MINUTES", "480"))  # 8 horas

# Contexto de criptografia de senha
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

# Esquema de segurança HTTP Bearer
security = HTTPBearer()

class TokenData(BaseModel):
    """Dados do token JWT"""
    email: Optional[str] = None
    perfil: Optional[str] = None

class UsuarioAtual(BaseModel):
    """Modelo do usuário autenticado"""
    id: int
    nome: str
    email: str
    perfil: str

def verificar_senha(senha_plana: str, senha_hash: str) -> bool:
    """Verifica se a senha plana corresponde ao hash"""
    return pwd_context.verify(senha_plana, senha_hash)

def criar_hash_senha(senha: str) -> str:
    """Cria um hash da senha"""
    return pwd_context.hash(senha)

def criar_token_acesso(data: dict, expires_delta: Optional[timedelta] = None):
    """Cria um token JWT de acesso"""
    to_encode = data.copy()
    if expires_delta:
        expire = datetime.utcnow() + expires_delta
    else:
        expire = datetime.utcnow() + timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    to_encode.update({"exp": expire})
    encoded_jwt = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
    return encoded_jwt

async def obter_usuario_atual(
    credentials: HTTPAuthorizationCredentials = Depends(security)
) -> UsuarioAtual:
    """Obtém o usuário atual a partir do token JWT"""
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Não foi possível validar as credenciais",
        headers={"WWW-Authenticate": "Bearer"},
    )
    
    try:
        token = credentials.credentials
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        email: str = payload.get("sub")
        perfil: str = payload.get("perfil")
        usuario_id: int = payload.get("id")
        nome: str = payload.get("nome")
        
        if email is None:
            raise credentials_exception
            
        return UsuarioAtual(
            id=usuario_id,
            nome=nome,
            email=email,
            perfil=perfil
        )
    except JWTError:
        raise credentials_exception

async def requer_admin(
    usuario_atual: UsuarioAtual = Depends(obter_usuario_atual)
) -> UsuarioAtual:
    """Verifica se o usuário atual é administrador"""
    if usuario_atual.perfil != "administrador":
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Acesso negado. Apenas administradores podem realizar esta ação."
        )
    return usuario_atual

