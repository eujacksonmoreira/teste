"""
Serviço de envio de emails via SMTP Microsoft Exchange
"""
import os
import aiosmtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

# Configurações SMTP
SMTP_HOST = os.getenv("SMTP_HOST", "smtp.office365.com")
SMTP_PORT = int(os.getenv("SMTP_PORT", "587"))
SMTP_USER = os.getenv("SMTP_USER", "")
SMTP_PASSWORD = os.getenv("SMTP_PASSWORD", "")
SMTP_FROM = os.getenv("SMTP_FROM", SMTP_USER)
APP_URL = os.getenv("APP_URL", "http://localhost:8080")

async def enviar_email(
    destinatario: str,
    assunto: str,
    corpo_html: str
):
    """
    Envia um email via SMTP
    
    Args:
        destinatario: Email do destinatário
        assunto: Assunto do email
        corpo_html: Corpo do email em HTML
    """
    if not SMTP_USER or not SMTP_PASSWORD:
        print("⚠ Configurações SMTP não definidas. Email não será enviado.")
        return
    
    # Criar mensagem
    mensagem = MIMEMultipart("alternative")
    mensagem["From"] = SMTP_FROM
    mensagem["To"] = destinatario
    mensagem["Subject"] = assunto
    
    # Adicionar corpo HTML
    parte_html = MIMEText(corpo_html, "html", "utf-8")
    mensagem.attach(parte_html)
    
    # Enviar email
    try:
        await aiosmtplib.send(
            mensagem,
            hostname=SMTP_HOST,
            port=SMTP_PORT,
            username=SMTP_USER,
            password=SMTP_PASSWORD,
            start_tls=True
        )
        print(f"✓ Email enviado para {destinatario}")
    except Exception as e:
        print(f"✗ Erro ao enviar email: {e}")
        raise

async def enviar_email_convite(email: str, nome: str, token: str):
    """
    Envia email de convite para novo usuário definir senha
    
    Args:
        email: Email do usuário
        nome: Nome do usuário
        token: Token de convite
    """
    link_convite = f"{APP_URL}/definir-senha?token={token}"
    
    corpo_html = f"""
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="UTF-8">
        <style>
            body {{
                font-family: Arial, sans-serif;
                line-height: 1.6;
                color: #333;
            }}
            .container {{
                max-width: 600px;
                margin: 0 auto;
                padding: 20px;
            }}
            .header {{
                background-color: #0066cc;
                color: white;
                padding: 20px;
                text-align: center;
            }}
            .content {{
                padding: 20px;
                background-color: #f9f9f9;
            }}
            .button {{
                display: inline-block;
                padding: 12px 24px;
                background-color: #0066cc;
                color: white;
                text-decoration: none;
                border-radius: 4px;
                margin: 20px 0;
            }}
            .footer {{
                padding: 20px;
                text-align: center;
                font-size: 12px;
                color: #666;
            }}
        </style>
    </head>
    <body>
        <div class="container">
            <div class="header">
                <h1>Bem-vindo ao Sistema de Gestão de Processos</h1>
            </div>
            <div class="content">
                <p>Olá, <strong>{nome}</strong>!</p>
                <p>Você foi convidado a fazer parte do Sistema de Gestão de Processos Backoffice.</p>
                <p>Para ativar sua conta, clique no botão abaixo e defina sua senha:</p>
                <p style="text-align: center;">
                    <a href="{link_convite}" class="button">Definir Senha</a>
                </p>
                <p>Ou copie e cole o link abaixo no seu navegador:</p>
                <p style="word-break: break-all; background-color: #fff; padding: 10px; border: 1px solid #ddd;">
                    {link_convite}
                </p>
                <p><strong>Atenção:</strong> Este link expira em 7 dias.</p>
            </div>
            <div class="footer">
                <p>Este é um email automático. Por favor, não responda.</p>
                <p>&copy; 2025 Sistema de Gestão de Processos Backoffice</p>
            </div>
        </div>
    </body>
    </html>
    """
    
    await enviar_email(
        destinatario=email,
        assunto="Convite - Sistema de Gestão de Processos",
        corpo_html=corpo_html
    )

