#!/bin/bash

echo "Iniciando a API FastAPI com Uvicorn..."

# Instalar dependências se ainda não estiverem instaladas
pip install -r requirements.txt

# Iniciar o Uvicorn em segundo plano
# O --reload é útil para desenvolvimento, mas pode ser removido em produção
# O --host 0.0.0.0 permite que a API seja acessível externamente
# O --port 8000 define a porta da API

# Salva o PID do processo para que o script stop.sh possa encerrá-lo
uvicorn main:app --host 0.0.0.0 --port 8000 --reload & echo $! > uvicorn.pid

echo "API iniciada. PID salvo em uvicorn.pid"


