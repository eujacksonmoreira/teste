
#!/bin/bash

if [ -f uvicorn.pid ]; then
    PID=$(cat uvicorn.pid)
    echo "Encerrando processo Uvicorn com PID: $PID"
    kill $PID
    rm uvicorn.pid
    echo "API encerrada."
else
    echo "Nenhum processo Uvicorn encontrado para encerrar (uvicorn.pid não existe)."
fi


