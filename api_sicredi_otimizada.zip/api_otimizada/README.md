# API Sicredi Fluid - Versão Otimizada 🚀

Esta é a versão otimizada da API Sicredi Fluid com melhorias significativas em arquitetura, performance, segurança e manutenibilidade.

## 📋 Principais Melhorias Implementadas

### ✅ Estrutura de Resposta Padronizada
- Todas as respostas seguem um formato consistente
- Status claros: `sucesso`, `erro`, `processando`, `concluido`
- IDs únicos para rastreamento de ensaios
- Timestamps automáticos
- Mensagens descritivas

### ✅ Métodos HTTP Corretos
- **GET** para consultas (dados_associado, busca_cep, consulta_cnae, etc.)
- **POST** apenas para operações que modificam dados
- **PUT** para atualizações completas
- **DELETE** para remoções

### ✅ Tratamento de Erro Robusto
- Middleware global de tratamento de erro
- Logs estruturados
- Sem reinicialização automática da aplicação
- Códigos de erro específicos
- Mensagens de erro claras

### ✅ Configuração Flexível
- Variáveis de ambiente via arquivo `.env`
- Configuração de SSL flexível
- Suporte a diferentes ambientes (dev, prod)
- CORS configurável

### ✅ Endpoint de Teste de Doping
- Exemplo completo de implementação
- GET para consulta de status
- POST para iniciar testes
- Estrutura replicável para outros itens

### ✅ Segurança Aprimorada
- Headers de segurança automáticos
- Validação de entrada robusta
- Rate limiting configurável
- CORS apropriado

## 🏗️ Estrutura do Projeto

```
api_otimizada/
├── app/                          # Código principal da aplicação
│   ├── __init__.py
│   ├── main.py                   # Arquivo principal da API
│   ├── endpoints/                # Endpoints organizados por módulo
│   │   ├── __init__.py
│   │   └── doping.py            # Endpoint de teste de doping
│   ├── models/                   # Modelos de dados
│   │   ├── __init__.py
│   │   └── response_models.py   # Modelos de resposta padronizados
│   ├── middleware/               # Middleware personalizado
│   │   ├── __init__.py
│   │   └── error_handler.py     # Tratamento de erros
│   └── utils/                    # Utilitários
│       ├── __init__.py
│       └── helpers.py           # Funções auxiliares
├── scripts/                      # Scripts de controle
│   ├── start_api.bat            # Iniciar API
│   ├── stop_api.bat             # Parar API
│   └── install_dependencies.bat # Instalar dependências
├── config/                       # Configurações
│   ├── nginx.conf               # Configuração Nginx
│   └── .env.example             # Exemplo de variáveis de ambiente
├── requirements.txt              # Dependências Python
└── README.md                     # Esta documentação
```

## 🚀 Como Usar

### 1. Instalação de Dependências

Execute o script de instalação:
```bash
scripts\install_dependencies.bat
```

Ou manualmente:
```bash
pip install -r requirements.txt
```

### 2. Configuração

1. Copie o arquivo de exemplo:
   ```bash
   copy config\.env.example .env
   ```

2. Edite o arquivo `.env` com suas configurações:
   ```env
   API_HOST=0.0.0.0
   API_PORT=8000
   DB_HOST=10.48.210.203
   DB_USER=app_3021_rpa
   DB_PASSWORD=3021
   # ... outras configurações
   ```

### 3. Iniciar a API

```bash
scripts\start_api.bat
```

### 4. Parar a API

```bash
scripts\stop_api.bat
```

## 📚 Documentação da API

Após iniciar a API, acesse:

- **Swagger UI**: http://localhost:8000/docs
- **ReDoc**: http://localhost:8000/redoc
- **Health Check**: http://localhost:8000/health

## 🧪 Endpoint de Teste de Doping

### Consultar Status de Teste
```http
GET /doping/test/{item_id}?include_details=true
```

### Iniciar Novo Teste
```http
POST /doping/test/{item_id}/start?test_type=qualidade&priority=normal
```

### Listar Todos os Testes
```http
GET /doping/tests?status=sucesso&limit=10
```

## 📊 Estrutura de Resposta Padronizada

Todos os endpoints retornam uma estrutura consistente:

```json
{
  "id_ensaio": "550e8400-e29b-41d4-a716-446655440001",
  "nome_ensaio": "dados_associado",
  "status": "sucesso",
  "mensagem": "Dados consultados com sucesso",
  "timestamp": "2024-01-15T10:30:00Z",
  "dados": {
    // Dados específicos do ensaio
  }
}
```

### Status Possíveis
- `sucesso`: Operação concluída com êxito
- `erro`: Erro na operação
- `processando`: Operação em andamento
- `concluido`: Operação finalizada

## 🔧 Configuração do Nginx

Use o arquivo `config/nginx.conf` como base para configurar o proxy reverso:

```bash
# Copie para o diretório do Nginx
copy config\nginx.conf C:\nginx\conf\
```

## 🔒 Segurança

### Headers Automáticos
- X-Frame-Options: DENY
- X-Content-Type-Options: nosniff
- X-XSS-Protection: 1; mode=block
- Content-Security-Policy configurável

### Rate Limiting
- Configurável via variáveis de ambiente
- Proteção contra ataques DDoS
- Limites por IP

### CORS
- Origens configuráveis
- Headers apropriados
- Suporte a credenciais

## 📈 Monitoramento

### Logs
- Logs estruturados em arquivo
- Rotação automática de logs
- Diferentes níveis de log

### Métricas
- Endpoint de health check
- Métricas de performance
- Status do banco de dados

## 🔄 Migração da API Antiga

### Endpoints Convertidos para GET
Os seguintes endpoints foram convertidos de POST para GET:

- `/dados_associado` → Consulta dados de associado
- `/busca_cep` → Busca informações de CEP
- `/consulta_cnae` → Consulta código CNAE
- E muitos outros...

### Compatibilidade
- Estrutura de resposta padronizada
- Validação de entrada melhorada
- Tratamento de erro robusto

## 🛠️ Desenvolvimento

### Executar em Modo de Desenvolvimento
```bash
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

### Testes
```bash
pytest tests/
```

### Linting
```bash
flake8 app/
black app/
```

## 📞 Suporte

Para dúvidas ou problemas:

1. Verifique os logs em `logs/api.log`
2. Consulte a documentação em `/docs`
3. Execute o health check em `/health`

## 📝 Changelog

### Versão 2.0.0
- ✅ Estrutura padronizada de resposta
- ✅ Métodos HTTP corretos
- ✅ Tratamento de erro robusto
- ✅ Endpoint de teste de doping
- ✅ Configuração flexível
- ✅ Documentação automática
- ✅ Scripts de controle
- ✅ Configuração Nginx

