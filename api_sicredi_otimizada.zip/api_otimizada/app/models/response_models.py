"""
Modelos de resposta padronizados para a API Sicredi
"""
from pydantic import BaseModel, Field
from typing import Any, Optional, Union
from enum import Enum
import uuid
from datetime import datetime


class StatusEnum(str, Enum):
    """Enum para status de resposta"""
    SUCESSO = "sucesso"
    ERRO = "erro"
    PROCESSANDO = "processando"
    CONCLUIDO = "concluido"


class BaseResponse(BaseModel):
    """Modelo base para todas as respostas da API"""
    id_ensaio: str = Field(default_factory=lambda: str(uuid.uuid4()), description="ID único do ensaio")
    nome_ensaio: str = Field(..., description="Nome do ensaio/endpoint")
    status: StatusEnum = Field(..., description="Status da operação")
    mensagem: str = Field(..., description="Mensagem descritiva do status")
    timestamp: datetime = Field(default_factory=datetime.now, description="Timestamp da resposta")
    dados: Optional[Any] = Field(None, description="Dados específicos do ensaio")


class SuccessResponse(BaseResponse):
    """Modelo para respostas de sucesso"""
    status: StatusEnum = StatusEnum.SUCESSO


class ErrorResponse(BaseResponse):
    """Modelo para respostas de erro"""
    status: StatusEnum = StatusEnum.ERRO
    codigo_erro: Optional[str] = Field(None, description="Código específico do erro")


class ProcessingResponse(BaseResponse):
    """Modelo para respostas de processamento"""
    status: StatusEnum = StatusEnum.PROCESSANDO
    progresso: Optional[int] = Field(None, description="Percentual de progresso (0-100)")


class DopingTestResponse(BaseModel):
    """Modelo específico para teste de doping"""
    id_teste: str = Field(default_factory=lambda: str(uuid.uuid4()))
    item_testado: str = Field(..., description="Item sendo testado")
    status_teste: StatusEnum = Field(..., description="Status do teste de doping")
    resultado: Optional[dict] = Field(None, description="Resultado do teste")
    data_teste: datetime = Field(default_factory=datetime.now)
    observacoes: Optional[str] = Field(None, description="Observações sobre o teste")


# Modelos de entrada para diferentes endpoints
class CPFRequest(BaseModel):
    """Modelo para requisições que necessitam CPF"""
    cpf: str = Field(..., description="CPF do associado", example="123.456.789-00")


class CNPJRequest(BaseModel):
    """Modelo para requisições que necessitam CNPJ"""
    cnpj: str = Field(..., description="CNPJ da empresa", example="12.345.678/0001-90")


class CEPRequest(BaseModel):
    """Modelo para busca de CEP"""
    cep: str = Field(..., description="CEP para busca", example="01234-567")


class DopingRequest(BaseModel):
    """Modelo para requisição de teste de doping"""
    item_id: str = Field(..., description="ID do item para teste")
    tipo_teste: str = Field(..., description="Tipo de teste a ser realizado")
    parametros: Optional[dict] = Field(None, description="Parâmetros específicos do teste")

