"""
Modelos de dados da API Sicredi
"""

