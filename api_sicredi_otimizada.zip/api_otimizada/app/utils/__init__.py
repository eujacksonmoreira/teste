"""
Utilitários da API Sicredi
"""

