"""
Funções auxiliares para a API Sicredi
"""
import os
import keyring
from fastapi import HTTPException, Depends
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from typing import Optional
import mysql.connector
from datetime import datetime
import re


security = HTTPBearer()


def verify_token(credentials: HTTPAuthorizationCredentials = Depends(security)):
    """
    Verifica o token de autenticação
    
    Args:
        credentials: Credenciais de autorização
        
    Raises:
        HTTPException: Se o token for inválido
    """
    service = 'token_api_local'
    token = keyring.get_password(service, service)
    
    if not token:
        raise HTTPException(
            status_code=401, 
            detail="Token de autenticação não configurado"
        )
    
    if credentials.scheme.lower() != "bearer" or credentials.credentials != token:
        raise HTTPException(
            status_code=401, 
            detail="Token de autenticação inválido"
        )
    
    return credentials


def get_database_connection():
    """
    Cria conexão com o banco de dados
    
    Returns:
        Conexão MySQL
        
    Raises:
        HTTPException: Se não conseguir conectar ao banco
    """
    try:
        connection = mysql.connector.connect(
            host=os.getenv("DB_HOST", "10.48.210.203"),
            user=os.getenv("DB_USER", "app_3021_rpa"),
            password=os.getenv("DB_PASSWORD", "3021"),
            database=os.getenv("DB_NAME", "bd1")
        )
        return connection
    except mysql.connector.Error as e:
        raise HTTPException(
            status_code=500,
            detail=f"Erro ao conectar com o banco de dados: {str(e)}"
        )


def log_api_access(client_ip: str, endpoint: str):
    """
    Registra acesso à API no banco de dados
    
    Args:
        client_ip: IP do cliente
        endpoint: Endpoint acessado
    """
    try:
        connection = get_database_connection()
        cursor = connection.cursor()
        
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        query = "INSERT INTO BD2.acessos_api (usuario, data_acesso, endpoint) VALUES (%s, %s, %s)"
        cursor.execute(query, (client_ip, now, endpoint))
        
        connection.commit()
        cursor.close()
        connection.close()
    except Exception as e:
        # Log do erro, mas não interrompe a execução
        print(f"Erro ao registrar acesso: {e}")


def validate_cpf(cpf: str) -> bool:
    """
    Valida formato de CPF
    
    Args:
        cpf: CPF a ser validado
        
    Returns:
        True se válido, False caso contrário
    """
    # Remove caracteres não numéricos
    cpf = re.sub(r'[^0-9]', '', cpf)
    
    # Verifica se tem 11 dígitos
    if len(cpf) != 11:
        return False
    
    # Verifica se todos os dígitos são iguais
    if cpf == cpf[0] * 11:
        return False
    
    # Validação dos dígitos verificadores
    def calculate_digit(cpf_partial):
        sum_digits = sum(int(digit) * weight for digit, weight in zip(cpf_partial, range(len(cpf_partial) + 1, 1, -1)))
        remainder = sum_digits % 11
        return 0 if remainder < 2 else 11 - remainder
    
    # Verifica primeiro dígito
    if int(cpf[9]) != calculate_digit(cpf[:9]):
        return False
    
    # Verifica segundo dígito
    if int(cpf[10]) != calculate_digit(cpf[:10]):
        return False
    
    return True


def validate_cnpj(cnpj: str) -> bool:
    """
    Valida formato de CNPJ
    
    Args:
        cnpj: CNPJ a ser validado
        
    Returns:
        True se válido, False caso contrário
    """
    # Remove caracteres não numéricos
    cnpj = re.sub(r'[^0-9]', '', cnpj)
    
    # Verifica se tem 14 dígitos
    if len(cnpj) != 14:
        return False
    
    # Verifica se todos os dígitos são iguais
    if cnpj == cnpj[0] * 14:
        return False
    
    # Validação dos dígitos verificadores
    def calculate_digit(cnpj_partial, weights):
        sum_digits = sum(int(digit) * weight for digit, weight in zip(cnpj_partial, weights))
        remainder = sum_digits % 11
        return 0 if remainder < 2 else 11 - remainder
    
    # Pesos para o primeiro dígito
    weights1 = [5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2]
    # Pesos para o segundo dígito
    weights2 = [6, 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2]
    
    # Verifica primeiro dígito
    if int(cnpj[12]) != calculate_digit(cnpj[:12], weights1):
        return False
    
    # Verifica segundo dígito
    if int(cnpj[13]) != calculate_digit(cnpj[:13], weights2):
        return False
    
    return True


def validate_cep(cep: str) -> bool:
    """
    Valida formato de CEP
    
    Args:
        cep: CEP a ser validado
        
    Returns:
        True se válido, False caso contrário
    """
    # Remove caracteres não numéricos
    cep = re.sub(r'[^0-9]', '', cep)
    
    # Verifica se tem 8 dígitos
    return len(cep) == 8


def sanitize_input(input_string: str) -> str:
    """
    Sanitiza entrada de dados para prevenir SQL injection
    
    Args:
        input_string: String a ser sanitizada
        
    Returns:
        String sanitizada
    """
    if not input_string:
        return ""
    
    # Remove caracteres perigosos
    dangerous_chars = ["'", '"', ";", "--", "/*", "*/", "xp_", "sp_"]
    sanitized = input_string
    
    for char in dangerous_chars:
        sanitized = sanitized.replace(char, "")
    
    return sanitized.strip()


def get_client_ip(request) -> str:
    """
    Obtém o IP real do cliente considerando proxies
    
    Args:
        request: Objeto Request do FastAPI
        
    Returns:
        IP do cliente
    """
    # Verifica headers de proxy
    forwarded_for = request.headers.get("X-Forwarded-For")
    if forwarded_for:
        return forwarded_for.split(",")[0].strip()
    
    real_ip = request.headers.get("X-Real-IP")
    if real_ip:
        return real_ip
    
    # Fallback para IP direto
    return request.client.host if request.client else "unknown"

