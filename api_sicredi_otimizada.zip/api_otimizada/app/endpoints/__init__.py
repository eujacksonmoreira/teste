"""
Módulo de endpoints da API Sicredi
"""

