"""
Middleware da API Sicredi
"""

