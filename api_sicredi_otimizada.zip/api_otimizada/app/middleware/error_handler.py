"""
Middleware para tratamento de erros da API Sicredi
"""
import logging
import traceback
from fastapi import Request, HTTPException
from fastapi.responses import JSONResponse
from starlette.middleware.base import BaseHTTPMiddleware
from typing import Callable
import uuid
from datetime import datetime

from ..models.response_models import ErrorResponse, StatusEnum


# Configuração de logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('api_errors.log'),
        logging.StreamHandler()
    ]
)

logger = logging.getLogger(__name__)


class ErrorHandlerMiddleware(BaseHTTPMiddleware):
    """Middleware para capturar e tratar erros globalmente"""
    
    async def dispatch(self, request: Request, call_next: Callable):
        try:
            response = await call_next(request)
            return response
        except HTTPException as e:
            # Erros HTTP já tratados pelo FastAPI
            raise e
        except Exception as e:
            # Erros não tratados
            error_id = str(uuid.uuid4())
            
            # Log do erro
            logger.error(
                f"Erro não tratado [ID: {error_id}] - "
                f"Path: {request.url.path} - "
                f"Method: {request.method} - "
                f"Error: {str(e)}\n"
                f"Traceback: {traceback.format_exc()}"
            )
            
            # Resposta padronizada de erro
            error_response = ErrorResponse(
                id_ensaio=error_id,
                nome_ensaio=request.url.path.strip('/'),
                mensagem=f"Erro interno do servidor. ID do erro: {error_id}",
                codigo_erro="INTERNAL_SERVER_ERROR",
                dados=None
            )
            
            return JSONResponse(
                status_code=500,
                content=error_response.dict()
            )


def create_error_response(
    endpoint_name: str,
    error_message: str,
    error_code: str = None,
    status_code: int = 400
) -> JSONResponse:
    """
    Cria uma resposta de erro padronizada
    
    Args:
        endpoint_name: Nome do endpoint que gerou o erro
        error_message: Mensagem de erro
        error_code: Código específico do erro
        status_code: Código HTTP de status
    
    Returns:
        JSONResponse com erro padronizado
    """
    error_response = ErrorResponse(
        nome_ensaio=endpoint_name,
        mensagem=error_message,
        codigo_erro=error_code
    )
    
    return JSONResponse(
        status_code=status_code,
        content=error_response.dict()
    )


def create_success_response(
    endpoint_name: str,
    message: str,
    data: any = None
) -> dict:
    """
    Cria uma resposta de sucesso padronizada
    
    Args:
        endpoint_name: Nome do endpoint
        message: Mensagem de sucesso
        data: Dados a serem retornados
    
    Returns:
        Dicionário com resposta padronizada
    """
    from ..models.response_models import SuccessResponse
    
    response = SuccessResponse(
        nome_ensaio=endpoint_name,
        mensagem=message,
        dados=data
    )
    
    return response.dict()


def log_api_access(request: Request, response_time: float = None):
    """
    Registra acesso à API
    
    Args:
        request: Objeto Request do FastAPI
        response_time: Tempo de resposta em segundos
    """
    client_ip = request.client.host
    method = request.method
    path = request.url.path
    user_agent = request.headers.get("user-agent", "Unknown")
    
    log_message = f"API Access - IP: {client_ip} - Method: {method} - Path: {path}"
    if response_time:
        log_message += f" - Response Time: {response_time:.3f}s"
    
    logger.info(log_message)

