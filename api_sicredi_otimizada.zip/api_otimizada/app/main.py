"""
API Sicredi Fluid - Versão Otimizada
Autor: Sistema de Otimização API
Versão: 2.0.0

Principais melhorias implementadas:
- Estrutura padronizada de resposta para todos os endpoints
- Correção de métodos HTTP (GET para consultas, POST para modificações)
- Tratamento de erro robusto sem reinicialização da aplicação
- Middleware de tratamento de erro global
- Configuração flexível via variáveis de ambiente
- Endpoint de teste de doping como exemplo
- Documentação automática melhorada
- Headers de segurança e CORS apropriados
"""

import os
import sys
from datetime import datetime
from typing import List, Optional
import uvicorn
from fastapi import FastAPI, Request, HTTPException, Depends, Query, Response
from fastapi.responses import HTMLResponse, JSONResponse, FileResponse
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import HTTPAuthorizationCredentials
from pydantic import BaseModel
from dotenv import load_dotenv

# Importações locais
from .models.response_models import (
    BaseResponse, 
    SuccessResponse, 
    ErrorResponse, 
    StatusEnum,
    CPFRequest,
    CNPJRequest,
    CEPRequest
)
from .middleware.error_handler import (
    ErrorHandlerMiddleware, 
    create_success_response, 
    create_error_response,
    log_api_access
)
from .utils.helpers import (
    verify_token, 
    get_database_connection, 
    validate_cpf, 
    validate_cnpj,
    get_client_ip
)
from .endpoints.doping import router as doping_router

# Carrega variáveis de ambiente
load_dotenv()

# Configuração da aplicação
app = FastAPI(
    title="Sicredi Alta Noroeste SP - API Otimizada",
    description="""
    API otimizada para processos Fluid do Sicredi.
    
    ## Principais melhorias:
    - ✅ Estrutura padronizada de resposta
    - ✅ Métodos HTTP corretos (GET para consultas)
    - ✅ Tratamento de erro robusto
    - ✅ Configuração flexível
    - ✅ Documentação automática
    - ✅ Endpoint de teste de doping
    - ✅ Headers de segurança
    
    ## Estrutura de Resposta Padronizada:
    Todos os endpoints retornam uma estrutura consistente com:
    - `id_ensaio`: ID único do ensaio
    - `nome_ensaio`: Nome do endpoint/ensaio
    - `status`: Status da operação (sucesso, erro, processando, concluido)
    - `mensagem`: Mensagem descritiva
    - `timestamp`: Timestamp da resposta
    - `dados`: Dados específicos do ensaio
    """,
    version="2.0.0",
    docs_url="/docs",
    redoc_url="/redoc"
)

# Configuração CORS
cors_origins = os.getenv("CORS_ORIGINS", "https://3021.fluid.sicredi.io,https://api.fluid.sicredi.io").split(",")

app.add_middleware(
    CORSMiddleware,
    allow_origins=cors_origins,
    allow_credentials=True,
    allow_methods=["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    allow_headers=["Authorization", "Content-Type", "X-Requested-With", "*"]
)

# Middleware de tratamento de erro
app.add_middleware(ErrorHandlerMiddleware)

# Inclui routers
app.include_router(doping_router)


# ===== ENDPOINTS DE SAÚDE E MONITORAMENTO =====

@app.get("/health", tags=["Monitoramento"])
async def health_check():
    """
    Endpoint de verificação de saúde da API
    """
    try:
        # Testa conexão com banco de dados
        db_status = "ok"
        try:
            conn = get_database_connection()
            conn.close()
        except Exception:
            db_status = "error"
        
        return create_success_response(
            "health_check",
            "API está funcionando corretamente",
            {
                "status": "healthy",
                "timestamp": datetime.now().isoformat(),
                "version": "2.0.0",
                "database": db_status,
                "environment": os.getenv("ENVIRONMENT", "development")
            }
        )
    except Exception as e:
        return create_error_response(
            "health_check",
            f"Erro na verificação de saúde: {str(e)}",
            "HEALTH_CHECK_ERROR",
            500
        )


@app.get("/", response_class=HTMLResponse, tags=["Documentação"])
async def root():
    """
    Página inicial da API com informações básicas
    """
    html_content = """
    <!DOCTYPE html>
    <html>
    <head>
        <title>API Sicredi Fluid - Otimizada</title>
        <style>
            body { font-family: Arial, sans-serif; margin: 40px; background-color: #f5f5f5; }
            .container { max-width: 800px; margin: 0 auto; background: white; padding: 30px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
            h1 { color: #2c5aa0; }
            .status { background: #d4edda; color: #155724; padding: 10px; border-radius: 4px; margin: 20px 0; }
            .links { margin: 20px 0; }
            .links a { display: inline-block; margin: 10px 10px 10px 0; padding: 10px 20px; background: #007bff; color: white; text-decoration: none; border-radius: 4px; }
            .links a:hover { background: #0056b3; }
            .improvements { background: #f8f9fa; padding: 20px; border-radius: 4px; margin: 20px 0; }
            .improvements ul { margin: 10px 0; }
            .improvements li { margin: 5px 0; }
        </style>
    </head>
    <body>
        <div class="container">
            <h1>🚀 API Sicredi Fluid - Versão Otimizada</h1>
            
            <div class="status">
                ✅ API está funcionando corretamente - Versão 2.0.0
            </div>
            
            <div class="improvements">
                <h3>🔧 Melhorias Implementadas:</h3>
                <ul>
                    <li>✅ Estrutura padronizada de resposta para todos os endpoints</li>
                    <li>✅ Correção de métodos HTTP (GET para consultas, POST para modificações)</li>
                    <li>✅ Tratamento de erro robusto sem reinicialização da aplicação</li>
                    <li>✅ Middleware de tratamento de erro global</li>
                    <li>✅ Configuração flexível via variáveis de ambiente</li>
                    <li>✅ Endpoint de teste de doping como exemplo</li>
                    <li>✅ Headers de segurança e CORS apropriados</li>
                    <li>✅ Documentação automática melhorada</li>
                    <li>✅ Validação de entrada robusta</li>
                    <li>✅ Logs estruturados</li>
                </ul>
            </div>
            
            <div class="links">
                <a href="/docs">📚 Documentação Swagger</a>
                <a href="/redoc">📖 Documentação ReDoc</a>
                <a href="/health">🏥 Health Check</a>
                <a href="/doping/tests">🧪 Teste de Doping</a>
            </div>
            
            <p><strong>Data/Hora:</strong> """ + datetime.now().strftime("%d/%m/%Y %H:%M:%S") + """</p>
            <p><strong>Ambiente:</strong> """ + os.getenv("ENVIRONMENT", "development") + """</p>
        </div>
    </body>
    </html>
    """
    return HTMLResponse(content=html_content)


# ===== ENDPOINTS OTIMIZADOS (EXEMPLOS) =====

@app.get("/dados_associado", tags=["Processos Fluid: Geral"])
async def get_dados_associado(
    cpf: str = Query(..., description="CPF do associado"),
    include_details: bool = Query(False, description="Incluir detalhes completos"),
    request: Request = None
):
    """
    Consulta dados de um associado (OTIMIZADO: GET em vez de POST)
    
    Exemplo de endpoint otimizado que demonstra:
    - Uso correto do método GET para consulta
    - Estrutura padronizada de resposta
    - Validação de entrada
    - Tratamento de erro adequado
    """
    try:
        # Log do acesso
        client_ip = get_client_ip(request)
        log_api_access(client_ip, "dados_associado")
        
        # Validação do CPF
        if not validate_cpf(cpf):
            return create_error_response(
                "dados_associado",
                "CPF inválido. Verifique o formato e dígitos verificadores.",
                "INVALID_CPF",
                400
            )
        
        # Aqui seria implementada a lógica real de consulta
        # Por enquanto, retorna dados simulados
        dados_simulados = {
            "cpf": cpf,
            "nome": "João da Silva",
            "status": "ativo",
            "agencia": "3021",
            "conta": "12345-6"
        }
        
        if include_details:
            dados_simulados.update({
                "endereco": "Rua das Flores, 123",
                "telefone": "(11) 99999-9999",
                "email": "joao@email.com"
            })
        
        return create_success_response(
            "dados_associado",
            f"Dados do associado {cpf} consultados com sucesso",
            dados_simulados
        )
        
    except Exception as e:
        return create_error_response(
            "dados_associado",
            f"Erro ao consultar dados do associado: {str(e)}",
            "INTERNAL_ERROR",
            500
        )


@app.get("/busca_cep", tags=["Processos Fluid: Abertura de Conta"])
async def get_busca_cep(
    cep: str = Query(..., description="CEP para busca"),
    request: Request = None
):
    """
    Busca informações de endereço por CEP (OTIMIZADO: GET em vez de POST)
    """
    try:
        # Log do acesso
        client_ip = get_client_ip(request)
        log_api_access(client_ip, "busca_cep")
        
        # Remove formatação do CEP
        cep_clean = cep.replace("-", "").replace(".", "").strip()
        
        # Validação do CEP
        if not cep_clean.isdigit() or len(cep_clean) != 8:
            return create_error_response(
                "busca_cep",
                "CEP inválido. Use o formato 12345-678 ou 12345678.",
                "INVALID_CEP",
                400
            )
        
        # Dados simulados (em produção, consultaria API dos Correios)
        endereco_simulado = {
            "cep": f"{cep_clean[:5]}-{cep_clean[5:]}",
            "logradouro": "Rua das Flores",
            "bairro": "Centro",
            "cidade": "São Paulo",
            "uf": "SP",
            "ibge": "3550308"
        }
        
        return create_success_response(
            "busca_cep",
            f"Endereço encontrado para o CEP {cep}",
            endereco_simulado
        )
        
    except Exception as e:
        return create_error_response(
            "busca_cep",
            f"Erro ao buscar CEP: {str(e)}",
            "INTERNAL_ERROR",
            500
        )


@app.get("/consulta_cnae", tags=["Processos Fluid: Crédito"])
async def get_consulta_cnae(
    cnae: str = Query(..., description="Código CNAE para consulta"),
    request: Request = None
):
    """
    Consulta informações de um código CNAE (OTIMIZADO: GET em vez de POST)
    """
    try:
        # Log do acesso
        client_ip = get_client_ip(request)
        log_api_access(client_ip, "consulta_cnae")
        
        # Validação básica do CNAE
        cnae_clean = cnae.replace(".", "").replace("-", "").replace("/", "").strip()
        
        if not cnae_clean.isdigit() or len(cnae_clean) < 4:
            return create_error_response(
                "consulta_cnae",
                "Código CNAE inválido. Use o formato 1234-5/67.",
                "INVALID_CNAE",
                400
            )
        
        # Dados simulados
        cnae_info = {
            "codigo": cnae,
            "descricao": "Atividades de consultoria em gestão empresarial",
            "secao": "M",
            "divisao": "70",
            "grupo": "702",
            "classe": "7020-4",
            "subclasse": "7020-4/00"
        }
        
        return create_success_response(
            "consulta_cnae",
            f"Informações do CNAE {cnae} consultadas com sucesso",
            cnae_info
        )
        
    except Exception as e:
        return create_error_response(
            "consulta_cnae",
            f"Erro ao consultar CNAE: {str(e)}",
            "INTERNAL_ERROR",
            500
        )


# ===== ENDPOINT PARA DEMONSTRAR ESTRUTURA DE ENSAIOS =====

@app.get("/ensaios/status", tags=["Ensaios"])
async def get_ensaios_status(
    tipo_ensaio: Optional[str] = Query(None, description="Filtrar por tipo de ensaio"),
    status: Optional[str] = Query(None, description="Filtrar por status"),
    limit: int = Query(10, ge=1, le=100, description="Limite de resultados")
):
    """
    Lista status de ensaios com estrutura padronizada
    
    Demonstra a estrutura de retorno padronizada para ensaios:
    - id_ensaio: UUID único
    - nome_ensaio: Nome descritivo
    - status: sucesso|erro|processando|concluido
    - mensagem: Descrição do status
    - dados: Dados específicos do ensaio
    """
    try:
        # Simula lista de ensaios
        ensaios_simulados = [
            {
                "id_ensaio": "550e8400-e29b-41d4-a716-446655440001",
                "nome_ensaio": "Validação de CPF",
                "status": StatusEnum.SUCESSO,
                "mensagem": "CPF validado com sucesso",
                "timestamp": datetime.now(),
                "dados": {
                    "cpf_validado": "123.456.789-00",
                    "tempo_processamento": "0.5s"
                }
            },
            {
                "id_ensaio": "550e8400-e29b-41d4-a716-446655440002",
                "nome_ensaio": "Consulta Receita Federal",
                "status": StatusEnum.PROCESSANDO,
                "mensagem": "Consultando dados na Receita Federal",
                "timestamp": datetime.now(),
                "dados": {
                    "progresso": 75,
                    "etapa_atual": "Validando documentos"
                }
            },
            {
                "id_ensaio": "550e8400-e29b-41d4-a716-446655440003",
                "nome_ensaio": "Análise de Crédito",
                "status": StatusEnum.CONCLUIDO,
                "mensagem": "Análise de crédito finalizada",
                "timestamp": datetime.now(),
                "dados": {
                    "score": 750,
                    "limite_aprovado": 50000.00,
                    "observacoes": "Cliente aprovado"
                }
            }
        ]
        
        # Aplica filtros
        ensaios_filtrados = ensaios_simulados
        if tipo_ensaio:
            ensaios_filtrados = [e for e in ensaios_filtrados if tipo_ensaio.lower() in e["nome_ensaio"].lower()]
        if status:
            ensaios_filtrados = [e for e in ensaios_filtrados if e["status"] == status]
        
        # Aplica limite
        ensaios_limitados = ensaios_filtrados[:limit]
        
        return create_success_response(
            "ensaios_status",
            f"Encontrados {len(ensaios_filtrados)} ensaios, retornando {len(ensaios_limitados)}",
            {
                "ensaios": ensaios_limitados,
                "total_encontrados": len(ensaios_filtrados),
                "total_retornados": len(ensaios_limitados),
                "filtros_aplicados": {
                    "tipo_ensaio": tipo_ensaio,
                    "status": status,
                    "limit": limit
                }
            }
        )
        
    except Exception as e:
        return create_error_response(
            "ensaios_status",
            f"Erro ao consultar ensaios: {str(e)}",
            "INTERNAL_ERROR",
            500
        )


# ===== CONFIGURAÇÃO DE INICIALIZAÇÃO =====

if __name__ == "__main__":
    # Configurações do servidor
    host = os.getenv("API_HOST", "0.0.0.0")
    port = int(os.getenv("API_PORT", 8000))
    reload = os.getenv("API_RELOAD", "true").lower() == "true"
    log_level = os.getenv("API_LOG_LEVEL", "info")
    
    # SSL (se configurado)
    ssl_keyfile = os.getenv("SSL_KEYFILE")
    ssl_certfile = os.getenv("SSL_CERTFILE")
    
    print("=" * 50)
    print("🚀 INICIANDO API SICREDI FLUID OTIMIZADA")
    print("=" * 50)
    print(f"📍 Host: {host}")
    print(f"🔌 Porta: {port}")
    print(f"🔄 Reload: {reload}")
    print(f"📊 Log Level: {log_level}")
    print(f"🔒 SSL: {'Habilitado' if ssl_keyfile and ssl_certfile else 'Desabilitado'}")
    print(f"🌐 Documentação: http://{host}:{port}/docs")
    print("=" * 50)
    
    # Inicia o servidor
    uvicorn.run(
        "app.main:app",
        host=host,
        port=port,
        reload=reload,
        log_level=log_level,
        ssl_keyfile=ssl_keyfile,
        ssl_certfile=ssl_certfile
    )

