"""
Módulo principal da API Sicredi Fluid Otimizada
"""

