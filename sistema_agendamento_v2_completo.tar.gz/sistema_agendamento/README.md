# Sistema de Agendamento

Um sistema completo de agendamento e reservas desenvolvido com FastAPI, incluindo interface web moderna e funcionalidades avançadas de gerenciamento.

## 🚀 Funcionalidades

### 👥 Gerenciamento de Usuários
- Sistema completo de autenticação com JWT
- CRUD de usuários com controle de acesso
- Perfis de usuário personalizáveis
- Sistema de permissões (usuário/admin)

### 📅 Sistema de Reservas
- Agendamento de salas e veículos
- Validação de conflitos de horário
- Reservas limitadas ao mesmo dia
- Interface intuitiva para gerenciamento

### 🗓️ Agenda Semanal
- Visualização estilo Outlook
- Organização por períodos (manhã/tarde)
- Agenda individual e da equipe
- Indicação de localização e atividades

### 🔧 Administração
- Painel administrativo completo
- Gerenciamento de usuários e permissões
- CRUD de salas e veículos
- Controle total do sistema

## 🛠️ Tecnologias Utilizadas

### Backend
- **FastAPI** - Framework web moderno e rápido
- **SQLAlchemy** - ORM para banco de dados
- **Pydantic** - Validação de dados
- **JWT** - Autenticação segura
- **Uvicorn** - Servidor ASGI
- **SQLite/PostgreSQL** - Banco de dados

### Frontend
- **HTML5/CSS3** - Interface moderna
- **Bootstrap 5** - Framework CSS responsivo
- **JavaScript ES6+** - Interatividade
- **Axios** - Cliente HTTP
- **Font Awesome** - Ícones

### Infraestrutura
- **Nginx** - Proxy reverso e servidor web
- **Systemd** - Gerenciamento de serviços
- **Docker** - Containerização (opcional)

## 📋 Pré-requisitos

- Python 3.11+
- pip (gerenciador de pacotes Python)
- Nginx (opcional, para produção)
- SQLite (incluído) ou PostgreSQL

## 🚀 Instalação Rápida

### Opção 1: Script Automático (Recomendado)

```bash
# Clone o repositório
git clone <url-do-repositorio>
cd sistema_agendamento

# Execute o script de configuração
./setup.sh
```

### Opção 2: Instalação Manual

```bash
# 1. Criar ambiente virtual
python3.11 -m venv venv
source venv/bin/activate

# 2. Instalar dependências
pip install -r requirements.txt

# 3. Configurar variáveis de ambiente
cp .env.example .env
# Edite o arquivo .env conforme necessário

# 4. Executar aplicação
python main.py
```

## ⚙️ Configuração

### Arquivo .env

```env
# Banco de Dados
DATABASE_URL=sqlite:///./sistema_agendamento.db

# JWT
SECRET_KEY=sua-chave-secreta-muito-forte-aqui
ACCESS_TOKEN_EXPIRE_MINUTES=30

# Aplicação
DEBUG=true
HOST=0.0.0.0
PORT=8000

# Admin Padrão
ADMIN_EMAIL=admin@sistema.com
ADMIN_PASSWORD=admin123
```

### Nginx (Produção)

```bash
# Copiar configuração
sudo cp nginx.conf /etc/nginx/sites-available/sistema_agendamento
sudo ln -s /etc/nginx/sites-available/sistema_agendamento /etc/nginx/sites-enabled/

# Testar e recarregar
sudo nginx -t
sudo systemctl reload nginx
```

## 🏃‍♂️ Executando o Sistema

### Desenvolvimento

```bash
# Ativar ambiente virtual
source venv/bin/activate

# Executar com reload automático
uvicorn main:app --reload --host 0.0.0.0 --port 8000
```

### Produção

```bash
# Usando systemd (após configuração)
sudo systemctl start sistema-agendamento
sudo systemctl enable sistema-agendamento

# Ou manualmente
uvicorn main:app --host 0.0.0.0 --port 8000 --workers 4
```

## 📱 Uso do Sistema

### Acesso Inicial

1. Acesse `http://localhost:8000`
2. Use as credenciais padrão:
   - **Admin**: `admin` / `admin123`
   - **Usuário**: Registre-se na tela de login

### Funcionalidades Principais

#### 🏠 Dashboard
- Visão geral das reservas
- Estatísticas do sistema
- Ações rápidas

#### 📅 Reservas
- Criar nova reserva
- Selecionar sala ou veículo
- Definir horário (mesmo dia)
- Gerenciar reservas existentes

#### 🗓️ Agenda Semanal
- Visualizar agenda da semana
- Definir localização (manhã/tarde)
- Ver agenda da equipe
- Organização estilo Outlook

#### 👤 Perfil
- Editar informações pessoais
- Configurar perfil
- Alterar senha

#### ⚙️ Administração (Admin)
- Gerenciar usuários
- CRUD de salas e veículos
- Controle de permissões
- Configurações do sistema

## 🔧 API Endpoints

### Autenticação
- `POST /api/auth/login` - Login
- `POST /api/auth/register` - Registro
- `GET /api/auth/me` - Usuário atual

### Usuários
- `GET /api/users/` - Listar usuários
- `GET /api/users/{id}` - Obter usuário
- `PUT /api/users/{id}` - Atualizar usuário
- `DELETE /api/users/{id}` - Deletar usuário

### Reservas
- `GET /api/bookings/` - Listar reservas
- `POST /api/bookings/` - Criar reserva
- `PUT /api/bookings/{id}` - Atualizar reserva
- `DELETE /api/bookings/{id}` - Cancelar reserva

### Agenda
- `GET /api/schedule/` - Agenda do usuário
- `POST /api/schedule/` - Criar entrada
- `PUT /api/schedule/{id}` - Atualizar entrada
- `DELETE /api/schedule/{id}` - Deletar entrada

### Administração
- `GET /api/admin/rooms` - Gerenciar salas
- `GET /api/admin/vehicles` - Gerenciar veículos
- `POST /api/admin/users/{id}/toggle-admin` - Alterar admin

## 📁 Estrutura do Projeto

```
sistema_agendamento/
├── app/
│   ├── models/          # Modelos SQLAlchemy
│   ├── routes/          # Rotas da API
│   ├── services/        # Lógica de negócio
│   └── utils/           # Utilitários
├── config/              # Configurações
├── static/              # Arquivos estáticos
│   ├── css/
│   ├── js/
│   └── images/
├── templates/           # Templates HTML
├── logs/                # Arquivos de log
├── main.py              # Aplicação principal
├── requirements.txt     # Dependências
├── nginx.conf           # Configuração Nginx
├── setup.sh             # Script de instalação
└── README.md            # Documentação
```

## 🔒 Segurança

- Autenticação JWT com expiração
- Hash de senhas com bcrypt
- Validação de entrada com Pydantic
- Controle de acesso baseado em roles
- Headers de segurança no Nginx
- Proteção CSRF

## 📊 Monitoramento

### Logs
- Logs da aplicação: `logs/app.log`
- Logs de erro: `logs/error.log`
- Logs do Nginx: `/var/log/nginx/`

### Health Check
- Endpoint: `GET /health`
- Status da aplicação e dependências

## 🚀 Deploy

### Docker (Opcional)

```dockerfile
FROM python:3.11-slim

WORKDIR /app
COPY requirements.txt .
RUN pip install -r requirements.txt

COPY . .
EXPOSE 8000

CMD ["uvicorn", "main:app", "--host", "0.0.0.0", "--port", "8000"]
```

### Systemd Service

```ini
[Unit]
Description=Sistema de Agendamento
After=network.target

[Service]
Type=simple
User=ubuntu
WorkingDirectory=/path/to/sistema_agendamento
Environment=PATH=/path/to/sistema_agendamento/venv/bin
ExecStart=/path/to/sistema_agendamento/venv/bin/uvicorn main:app --host 0.0.0.0 --port 8000
Restart=always

[Install]
WantedBy=multi-user.target
```

## 🐛 Troubleshooting

### Problemas Comuns

1. **Erro de permissão no banco**
   ```bash
   chmod 664 sistema_agendamento.db
   ```

2. **Porta já em uso**
   ```bash
   lsof -i :8000
   kill -9 <PID>
   ```

3. **Erro de dependências**
   ```bash
   pip install --upgrade -r requirements.txt
   ```

4. **Nginx não inicia**
   ```bash
   sudo nginx -t
   sudo systemctl status nginx
   ```

## 📝 Changelog

### v1.0.0
- Sistema completo de autenticação
- CRUD de usuários e perfis
- Sistema de reservas de salas/veículos
- Agenda semanal interativa
- Interface web moderna
- Configuração Nginx
- Documentação completa

## 🤝 Contribuição

1. Fork o projeto
2. Crie uma branch para sua feature
3. Commit suas mudanças
4. Push para a branch
5. Abra um Pull Request

## 📄 Licença

Este projeto está sob a licença MIT. Veja o arquivo `LICENSE` para mais detalhes.

## 📞 Suporte

Para suporte e dúvidas:
- Abra uma issue no GitHub
- Consulte a documentação da API em `/docs`
- Verifique os logs em `logs/`

---

**Sistema de Agendamento** - Desenvolvido com ❤️ usando FastAPI

