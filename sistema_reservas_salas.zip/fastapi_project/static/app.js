// Estado global da aplicação
let currentUser = null;
let authToken = null;
let calendar = null;
let rooms = [];

// API Base URL
const API_BASE = '';

// Utilitários
function showAlert(message, type = 'info') {
    const alertDiv = document.createElement('div');
    alertDiv.className = `alert alert-${type}`;
    alertDiv.textContent = message;
    
    // Remover alertas existentes
    const existingAlerts = document.querySelectorAll('.alert');
    existingAlerts.forEach(alert => alert.remove());
    
    // Adicionar novo alerta
    const container = document.querySelector('.tab-content .tab-pane.active') || document.querySelector('#loginAlert');
    if (container) {
        container.insertBefore(alertDiv, container.firstChild);
        
        // Remover após 5 segundos
        setTimeout(() => {
            alertDiv.remove();
        }, 5000);
    }
}

function formatDateTime(dateTimeString) {
    const date = new Date(dateTimeString);
    return date.toLocaleString('pt-BR');
}

function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString('pt-BR');
}

function formatTime(dateTimeString) {
    const date = new Date(dateTimeString);
    return date.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
}

// API Functions
async function apiCall(endpoint, options = {}) {
    const url = `${API_BASE}${endpoint}`;
    const config = {
        headers: {
            'Content-Type': 'application/json',
            ...options.headers
        },
        ...options
    };
    
    if (authToken) {
        config.headers['Authorization'] = `Bearer ${authToken}`;
    }
    
    try {
        const response = await fetch(url, config);
        const data = await response.json();
        
        if (!response.ok) {
            throw new Error(data.detail || 'Erro na requisição');
        }
        
        return data;
    } catch (error) {
        console.error('API Error:', error);
        throw error;
    }
}

// Authentication
async function login(email, password) {
    const formData = new FormData();
    formData.append('username', email);
    formData.append('password', password);
    
    const response = await fetch('/auth/login', {
        method: 'POST',
        body: formData
    });
    
    if (!response.ok) {
        const error = await response.json();
        throw new Error(error.detail || 'Erro no login');
    }
    
    return response.json();
}

function logout() {
    currentUser = null;
    authToken = null;
    localStorage.removeItem('authToken');
    localStorage.removeItem('currentUser');
    
    document.getElementById('loginContainer').style.display = 'flex';
    document.getElementById('mainApp').style.display = 'none';
    
    // Limpar formulário
    document.getElementById('loginForm').reset();
}

function checkAuth() {
    const savedToken = localStorage.getItem('authToken');
    const savedUser = localStorage.getItem('currentUser');
    
    if (savedToken && savedUser) {
        authToken = savedToken;
        currentUser = JSON.parse(savedUser);
        showMainApp();
        return true;
    }
    
    return false;
}

function showMainApp() {
    document.getElementById('loginContainer').style.display = 'none';
    document.getElementById('mainApp').style.display = 'block';
    
    // Atualizar informações do usuário
    document.getElementById('userName').textContent = currentUser.name;
    document.getElementById('userAvatar').textContent = currentUser.name.charAt(0).toUpperCase();
    
    // Mostrar tab de admin se for admin
    if (currentUser.role === 'admin') {
        document.getElementById('adminTab').style.display = 'block';
    }
    
    // Inicializar aplicação
    initializeApp();
}

// App Initialization
async function initializeApp() {
    try {
        await loadRooms();
        initializeCalendar();
        loadMyReservations();
        
        if (currentUser.role === 'admin') {
            loadUsers();
        }
    } catch (error) {
        console.error('Erro ao inicializar aplicação:', error);
        showAlert('Erro ao carregar dados da aplicação', 'error');
    }
}

// Rooms
async function loadRooms() {
    try {
        rooms = await apiCall('/rooms/');
        
        // Atualizar select de salas
        const roomSelect = document.getElementById('reservationRoom');
        roomSelect.innerHTML = '<option value="">Selecione uma sala</option>';
        
        rooms.forEach(room => {
            const option = document.createElement('option');
            option.value = room.id;
            option.textContent = `${room.name} (${room.capacity} pessoas)`;
            roomSelect.appendChild(option);
        });
        
        if (currentUser.role === 'admin') {
            displayRooms();
        }
    } catch (error) {
        console.error('Erro ao carregar salas:', error);
        showAlert('Erro ao carregar salas', 'error');
    }
}

function displayRooms() {
    const roomsList = document.getElementById('roomsList');
    
    if (rooms.length === 0) {
        roomsList.innerHTML = '<p>Nenhuma sala cadastrada.</p>';
        return;
    }
    
    const table = document.createElement('table');
    table.className = 'table';
    table.innerHTML = `
        <thead>
            <tr>
                <th>Nome</th>
                <th>Capacidade</th>
                <th>Localização</th>
                <th>Status</th>
                <th>Ações</th>
            </tr>
        </thead>
        <tbody>
            ${rooms.map(room => `
                <tr>
                    <td>${room.name}</td>
                    <td>${room.capacity} pessoas</td>
                    <td>${room.location || '-'}</td>
                    <td>${room.is_active ? 'Ativa' : 'Inativa'}</td>
                    <td>
                        <button class="btn btn-secondary" onclick="editRoom(${room.id})">Editar</button>
                        <button class="btn btn-danger" onclick="deleteRoom(${room.id})">Excluir</button>
                    </td>
                </tr>
            `).join('')}
        </tbody>
    `;
    
    roomsList.innerHTML = '';
    roomsList.appendChild(table);
}

// Users (Admin only)
async function loadUsers() {
    try {
        const users = await apiCall('/users/');
        displayUsers(users);
    } catch (error) {
        console.error('Erro ao carregar usuários:', error);
        showAlert('Erro ao carregar usuários', 'error');
    }
}

function displayUsers(users) {
    const usersList = document.getElementById('usersList');
    
    if (users.length === 0) {
        usersList.innerHTML = '<p>Nenhum usuário cadastrado.</p>';
        return;
    }
    
    const table = document.createElement('table');
    table.className = 'table';
    table.innerHTML = `
        <thead>
            <tr>
                <th>Nome</th>
                <th>Email</th>
                <th>Perfil</th>
                <th>Status</th>
                <th>Criado em</th>
                <th>Ações</th>
            </tr>
        </thead>
        <tbody>
            ${users.map(user => `
                <tr>
                    <td>${user.name}</td>
                    <td>${user.email}</td>
                    <td>${user.role === 'admin' ? 'Administrador' : 'Usuário'}</td>
                    <td>${user.is_active ? 'Ativo' : 'Inativo'}</td>
                    <td>${formatDate(user.created_at)}</td>
                    <td>
                        <button class="btn btn-secondary" onclick="resetUserPassword(${user.id})">Reset Senha</button>
                        <button class="btn btn-danger" onclick="deleteUser(${user.id})">Excluir</button>
                    </td>
                </tr>
            `).join('')}
        </tbody>
    `;
    
    usersList.innerHTML = '';
    usersList.appendChild(table);
}

// Reservations
async function loadMyReservations() {
    try {
        const reservations = await apiCall('/reservations/');
        displayMyReservations(reservations);
    } catch (error) {
        console.error('Erro ao carregar reservas:', error);
        showAlert('Erro ao carregar reservas', 'error');
    }
}

function displayMyReservations(reservations) {
    const reservationsList = document.getElementById('reservationsList');
    
    if (reservations.length === 0) {
        reservationsList.innerHTML = '<p>Você não possui reservas.</p>';
        return;
    }
    
    const table = document.createElement('table');
    table.className = 'table';
    table.innerHTML = `
        <thead>
            <tr>
                <th>Título</th>
                <th>Sala</th>
                <th>Data</th>
                <th>Horário</th>
                <th>Status</th>
                <th>Ações</th>
            </tr>
        </thead>
        <tbody>
            ${reservations.map(reservation => `
                <tr>
                    <td>${reservation.title}</td>
                    <td>${reservation.room_name}</td>
                    <td>${formatDate(reservation.start_time)}</td>
                    <td>${formatTime(reservation.start_time)} - ${formatTime(reservation.end_time)}</td>
                    <td>${reservation.is_cancelled ? 'Cancelada' : 'Ativa'}</td>
                    <td>
                        ${!reservation.is_cancelled ? `
                            <button class="btn btn-secondary" onclick="editReservation(${reservation.id})">Editar</button>
                            <button class="btn btn-danger" onclick="cancelReservation(${reservation.id})">Cancelar</button>
                        ` : '-'}
                    </td>
                </tr>
            `).join('')}
        </tbody>
    `;
    
    reservationsList.innerHTML = '';
    reservationsList.appendChild(table);
}

// Calendar
function initializeCalendar() {
    const calendarEl = document.getElementById('calendar');
    
    calendar = new FullCalendar.Calendar(calendarEl, {
        initialView: 'dayGridMonth',
        locale: 'pt-br',
        headerToolbar: {
            left: 'prev,next today',
            center: 'title',
            right: 'dayGridMonth,timeGridWeek,timeGridDay'
        },
        buttonText: {
            today: 'Hoje',
            month: 'Mês',
            week: 'Semana',
            day: 'Dia'
        },
        events: loadCalendarEvents,
        eventClick: function(info) {
            showReservationDetails(info.event);
        },
        dateClick: function(info) {
            // Pré-preencher data no modal de nova reserva
            document.getElementById('reservationDate').value = info.dateStr;
            showNewReservationModal();
        }
    });
    
    calendar.render();
}

async function loadCalendarEvents(fetchInfo, successCallback, failureCallback) {
    try {
        const start = fetchInfo.start.toISOString();
        const end = fetchInfo.end.toISOString();
        
        const events = await apiCall(`/reservations/calendar?start_date=${start}&end_date=${end}`);
        
        const calendarEvents = events.map(event => ({
            id: event.id,
            title: event.title,
            start: event.start,
            end: event.end,
            className: event.is_own ? 'own-event' : 'other-event',
            extendedProps: {
                room_name: event.room_name,
                user_name: event.user_name,
                is_own: event.is_own
            }
        }));
        
        successCallback(calendarEvents);
    } catch (error) {
        console.error('Erro ao carregar eventos do calendário:', error);
        failureCallback(error);
    }
}

function showReservationDetails(event) {
    const isOwn = event.extendedProps.is_own;
    const title = isOwn ? event.title : 'Reservado';
    
    alert(`
        Título: ${title}
        Sala: ${event.extendedProps.room_name}
        Responsável: ${event.extendedProps.user_name}
        Início: ${formatDateTime(event.start)}
        Fim: ${formatDateTime(event.end)}
    `);
}

// Modal Functions
function showModal(modalId) {
    document.getElementById(modalId).classList.add('show');
}

function closeModal(modalId) {
    document.getElementById(modalId).classList.remove('show');
}

function showNewReservationModal() {
    // Definir data padrão como hoje
    const today = new Date().toISOString().split('T')[0];
    document.getElementById('reservationDate').value = today;
    
    showModal('newReservationModal');
}

function showNewUserModal() {
    showModal('newUserModal');
}

function showNewRoomModal() {
    showModal('newRoomModal');
}

// Tab Functions
function showTab(tabName) {
    // Remover classe active de todas as tabs
    document.querySelectorAll('.nav-tab').forEach(tab => {
        tab.classList.remove('active');
    });
    
    document.querySelectorAll('.tab-pane').forEach(pane => {
        pane.classList.remove('active');
    });
    
    // Ativar tab selecionada
    event.target.classList.add('active');
    document.getElementById(tabName + 'Tab').classList.add('active');
    
    // Recarregar dados se necessário
    if (tabName === 'reservations') {
        loadMyReservations();
    } else if (tabName === 'calendar' && calendar) {
        calendar.refetchEvents();
    }
}

function showAdminTab(tabName) {
    // Remover classe active de todas as admin tabs
    document.querySelectorAll('#adminTab .nav-tab').forEach(tab => {
        tab.classList.remove('active');
    });
    
    document.querySelectorAll('.admin-content').forEach(content => {
        content.classList.add('hidden');
    });
    
    // Ativar tab selecionada
    event.target.classList.add('active');
    document.getElementById('admin' + tabName.charAt(0).toUpperCase() + tabName.slice(1)).classList.remove('hidden');
    
    // Recarregar dados se necessário
    if (tabName === 'users') {
        loadUsers();
    } else if (tabName === 'rooms') {
        displayRooms();
    }
}

// Form Handlers
document.getElementById('loginForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    
    // Mostrar loading
    document.getElementById('loginText').classList.add('hidden');
    document.getElementById('loginLoading').classList.remove('hidden');
    
    try {
        const response = await login(email, password);
        
        authToken = response.access_token;
        currentUser = response.user;
        
        // Salvar no localStorage
        localStorage.setItem('authToken', authToken);
        localStorage.setItem('currentUser', JSON.stringify(currentUser));
        
        showMainApp();
    } catch (error) {
        showAlert(error.message, 'error');
    } finally {
        // Esconder loading
        document.getElementById('loginText').classList.remove('hidden');
        document.getElementById('loginLoading').classList.add('hidden');
    }
});

document.getElementById('newReservationForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const formData = {
        room_id: parseInt(document.getElementById('reservationRoom').value),
        title: document.getElementById('reservationTitle').value,
        description: document.getElementById('reservationDescription').value,
        start_time: new Date(document.getElementById('reservationDate').value + 'T' + document.getElementById('reservationStartTime').value).toISOString(),
        end_time: new Date(document.getElementById('reservationDate').value + 'T' + document.getElementById('reservationEndTime').value).toISOString()
    };
    
    // Mostrar loading
    document.getElementById('saveReservationText').classList.add('hidden');
    document.getElementById('saveReservationLoading').classList.remove('hidden');
    
    try {
        await apiCall('/reservations/', {
            method: 'POST',
            body: JSON.stringify(formData)
        });
        
        showAlert('Reserva criada com sucesso!', 'success');
        closeModal('newReservationModal');
        document.getElementById('newReservationForm').reset();
        
        // Atualizar calendário e lista de reservas
        if (calendar) {
            calendar.refetchEvents();
        }
        loadMyReservations();
    } catch (error) {
        showAlert(error.message, 'error');
    } finally {
        // Esconder loading
        document.getElementById('saveReservationText').classList.remove('hidden');
        document.getElementById('saveReservationLoading').classList.add('hidden');
    }
});

document.getElementById('newUserForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const formData = {
        name: document.getElementById('userName').value,
        email: document.getElementById('userEmail').value,
        role: document.getElementById('userRole').value
    };
    
    // Mostrar loading
    document.getElementById('saveUserText').classList.add('hidden');
    document.getElementById('saveUserLoading').classList.remove('hidden');
    
    try {
        await apiCall('/users/', {
            method: 'POST',
            body: JSON.stringify(formData)
        });
        
        showAlert('Usuário criado com sucesso! Email enviado para definir senha.', 'success');
        closeModal('newUserModal');
        document.getElementById('newUserForm').reset();
        
        // Atualizar lista de usuários
        loadUsers();
    } catch (error) {
        showAlert(error.message, 'error');
    } finally {
        // Esconder loading
        document.getElementById('saveUserText').classList.remove('hidden');
        document.getElementById('saveUserLoading').classList.add('hidden');
    }
});

document.getElementById('newRoomForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const equipment = document.getElementById('roomEquipment').value;
    const equipmentArray = equipment ? equipment.split(',').map(item => item.trim()).filter(item => item) : [];
    
    const formData = {
        name: document.getElementById('roomName').value,
        description: document.getElementById('roomDescription').value,
        capacity: parseInt(document.getElementById('roomCapacity').value),
        location: document.getElementById('roomLocation').value,
        equipment: JSON.stringify(equipmentArray)
    };
    
    // Mostrar loading
    document.getElementById('saveRoomText').classList.add('hidden');
    document.getElementById('saveRoomLoading').classList.remove('hidden');
    
    try {
        await apiCall('/rooms/', {
            method: 'POST',
            body: JSON.stringify(formData)
        });
        
        showAlert('Sala criada com sucesso!', 'success');
        closeModal('newRoomModal');
        document.getElementById('newRoomForm').reset();
        
        // Atualizar lista de salas
        await loadRooms();
    } catch (error) {
        showAlert(error.message, 'error');
    } finally {
        // Esconder loading
        document.getElementById('saveRoomText').classList.remove('hidden');
        document.getElementById('saveRoomLoading').classList.add('hidden');
    }
});

// Action Functions
async function cancelReservation(reservationId) {
    if (!confirm('Tem certeza que deseja cancelar esta reserva?')) {
        return;
    }
    
    try {
        await apiCall(`/reservations/${reservationId}`, {
            method: 'DELETE'
        });
        
        showAlert('Reserva cancelada com sucesso!', 'success');
        loadMyReservations();
        
        if (calendar) {
            calendar.refetchEvents();
        }
    } catch (error) {
        showAlert(error.message, 'error');
    }
}

async function resetUserPassword(userId) {
    if (!confirm('Tem certeza que deseja resetar a senha deste usuário?')) {
        return;
    }
    
    try {
        await apiCall(`/users/${userId}/reset-password`, {
            method: 'POST'
        });
        
        showAlert('Email de reset de senha enviado!', 'success');
    } catch (error) {
        showAlert(error.message, 'error');
    }
}

async function deleteUser(userId) {
    if (!confirm('Tem certeza que deseja excluir este usuário?')) {
        return;
    }
    
    try {
        await apiCall(`/users/${userId}`, {
            method: 'DELETE'
        });
        
        showAlert('Usuário excluído com sucesso!', 'success');
        loadUsers();
    } catch (error) {
        showAlert(error.message, 'error');
    }
}

async function deleteRoom(roomId) {
    if (!confirm('Tem certeza que deseja excluir esta sala?')) {
        return;
    }
    
    try {
        await apiCall(`/rooms/${roomId}`, {
            method: 'DELETE'
        });
        
        showAlert('Sala excluída com sucesso!', 'success');
        await loadRooms();
    } catch (error) {
        showAlert(error.message, 'error');
    }
}

// Placeholder functions for edit operations
function editReservation(reservationId) {
    showAlert('Funcionalidade de edição em desenvolvimento', 'info');
}

function editRoom(roomId) {
    showAlert('Funcionalidade de edição em desenvolvimento', 'info');
}

// Initialize app on page load
document.addEventListener('DOMContentLoaded', () => {
    if (!checkAuth()) {
        document.getElementById('loginContainer').style.display = 'flex';
        document.getElementById('mainApp').style.display = 'none';
    }
});

// Close modals when clicking outside
document.addEventListener('click', (e) => {
    if (e.target.classList.contains('modal')) {
        e.target.classList.remove('show');
    }
});

