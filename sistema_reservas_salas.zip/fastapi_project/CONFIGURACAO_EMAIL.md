# Configuração de Email SMTP

Este guia explica como configurar o envio de emails no Sistema de Reservas de Salas.

## 📧 Configuração Básica

### 1. Variáveis de Ambiente (Recomendado)

Crie um arquivo `.env` na raiz do projeto:

```env
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USERNAME=seu_email@gmail.com
SMTP_PASSWORD=sua_senha_app
SMTP_USE_TLS=true
FROM_EMAIL=seu_email@gmail.com
FROM_NAME=Sistema de Reservas
```

### 2. Configuração Direta no Código

Edite o arquivo `email_service.py` e altere as variáveis:

```python
SMTP_HOST = "smtp.gmail.com"
SMTP_PORT = 587
SMTP_USERNAME = "seu_email@gmail.com"
SMTP_PASSWORD = "sua_senha_app"
FROM_EMAIL = "seu_email@gmail.com"
FROM_NAME = "Sistema de Reservas"
```

## 🔧 Configuração por Provedor

### Gmail
```env
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USE_TLS=true
```

**Importante**: Use uma "Senha de App" do Gmail, não sua senha normal.

#### Como criar uma Senha de App no Gmail:
1. Acesse sua conta Google
2. Vá em "Segurança"
3. Ative a "Verificação em duas etapas"
4. Gere uma "Senha de app"
5. Use essa senha no campo SMTP_PASSWORD

### Outlook/Hotmail
```env
SMTP_HOST=smtp-mail.outlook.com
SMTP_PORT=587
SMTP_USE_TLS=true
```

### Yahoo
```env
SMTP_HOST=smtp.mail.yahoo.com
SMTP_PORT=587
SMTP_USE_TLS=true
```

### Provedor Personalizado
```env
SMTP_HOST=mail.seudominio.com
SMTP_PORT=587
SMTP_USE_TLS=true
SMTP_USERNAME=noreply@seudominio.com
SMTP_PASSWORD=sua_senha
```

## 📨 Tipos de Email Enviados

### 1. Email de Definição de Senha
- **Quando**: Novo usuário é criado pelo admin
- **Conteúdo**: Link para definir senha + token de segurança
- **Template**: HTML responsivo com instruções

### 2. Email de Confirmação de Reserva
- **Quando**: Reserva é criada com sucesso
- **Conteúdo**: Detalhes da reunião (título, sala, horário, localização)
- **Template**: HTML com design profissional

### 3. Email de Lembrete
- **Quando**: 30 minutos antes da reunião
- **Conteúdo**: Lembrete da reunião com detalhes
- **Template**: HTML com destaque para urgência

## 🧪 Testando a Configuração

### 1. Teste Manual
Execute este código Python para testar:

```python
import asyncio
from email_service import email_service

async def test_email():
    success = await email_service.send_email(
        to_email="seu_email_teste@gmail.com",
        subject="Teste do Sistema",
        html_content="<h1>Email funcionando!</h1>",
        text_content="Email funcionando!"
    )
    print(f"Email enviado: {success}")

# Execute o teste
asyncio.run(test_email())
```

### 2. Teste via Sistema
1. Crie um novo usuário no sistema
2. Verifique se o email de definição de senha foi enviado
3. Crie uma reserva e verifique o email de confirmação

## 🔒 Segurança

### Boas Práticas
- **Nunca** commite senhas no código
- Use variáveis de ambiente
- Use senhas de aplicativo quando disponível
- Configure TLS/SSL sempre que possível

### Exemplo de .env Seguro
```env
# Email Configuration
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USERNAME=sistema.reservas@empresa.com
SMTP_PASSWORD=abcd1234efgh5678  # Senha de app
SMTP_USE_TLS=true
FROM_EMAIL=sistema.reservas@empresa.com
FROM_NAME=Sistema de Reservas - Empresa XYZ
```

## 🚨 Solução de Problemas

### Erro: "Authentication failed"
- Verifique usuário e senha
- Para Gmail, use senha de aplicativo
- Verifique se 2FA está ativado

### Erro: "Connection refused"
- Verifique o host SMTP
- Verifique a porta (587 para TLS, 465 para SSL)
- Teste conectividade de rede

### Erro: "TLS required"
- Defina SMTP_USE_TLS=true
- Use porta 587 (TLS) ou 465 (SSL)

### Emails não chegam
- Verifique pasta de spam
- Verifique logs do sistema
- Teste com email diferente

## 📋 Logs de Email

O sistema registra todos os emails enviados na tabela `email_logs`:

```sql
SELECT * FROM email_logs ORDER BY sent_at DESC LIMIT 10;
```

Campos registrados:
- `recipient_email`: Email do destinatário
- `subject`: Assunto do email
- `email_type`: Tipo (password_reset, reservation_confirmation, reminder)
- `success`: Se foi enviado com sucesso
- `error_message`: Mensagem de erro (se houver)
- `sent_at`: Data/hora do envio

## 🔄 Configuração Avançada

### Personalizar Templates
Edite os templates HTML em `email_service.py`:

```python
html_template = Template("""
<!DOCTYPE html>
<html>
<head>
    <style>
        /* Seu CSS personalizado */
    </style>
</head>
<body>
    <!-- Seu HTML personalizado -->
</body>
</html>
""")
```

### Configurar Retry
Para emails que falharam, implemente retry:

```python
async def send_email_with_retry(self, to_email, subject, html_content, max_retries=3):
    for attempt in range(max_retries):
        try:
            success = await self.send_email(to_email, subject, html_content)
            if success:
                return True
        except Exception as e:
            if attempt == max_retries - 1:
                raise e
            await asyncio.sleep(2 ** attempt)  # Backoff exponencial
    return False
```

## 📞 Suporte

Se ainda tiver problemas:
1. Verifique os logs do sistema
2. Teste com um provedor diferente
3. Consulte a documentação do seu provedor SMTP
4. Verifique firewall e configurações de rede

---

**Nota**: Sempre teste a configuração de email em ambiente de desenvolvimento antes de usar em produção.

