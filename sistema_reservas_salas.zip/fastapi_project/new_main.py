from fastapi import FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import HTMLResponse, FileResponse
import uvicorn
import os
from contextlib import asynccontextmanager

# Importar configurações do banco de dados
from database import create_tables, init_db

# Importar routers
from routers.auth_router import router as auth_router
from routers.users_router import router as users_router
from routers.rooms_router import router as rooms_router
from routers.reservations_router import router as reservations_router

# Importar background tasks
from background_tasks import background_manager

@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup
    print("Iniciando aplicação...")
    
    # Criar tabelas do banco de dados
    create_tables()
    
    # Inicializar dados padrão
    init_db()
    
    # Iniciar background tasks
    await background_manager.start()
    
    yield
    
    # Shutdown
    print("Encerrando aplicação...")
    await background_manager.stop()

# Criar aplicação FastAPI
app = FastAPI(
    title="Sistema de Reservas de Salas",
    description="Sistema completo para reserva de salas de reuniões com autenticação, notificações e interface moderna",
    version="1.0.0",
    lifespan=lifespan
)

# Configurar CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Em produção, especifique os domínios permitidos
    allow_credentials=True,
    allow_methods=["GET", "POST", "PUT", "DELETE", "OPTIONS", "HEAD", "PATCH"],
    allow_headers=["*"],
)

# Incluir routers
app.include_router(auth_router)
app.include_router(users_router)
app.include_router(rooms_router)
app.include_router(reservations_router)

# Servir arquivos estáticos
if not os.path.exists("static"):
    os.makedirs("static")
app.mount("/static", StaticFiles(directory="static"), name="static")

# Endpoint raiz
@app.get("/")
async def root():
    """Endpoint raiz - redirecionar para a aplicação frontend"""
    return FileResponse("static/index.html")

# Endpoint de saúde
@app.get("/health")
async def health_check():
    """Endpoint de verificação de saúde"""
    return {
        "status": "healthy",
        "service": "Sistema de Reservas de Salas",
        "version": "1.0.0"
    }

# Endpoint para servir a página de definir senha
@app.get("/set-password", response_class=HTMLResponse)
async def set_password_page():
    """Página para definir senha"""
    return FileResponse("static/set-password.html")

if __name__ == "__main__":
    uvicorn.run(
        "new_main:app",
        host="0.0.0.0",
        port=8000,
        reload=True,
        log_level="info"
    )

