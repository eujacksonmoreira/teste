from typing import List
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from database import get_db
from models import User, Room
from schemas import RoomCreate, RoomUpdate, RoomResponse
from auth import get_current_admin_user, get_current_active_user

router = APIRouter(prefix="/rooms", tags=["Salas"])

@router.post("/", response_model=RoomResponse)
async def create_room(
    room: RoomCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_admin_user)
):
    """Criar nova sala (apenas admin)"""
    db_room = Room(**room.dict())
    db.add(db_room)
    db.commit()
    db.refresh(db_room)
    
    return RoomResponse.from_orm(db_room)

@router.get("/", response_model=List[RoomResponse])
async def read_rooms(
    skip: int = 0,
    limit: int = 100,
    active_only: bool = True,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """Listar salas"""
    query = db.query(Room)
    
    if active_only:
        query = query.filter(Room.is_active == True)
    
    rooms = query.offset(skip).limit(limit).all()
    return [RoomResponse.from_orm(room) for room in rooms]

@router.get("/{room_id}", response_model=RoomResponse)
async def read_room(
    room_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """Obter sala por ID"""
    room = db.query(Room).filter(Room.id == room_id).first()
    if room is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Sala não encontrada"
        )
    
    return RoomResponse.from_orm(room)

@router.put("/{room_id}", response_model=RoomResponse)
async def update_room(
    room_id: int,
    room_update: RoomUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_admin_user)
):
    """Atualizar sala (apenas admin)"""
    room = db.query(Room).filter(Room.id == room_id).first()
    if room is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Sala não encontrada"
        )
    
    # Atualizar campos
    update_data = room_update.dict(exclude_unset=True)
    for field, value in update_data.items():
        setattr(room, field, value)
    
    db.commit()
    db.refresh(room)
    
    return RoomResponse.from_orm(room)

@router.delete("/{room_id}")
async def delete_room(
    room_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_admin_user)
):
    """Deletar sala (apenas admin)"""
    room = db.query(Room).filter(Room.id == room_id).first()
    if room is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Sala não encontrada"
        )
    
    # Verificar se há reservas ativas para esta sala
    from models import Reservation
    from datetime import datetime
    
    active_reservations = db.query(Reservation).filter(
        Reservation.room_id == room_id,
        Reservation.end_time > datetime.utcnow(),
        Reservation.is_cancelled == False
    ).count()
    
    if active_reservations > 0:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Não é possível deletar sala com reservas ativas"
        )
    
    db.delete(room)
    db.commit()
    
    return {"message": "Sala deletada com sucesso"}

