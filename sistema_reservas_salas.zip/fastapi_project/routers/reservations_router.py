from typing import List, Optional
from datetime import datetime, timedelta
from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.orm import Session
from sqlalchemy import and_, or_

from database import get_db
from models import User, Room, Reservation
from schemas import (
    ReservationCreate, 
    ReservationUpdate, 
    ReservationResponse, 
    ReservationPublicResponse,
    CalendarEvent
)
from auth import get_current_active_user, check_reservation_permission

router = APIRouter(prefix="/reservations", tags=["Reservas"])

def check_room_availability(
    db: Session, 
    room_id: int, 
    start_time: datetime, 
    end_time: datetime,
    exclude_reservation_id: Optional[int] = None
) -> bool:
    """Verificar se a sala está disponível no horário solicitado"""
    query = db.query(Reservation).filter(
        Reservation.room_id == room_id,
        Reservation.is_cancelled == False,
        or_(
            and_(
                Reservation.start_time <= start_time,
                Reservation.end_time > start_time
            ),
            and_(
                Reservation.start_time < end_time,
                Reservation.end_time >= end_time
            ),
            and_(
                Reservation.start_time >= start_time,
                Reservation.end_time <= end_time
            )
        )
    )
    
    if exclude_reservation_id:
        query = query.filter(Reservation.id != exclude_reservation_id)
    
    conflicting_reservations = query.count()
    return conflicting_reservations == 0

@router.post("/", response_model=ReservationResponse)
async def create_reservation(
    reservation: ReservationCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """Criar nova reserva"""
    # Verificar se a sala existe
    room = db.query(Room).filter(Room.id == reservation.room_id).first()
    if not room:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Sala não encontrada"
        )
    
    if not room.is_active:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Sala não está ativa"
        )
    
    # Verificar se o horário é no futuro
    if reservation.start_time <= datetime.utcnow():
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Horário de início deve ser no futuro"
        )
    
    # Verificar disponibilidade da sala
    if not check_room_availability(db, reservation.room_id, reservation.start_time, reservation.end_time):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Sala não está disponível no horário solicitado"
        )
    
    # Criar reserva
    db_reservation = Reservation(
        user_id=current_user.id,
        **reservation.dict()
    )
    
    db.add(db_reservation)
    db.commit()
    db.refresh(db_reservation)
    
    # Carregar dados relacionados para resposta
    db_reservation.user_name = current_user.name
    db_reservation.room_name = room.name
    
    return ReservationResponse(
        id=db_reservation.id,
        user_id=db_reservation.user_id,
        room_id=db_reservation.room_id,
        title=db_reservation.title,
        description=db_reservation.description,
        start_time=db_reservation.start_time,
        end_time=db_reservation.end_time,
        is_cancelled=db_reservation.is_cancelled,
        created_at=db_reservation.created_at,
        updated_at=db_reservation.updated_at,
        user_name=current_user.name,
        room_name=room.name
    )

@router.get("/", response_model=List[ReservationResponse])
async def read_my_reservations(
    skip: int = 0,
    limit: int = 100,
    include_past: bool = False,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """Listar minhas reservas"""
    query = db.query(Reservation).filter(Reservation.user_id == current_user.id)
    
    if not include_past:
        query = query.filter(Reservation.end_time > datetime.utcnow())
    
    reservations = query.offset(skip).limit(limit).all()
    
    # Carregar dados relacionados
    result = []
    for reservation in reservations:
        user = db.query(User).filter(User.id == reservation.user_id).first()
        room = db.query(Room).filter(Room.id == reservation.room_id).first()
        
        result.append(ReservationResponse(
            id=reservation.id,
            user_id=reservation.user_id,
            room_id=reservation.room_id,
            title=reservation.title,
            description=reservation.description,
            start_time=reservation.start_time,
            end_time=reservation.end_time,
            is_cancelled=reservation.is_cancelled,
            created_at=reservation.created_at,
            updated_at=reservation.updated_at,
            user_name=user.name if user else "Usuário não encontrado",
            room_name=room.name if room else "Sala não encontrada"
        ))
    
    return result

@router.get("/public", response_model=List[ReservationPublicResponse])
async def read_public_reservations(
    room_id: Optional[int] = Query(None),
    start_date: Optional[datetime] = Query(None),
    end_date: Optional[datetime] = Query(None),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """Listar reservas públicas (apenas quem reservou e horário)"""
    query = db.query(Reservation).filter(Reservation.is_cancelled == False)
    
    if room_id:
        query = query.filter(Reservation.room_id == room_id)
    
    if start_date:
        query = query.filter(Reservation.end_time >= start_date)
    
    if end_date:
        query = query.filter(Reservation.start_time <= end_date)
    
    reservations = query.all()
    
    # Carregar dados relacionados
    result = []
    for reservation in reservations:
        user = db.query(User).filter(User.id == reservation.user_id).first()
        room = db.query(Room).filter(Room.id == reservation.room_id).first()
        
        result.append(ReservationPublicResponse(
            id=reservation.id,
            room_id=reservation.room_id,
            start_time=reservation.start_time,
            end_time=reservation.end_time,
            user_name=user.name if user else "Usuário não encontrado",
            room_name=room.name if room else "Sala não encontrada"
        ))
    
    return result

@router.get("/calendar", response_model=List[CalendarEvent])
async def get_calendar_events(
    start_date: datetime = Query(...),
    end_date: datetime = Query(...),
    room_id: Optional[int] = Query(None),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """Obter eventos para o calendário (estilo Outlook)"""
    query = db.query(Reservation).filter(
        Reservation.is_cancelled == False,
        Reservation.start_time <= end_date,
        Reservation.end_time >= start_date
    )
    
    if room_id:
        query = query.filter(Reservation.room_id == room_id)
    
    reservations = query.all()
    
    # Converter para eventos do calendário
    events = []
    for reservation in reservations:
        user = db.query(User).filter(User.id == reservation.user_id).first()
        room = db.query(Room).filter(Room.id == reservation.room_id).first()
        
        # Determinar se é própria reserva
        is_own = reservation.user_id == current_user.id
        
        # Título: se for própria reserva, mostrar título completo, senão apenas "Reservado"
        title = reservation.title if is_own else "Reservado"
        
        events.append(CalendarEvent(
            id=reservation.id,
            title=title,
            start=reservation.start_time,
            end=reservation.end_time,
            room_name=room.name if room else "Sala não encontrada",
            user_name=user.name if user else "Usuário não encontrado",
            is_own=is_own
        ))
    
    return events

@router.get("/{reservation_id}", response_model=ReservationResponse)
async def read_reservation(
    reservation_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """Obter reserva por ID"""
    reservation = db.query(Reservation).filter(Reservation.id == reservation_id).first()
    if not reservation:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Reserva não encontrada"
        )
    
    # Verificar permissão
    if not check_reservation_permission(current_user, reservation.user_id):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Acesso negado"
        )
    
    # Carregar dados relacionados
    user = db.query(User).filter(User.id == reservation.user_id).first()
    room = db.query(Room).filter(Room.id == reservation.room_id).first()
    
    return ReservationResponse(
        id=reservation.id,
        user_id=reservation.user_id,
        room_id=reservation.room_id,
        title=reservation.title,
        description=reservation.description,
        start_time=reservation.start_time,
        end_time=reservation.end_time,
        is_cancelled=reservation.is_cancelled,
        created_at=reservation.created_at,
        updated_at=reservation.updated_at,
        user_name=user.name if user else "Usuário não encontrado",
        room_name=room.name if room else "Sala não encontrada"
    )

@router.put("/{reservation_id}", response_model=ReservationResponse)
async def update_reservation(
    reservation_id: int,
    reservation_update: ReservationUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """Atualizar reserva"""
    reservation = db.query(Reservation).filter(Reservation.id == reservation_id).first()
    if not reservation:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Reserva não encontrada"
        )
    
    # Verificar permissão
    if not check_reservation_permission(current_user, reservation.user_id):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Acesso negado"
        )
    
    # Verificar se a reserva já passou
    if reservation.start_time <= datetime.utcnow():
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Não é possível alterar reserva que já iniciou"
        )
    
    # Atualizar campos
    update_data = reservation_update.dict(exclude_unset=True)
    
    # Se alterando horário, verificar disponibilidade
    if 'start_time' in update_data or 'end_time' in update_data:
        new_start = update_data.get('start_time', reservation.start_time)
        new_end = update_data.get('end_time', reservation.end_time)
        
        if new_start <= datetime.utcnow():
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Horário de início deve ser no futuro"
            )
        
        if not check_room_availability(db, reservation.room_id, new_start, new_end, reservation.id):
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Sala não está disponível no novo horário"
            )
    
    for field, value in update_data.items():
        setattr(reservation, field, value)
    
    db.commit()
    db.refresh(reservation)
    
    # Carregar dados relacionados
    user = db.query(User).filter(User.id == reservation.user_id).first()
    room = db.query(Room).filter(Room.id == reservation.room_id).first()
    
    return ReservationResponse(
        id=reservation.id,
        user_id=reservation.user_id,
        room_id=reservation.room_id,
        title=reservation.title,
        description=reservation.description,
        start_time=reservation.start_time,
        end_time=reservation.end_time,
        is_cancelled=reservation.is_cancelled,
        created_at=reservation.created_at,
        updated_at=reservation.updated_at,
        user_name=user.name if user else "Usuário não encontrado",
        room_name=room.name if room else "Sala não encontrada"
    )

@router.delete("/{reservation_id}")
async def cancel_reservation(
    reservation_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """Cancelar reserva"""
    reservation = db.query(Reservation).filter(Reservation.id == reservation_id).first()
    if not reservation:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Reserva não encontrada"
        )
    
    # Verificar permissão
    if not check_reservation_permission(current_user, reservation.user_id):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Acesso negado"
        )
    
    # Marcar como cancelada ao invés de deletar
    reservation.is_cancelled = True
    db.commit()
    
    return {"message": "Reserva cancelada com sucesso"}

@router.get("/room/{room_id}/availability")
async def check_room_availability_endpoint(
    room_id: int,
    start_time: datetime = Query(...),
    end_time: datetime = Query(...),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """Verificar disponibilidade de uma sala"""
    # Verificar se a sala existe
    room = db.query(Room).filter(Room.id == room_id).first()
    if not room:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Sala não encontrada"
        )
    
    is_available = check_room_availability(db, room_id, start_time, end_time)
    
    return {
        "room_id": room_id,
        "room_name": room.name,
        "start_time": start_time,
        "end_time": end_time,
        "is_available": is_available
    }

