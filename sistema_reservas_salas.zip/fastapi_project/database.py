from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.ext.declarative import declarative_base
import os

# URL do banco de dados SQLite
SQLALCHEMY_DATABASE_URL = "sqlite:///./meeting_rooms.db"

# Criar engine do SQLAlchemy
engine = create_engine(
    SQLALCHEMY_DATABASE_URL, 
    connect_args={"check_same_thread": False}  # Necessário para SQLite
)

# Criar SessionLocal class
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

# Base para os modelos
Base = declarative_base()

# Dependency para obter sessão do banco de dados
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

# Função para criar todas as tabelas
def create_tables():
    from models import Base
    Base.metadata.create_all(bind=engine)

# Função para inicializar o banco com dados padrão
def init_db():
    from models import User, Room, UserRole
    from sqlalchemy.orm import Session
    from passlib.context import CryptContext
    
    # Configurar hash de senha
    pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
    
    db = SessionLocal()
    try:
        # Verificar se já existe um usuário admin
        admin_user = db.query(User).filter(User.role == UserRole.ADMIN).first()
        
        if not admin_user:
            # Criar usuário admin padrão
            admin_user = User(
                email="admin@empresa.com",
                name="Administrador",
                hashed_password=pwd_context.hash("admin123"),  # Senha padrão - deve ser alterada
                role=UserRole.ADMIN,
                is_active=True
            )
            db.add(admin_user)
        
        # Verificar se já existem salas
        existing_rooms = db.query(Room).count()
        
        if existing_rooms == 0:
            # Criar salas padrão
            default_rooms = [
                Room(
                    name="Sala de Reunião 1",
                    description="Sala principal para reuniões executivas",
                    capacity=10,
                    location="1º Andar",
                    equipment='["Projetor", "TV 55\"", "Sistema de áudio", "Videoconferência"]',
                    is_active=True
                ),
                Room(
                    name="Sala de Reunião 2",
                    description="Sala para reuniões de equipe",
                    capacity=6,
                    location="1º Andar",
                    equipment='["TV 42\"", "Sistema de áudio"]',
                    is_active=True
                ),
                Room(
                    name="Sala de Treinamento",
                    description="Sala ampla para treinamentos e workshops",
                    capacity=20,
                    location="2º Andar",
                    equipment='["Projetor", "Sistema de som", "Flipchart", "Videoconferência"]',
                    is_active=True
                ),
                Room(
                    name="Sala de Videoconferência",
                    description="Sala especializada para reuniões remotas",
                    capacity=8,
                    location="2º Andar",
                    equipment='["Sistema de videoconferência avançado", "TV 65\"", "Microfones direcionais"]',
                    is_active=True
                )
            ]
            
            for room in default_rooms:
                db.add(room)
        
        db.commit()
        print("Banco de dados inicializado com sucesso!")
        print("Usuário admin padrão: admin@empresa.com / admin123")
        
    except Exception as e:
        print(f"Erro ao inicializar banco de dados: {e}")
        db.rollback()
    finally:
        db.close()

