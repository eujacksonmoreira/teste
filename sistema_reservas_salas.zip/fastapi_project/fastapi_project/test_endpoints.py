from fastapi import APIRouter, HTTPException, Query, Path, Body
from pydantic import BaseModel
from typing import Optional, List
import asyncio
import random
from datetime import datetime
import json

# Router para endpoints de teste
test_router = APIRouter(prefix="/test", tags=["Testes"])

# Modelos Pydantic para validação de dados
class UserModel(BaseModel):
    name: str
    email: str
    age: Optional[int] = None

class ResponseModel(BaseModel):
    success: bool
    message: str
    data: Optional[dict] = None
    timestamp: str

# Simulação de banco de dados em memória
fake_users_db = []

@test_router.get("/", response_model=ResponseModel)
async def test_root():
    """Endpoint raiz de teste"""
    return ResponseModel(
        success=True,
        message="Endpoints de teste funcionando!",
        timestamp=datetime.now().isoformat()
    )

@test_router.get("/fast", response_model=ResponseModel)
async def test_fast_endpoint():
    """Endpoint de teste rápido (< 100ms)"""
    return ResponseModel(
        success=True,
        message="Resposta rápida",
        data={"response_time": "fast", "delay_ms": 0},
        timestamp=datetime.now().isoformat()
    )

@test_router.get("/slow", response_model=ResponseModel)
async def test_slow_endpoint():
    """Endpoint de teste lento (2-3 segundos)"""
    delay = random.uniform(2, 3)
    await asyncio.sleep(delay)
    return ResponseModel(
        success=True,
        message="Resposta lenta",
        data={"response_time": "slow", "delay_ms": delay * 1000},
        timestamp=datetime.now().isoformat()
    )

@test_router.get("/random-delay", response_model=ResponseModel)
async def test_random_delay():
    """Endpoint com delay aleatório (0.1 a 2 segundos)"""
    delay = random.uniform(0.1, 2)
    await asyncio.sleep(delay)
    return ResponseModel(
        success=True,
        message=f"Resposta com delay aleatório de {delay:.2f}s",
        data={"delay_seconds": delay},
        timestamp=datetime.now().isoformat()
    )

@test_router.get("/error/{error_code}")
async def test_error_endpoint(error_code: int = Path(..., ge=400, le=599)):
    """Endpoint que simula diferentes códigos de erro HTTP"""
    error_messages = {
        400: "Bad Request - Requisição inválida",
        401: "Unauthorized - Não autorizado",
        403: "Forbidden - Acesso negado",
        404: "Not Found - Recurso não encontrado",
        500: "Internal Server Error - Erro interno do servidor",
        502: "Bad Gateway - Gateway inválido",
        503: "Service Unavailable - Serviço indisponível"
    }
    
    message = error_messages.get(error_code, f"Erro HTTP {error_code}")
    raise HTTPException(status_code=error_code, detail=message)

@test_router.get("/success-rate/{rate}")
async def test_success_rate(rate: int = Path(..., ge=0, le=100)):
    """Endpoint que falha baseado em uma taxa de sucesso (0-100%)"""
    if random.randint(1, 100) <= rate:
        return ResponseModel(
            success=True,
            message=f"Sucesso! Taxa configurada: {rate}%",
            data={"success_rate": rate},
            timestamp=datetime.now().isoformat()
        )
    else:
        raise HTTPException(
            status_code=500, 
            detail=f"Falha simulada. Taxa de sucesso: {rate}%"
        )

@test_router.post("/users", response_model=ResponseModel)
async def create_user(user: UserModel):
    """Endpoint para criar usuário (teste de POST)"""
    user_dict = user.dict()
    user_dict["id"] = len(fake_users_db) + 1
    user_dict["created_at"] = datetime.now().isoformat()
    
    fake_users_db.append(user_dict)
    
    return ResponseModel(
        success=True,
        message="Usuário criado com sucesso",
        data=user_dict,
        timestamp=datetime.now().isoformat()
    )

@test_router.get("/users", response_model=ResponseModel)
async def get_users(limit: int = Query(10, ge=1, le=100)):
    """Endpoint para listar usuários (teste de GET com query params)"""
    return ResponseModel(
        success=True,
        message=f"Lista de usuários (limite: {limit})",
        data={"users": fake_users_db[:limit], "total": len(fake_users_db)},
        timestamp=datetime.now().isoformat()
    )

@test_router.get("/users/{user_id}", response_model=ResponseModel)
async def get_user(user_id: int = Path(..., ge=1)):
    """Endpoint para buscar usuário por ID (teste de path params)"""
    user = next((u for u in fake_users_db if u["id"] == user_id), None)
    
    if not user:
        raise HTTPException(status_code=404, detail="Usuário não encontrado")
    
    return ResponseModel(
        success=True,
        message="Usuário encontrado",
        data=user,
        timestamp=datetime.now().isoformat()
    )

@test_router.put("/users/{user_id}", response_model=ResponseModel)
async def update_user(user_id: int, user_update: UserModel):
    """Endpoint para atualizar usuário (teste de PUT)"""
    user_index = next((i for i, u in enumerate(fake_users_db) if u["id"] == user_id), None)
    
    if user_index is None:
        raise HTTPException(status_code=404, detail="Usuário não encontrado")
    
    fake_users_db[user_index].update(user_update.dict())
    fake_users_db[user_index]["updated_at"] = datetime.now().isoformat()
    
    return ResponseModel(
        success=True,
        message="Usuário atualizado com sucesso",
        data=fake_users_db[user_index],
        timestamp=datetime.now().isoformat()
    )

@test_router.delete("/users/{user_id}", response_model=ResponseModel)
async def delete_user(user_id: int):
    """Endpoint para deletar usuário (teste de DELETE)"""
    user_index = next((i for i, u in enumerate(fake_users_db) if u["id"] == user_id), None)
    
    if user_index is None:
        raise HTTPException(status_code=404, detail="Usuário não encontrado")
    
    deleted_user = fake_users_db.pop(user_index)
    
    return ResponseModel(
        success=True,
        message="Usuário deletado com sucesso",
        data=deleted_user,
        timestamp=datetime.now().isoformat()
    )

@test_router.get("/load-test/{requests_count}")
async def load_test_endpoint(requests_count: int = Path(..., ge=1, le=1000)):
    """Endpoint para teste de carga - simula processamento de múltiplas requisições"""
    start_time = datetime.now()
    
    # Simula processamento de múltiplas operações
    for i in range(requests_count):
        await asyncio.sleep(0.001)  # 1ms por operação
    
    end_time = datetime.now()
    processing_time = (end_time - start_time).total_seconds()
    
    return ResponseModel(
        success=True,
        message=f"Processadas {requests_count} operações",
        data={
            "requests_processed": requests_count,
            "processing_time_seconds": processing_time,
            "operations_per_second": requests_count / processing_time if processing_time > 0 else 0
        },
        timestamp=datetime.now().isoformat()
    )

@test_router.get("/memory-usage")
async def memory_usage_test():
    """Endpoint que simula uso de memória"""
    import psutil
    import os
    
    process = psutil.Process(os.getpid())
    memory_info = process.memory_info()
    
    return ResponseModel(
        success=True,
        message="Informações de uso de memória",
        data={
            "memory_rss_mb": memory_info.rss / 1024 / 1024,
            "memory_vms_mb": memory_info.vms / 1024 / 1024,
            "cpu_percent": process.cpu_percent()
        },
        timestamp=datetime.now().isoformat()
    )

