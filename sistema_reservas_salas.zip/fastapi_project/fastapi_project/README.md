# API FastAPI com Monitoramento em Tempo Real

Esta é uma estrutura completa de API desenvolvida com FastAPI e Uvicorn, incluindo sistema de monitoramento em tempo real, endpoints de teste, configuração CORS e scripts de controle.

## 🚀 Características

- **API RESTful** com FastAPI
- **Monitoramento em tempo real** com dashboard web
- **Endpoints de teste** para validação e carga
- **Configuração CORS** completa
- **Scripts de controle** (.bat e .sh)
- **Configuração Nginx** para proxy reverso
- **Sistema de métricas** com histórico de requisições

## 📋 Pré-requisitos

- Python 3.7+
- pip (gerenciador de pacotes Python)
- Nginx (opcional, para proxy reverso)

## 🛠️ Instalação

1. **Clone ou baixe o projeto**
2. **Instale as dependências:**
   ```bash
   pip install -r requirements.txt
   ```

## 🎯 Como Usar

### Iniciar a API

**Linux/Mac:**
```bash
chmod +x start.sh
./start.sh
```

**Windows:**
```cmd
start.bat
```

**Manual:**
```bash
uvicorn main:app --host 0.0.0.0 --port 8000 --reload
```

### Parar a API

**Linux/Mac:**
```bash
./stop.sh
```

**Windows:**
```cmd
stop.bat
```

### Acessar a API

- **API Base:** http://localhost:8000
- **Documentação Swagger:** http://localhost:8000/docs
- **Dashboard de Monitoramento:** http://localhost:8000/monitor/dashboard
- **Verificação de Saúde:** http://localhost:8000/health

## 📊 Dashboard de Monitoramento

O dashboard fornece uma visão em tempo real da API com:

- **Estatísticas Gerais:**
  - Total de requisições
  - Taxa de erro
  - Tempo médio de resposta
  - Tempo de atividade (uptime)

- **Gráficos em Tempo Real:**
  - Requisições por minuto
  - Tempo de resposta ao longo do tempo

- **Tabela de Endpoints:**
  - Estatísticas detalhadas por endpoint
  - Contadores de requisições e erros
  - Tempos médios de resposta

## 🧪 Endpoints de Teste

A API inclui vários endpoints para teste e validação:

### Básicos
- `GET /test/` - Endpoint raiz de teste
- `GET /test/fast` - Resposta rápida (< 100ms)
- `GET /test/slow` - Resposta lenta (2-3 segundos)
- `GET /test/random-delay` - Delay aleatório (0.1-2s)

### Simulação de Erros
- `GET /test/error/{error_code}` - Simula códigos de erro HTTP
- `GET /test/success-rate/{rate}` - Falha baseado em taxa de sucesso

### CRUD de Usuários
- `POST /test/users` - Criar usuário
- `GET /test/users` - Listar usuários
- `GET /test/users/{user_id}` - Buscar usuário por ID
- `PUT /test/users/{user_id}` - Atualizar usuário
- `DELETE /test/users/{user_id}` - Deletar usuário

### Performance
- `GET /test/load-test/{requests_count}` - Teste de carga
- `GET /test/memory-usage` - Informações de uso de memória

## 📈 Endpoints de Monitoramento

- `GET /monitor/stats` - Estatísticas gerais da API
- `GET /monitor/endpoints` - Estatísticas por endpoint
- `GET /monitor/history` - Histórico de requisições
- `GET /monitor/dashboard` - Dashboard web

## 🌐 Configuração Nginx

O arquivo `nginx.conf` inclui configuração para proxy reverso:

```bash
# Copiar configuração
sudo cp nginx.conf /etc/nginx/nginx.conf

# Testar configuração
sudo nginx -t

# Reiniciar Nginx
sudo systemctl restart nginx
```

## 🔧 Configuração CORS

A API está configurada para aceitar requisições de qualquer origem durante desenvolvimento. Para produção, modifique o arquivo `main.py`:

```python
app.add_middleware(
    CORSMiddleware,
    allow_origins=["https://seudominio.com"],  # Especificar domínios
    allow_credentials=True,
    allow_methods=["GET", "POST", "PUT", "DELETE"],
    allow_headers=["*"],
)
```

## 📁 Estrutura do Projeto

```
fastapi_project/
├── main.py              # Aplicação principal
├── test_endpoints.py    # Endpoints de teste
├── requirements.txt     # Dependências Python
├── start.sh            # Script de inicialização (Linux/Mac)
├── stop.sh             # Script de parada (Linux/Mac)
├── start.bat           # Script de inicialização (Windows)
├── stop.bat            # Script de parada (Windows)
├── nginx.conf          # Configuração Nginx
├── static/             # Arquivos estáticos
│   └── dashboard.html  # Dashboard de monitoramento
└── README.md           # Esta documentação
```

## 🔍 Monitoramento e Métricas

O sistema de monitoramento coleta automaticamente:

- **Contadores de requisições** por endpoint
- **Tempos de resposta** (últimos 100 por endpoint)
- **Códigos de status** e contagem de erros
- **Histórico de requisições** (últimas 1000)
- **Tempo de atividade** da API

## 🚀 Deployment

### Desenvolvimento
```bash
uvicorn main:app --host 0.0.0.0 --port 8000 --reload
```

### Produção
```bash
uvicorn main:app --host 0.0.0.0 --port 8000 --workers 4
```

### Com Gunicorn
```bash
pip install gunicorn
gunicorn main:app -w 4 -k uvicorn.workers.UvicornWorker --bind 0.0.0.0:8000
```

## 🛡️ Segurança

Para produção, considere:

1. **Configurar CORS** com domínios específicos
2. **Usar HTTPS** com certificados SSL
3. **Implementar autenticação** e autorização
4. **Configurar rate limiting**
5. **Usar variáveis de ambiente** para configurações sensíveis

## 📝 Logs

Os logs da aplicação são exibidos no console. Para produção, configure logging para arquivos:

```python
import logging
logging.basicConfig(level=logging.INFO, filename='api.log')
```

## 🤝 Contribuição

1. Faça um fork do projeto
2. Crie uma branch para sua feature
3. Commit suas mudanças
4. Push para a branch
5. Abra um Pull Request

## 📄 Licença

Este projeto está sob a licença MIT. Veja o arquivo LICENSE para mais detalhes.

## 🆘 Suporte

Para dúvidas ou problemas:

1. Verifique os logs da aplicação
2. Teste os endpoints básicos
3. Verifique se todas as dependências estão instaladas
4. Consulte a documentação do FastAPI: https://fastapi.tiangolo.com/

---

**Desenvolvido com ❤️ usando FastAPI**

