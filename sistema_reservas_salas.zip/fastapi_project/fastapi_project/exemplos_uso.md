# Exemplos de Uso da API FastAPI

## 🚀 Iniciando a API

### Linux/Mac
```bash
./start.sh
```

### Windows
```cmd
start.bat
```

### Manual
```bash
uvicorn main:app --host 0.0.0.0 --port 8000 --reload
```

## 📊 Acessando o Dashboard

Após iniciar a API, acesse: http://localhost:8000/monitor/dashboard

O dashboard mostra:
- **Total de requisições** realizadas
- **Taxa de erro** em percentual
- **Tempo médio de resposta** em milissegundos
- **Tempo online** da API
- **Gráficos em tempo real** de requisições e tempo de resposta
- **Tabela detalhada** com estatísticas por endpoint

## 🧪 Testando Endpoints

### 1. Verificação de Saúde
```bash
curl http://localhost:8000/health
```

### 2. Endpoint Rápido
```bash
curl http://localhost:8000/test/fast
```

### 3. Endpoint Lento (2-3 segundos)
```bash
curl http://localhost:8000/test/slow
```

### 4. Simulação de Erro
```bash
curl http://localhost:8000/test/error/404
curl http://localhost:8000/test/error/500
```

### 5. Teste de Taxa de Sucesso (70% de sucesso)
```bash
curl http://localhost:8000/test/success-rate/70
```

### 6. Criar Usuário (POST)
```bash
curl -X POST http://localhost:8000/test/users \
  -H "Content-Type: application/json" \
  -d '{"name":"João Silva","email":"joao@exemplo.com","age":30}'
```

### 7. Listar Usuários
```bash
curl http://localhost:8000/test/users
```

### 8. Buscar Usuário por ID
```bash
curl http://localhost:8000/test/users/1
```

### 9. Atualizar Usuário
```bash
curl -X PUT http://localhost:8000/test/users/1 \
  -H "Content-Type: application/json" \
  -d '{"name":"João Santos","email":"joao.santos@exemplo.com","age":31}'
```

### 10. Deletar Usuário
```bash
curl -X DELETE http://localhost:8000/test/users/1
```

### 11. Teste de Carga (simula 100 operações)
```bash
curl http://localhost:8000/test/load-test/100
```

### 12. Informações de Memória
```bash
curl http://localhost:8000/test/memory-usage
```

## 📈 Endpoints de Monitoramento

### Estatísticas Gerais
```bash
curl http://localhost:8000/monitor/stats
```

### Estatísticas por Endpoint
```bash
curl http://localhost:8000/monitor/endpoints
```

### Histórico de Requisições (últimas 50)
```bash
curl http://localhost:8000/monitor/history?limit=50
```

## 🔄 Gerando Dados para Monitoramento

Para popular o dashboard com dados interessantes, execute:

```bash
# Gerar várias requisições rápidas
for i in {1..10}; do curl -s http://localhost:8000/test/fast > /dev/null; done

# Gerar algumas requisições lentas
for i in {1..3}; do curl -s http://localhost:8000/test/slow > /dev/null & done

# Gerar alguns erros
curl -s http://localhost:8000/test/error/404 > /dev/null 2>&1 || true
curl -s http://localhost:8000/test/error/500 > /dev/null 2>&1 || true

# Criar alguns usuários
for i in {1..5}; do
  curl -s -X POST http://localhost:8000/test/users \
    -H "Content-Type: application/json" \
    -d "{\"name\":\"Usuário $i\",\"email\":\"user$i@test.com\",\"age\":$((20+i))}" > /dev/null
done
```

## 🌐 Configuração com Nginx

1. **Copiar configuração:**
```bash
sudo cp nginx.conf /etc/nginx/nginx.conf
```

2. **Testar configuração:**
```bash
sudo nginx -t
```

3. **Reiniciar Nginx:**
```bash
sudo systemctl restart nginx
```

4. **Acessar via Nginx:**
- API: http://localhost/
- Dashboard: http://localhost/monitor/dashboard

## 📱 Testando CORS

Para testar CORS, crie um arquivo HTML simples:

```html
<!DOCTYPE html>
<html>
<head>
    <title>Teste CORS</title>
</head>
<body>
    <script>
        fetch('http://localhost:8000/test/fast')
            .then(response => response.json())
            .then(data => console.log('Sucesso:', data))
            .catch(error => console.error('Erro:', error));
    </script>
</body>
</html>
```

## 🔧 Parando a API

### Linux/Mac
```bash
./stop.sh
```

### Windows
```cmd
stop.bat
```

### Manual
```bash
pkill -f uvicorn
```

## 📊 Interpretando o Dashboard

### Métricas Principais:
- **Total de Requisições**: Contador acumulativo
- **Taxa de Erro**: Percentual de requisições com status >= 400
- **Tempo Médio**: Média dos tempos de resposta em ms
- **Tempo Online**: Quanto tempo a API está rodando

### Gráficos:
- **Requisições por Minuto**: Mostra a atividade ao longo do tempo
- **Tempo de Resposta**: Mostra a performance ao longo do tempo

### Tabela de Endpoints:
- **Verde (0.0%)**: Sem erros
- **Amarelo (5-15%)**: Taxa de erro moderada
- **Vermelho (>15%)**: Taxa de erro alta

## 🎯 Casos de Uso

1. **Desenvolvimento**: Use com --reload para hot-reload
2. **Teste de Carga**: Use os endpoints de load-test
3. **Monitoramento**: Acompanhe métricas em tempo real
4. **Debug**: Analise tempos de resposta e erros
5. **Produção**: Configure com Nginx e múltiplos workers

