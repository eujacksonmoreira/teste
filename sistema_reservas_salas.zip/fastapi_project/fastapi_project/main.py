from fastapi import FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import HTMLResponse
import uvicorn
import time
import asyncio
from datetime import datetime
from typing import Dict, List
import json
import os
from collections import defaultdict, deque
import threading

# Importar endpoints de teste
from test_endpoints import test_router

# Configuração de monitoramento
class APIMonitor:
    def __init__(self):
        self.requests_count = defaultdict(int)
        self.response_times = defaultdict(deque)
        self.error_count = defaultdict(int)
        self.start_time = datetime.now()
        self.request_history = deque(maxlen=1000)  # Últimas 1000 requisições
        self.endpoint_stats = defaultdict(lambda: {
            'count': 0,
            'avg_response_time': 0,
            'errors': 0,
            'last_access': None
        })
        
    def log_request(self, endpoint: str, response_time: float, status_code: int):
        now = datetime.now()
        
        # Atualizar contadores gerais
        self.requests_count[endpoint] += 1
        self.response_times[endpoint].append(response_time)
        
        # Manter apenas os últimos 100 tempos de resposta por endpoint
        if len(self.response_times[endpoint]) > 100:
            self.response_times[endpoint].popleft()
            
        # Log de erros
        if status_code >= 400:
            self.error_count[endpoint] += 1
            
        # Histórico de requisições
        self.request_history.append({
            'timestamp': now.isoformat(),
            'endpoint': endpoint,
            'response_time': response_time,
            'status_code': status_code
        })
        
        # Atualizar estatísticas do endpoint
        stats = self.endpoint_stats[endpoint]
        stats['count'] += 1
        stats['last_access'] = now.isoformat()
        
        if status_code >= 400:
            stats['errors'] += 1
            
        # Calcular tempo médio de resposta
        if self.response_times[endpoint]:
            stats['avg_response_time'] = sum(self.response_times[endpoint]) / len(self.response_times[endpoint])

# Instância global do monitor
monitor = APIMonitor()

# Criar aplicação FastAPI
app = FastAPI(
    title="API de Monitoramento",
    description="API com sistema de monitoramento em tempo real",
    version="1.0.0"
)

# Configurar CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Em produção, especifique os domínios permitidos
    allow_credentials=True,
    allow_methods=["GET", "POST", "PUT", "DELETE", "OPTIONS", "HEAD", "PATCH"],
    allow_headers=["*"],
    expose_headers=["X-Process-Time"],
)

# Incluir routers
app.include_router(test_router)

# Middleware para monitoramento
@app.middleware("http")
async def monitor_middleware(request: Request, call_next):
    start_time = time.time()
    
    response = await call_next(request)
    
    process_time = time.time() - start_time
    endpoint = f"{request.method} {request.url.path}"
    
    # Log da requisição
    monitor.log_request(endpoint, process_time, response.status_code)
    
    # Adicionar header com tempo de resposta
    response.headers["X-Process-Time"] = str(process_time)
    
    return response

# Servir arquivos estáticos (para a página de monitoramento)
if not os.path.exists("static"):
    os.makedirs("static")
app.mount("/static", StaticFiles(directory="static"), name="static")

# Endpoints da API
@app.get("/")
async def root():
    """Endpoint raiz da API"""
    return {
        "message": "API de Monitoramento está funcionando!",
        "timestamp": datetime.now().isoformat(),
        "uptime_seconds": (datetime.now() - monitor.start_time).total_seconds(),
        "endpoints_disponiveis": {
            "health": "/health",
            "monitoramento": "/monitor/*",
            "testes": "/test/*",
            "dashboard": "/monitor/dashboard"
        }
    }

@app.get("/health")
async def health_check():
    """Endpoint de verificação de saúde"""
    return {
        "status": "healthy",
        "timestamp": datetime.now().isoformat(),
        "uptime": (datetime.now() - monitor.start_time).total_seconds()
    }

# Endpoints de monitoramento
@app.get("/monitor/stats")
async def get_monitoring_stats():
    """Retorna estatísticas gerais de monitoramento"""
    total_requests = sum(monitor.requests_count.values())
    total_errors = sum(monitor.error_count.values())
    
    # Calcular tempo médio geral
    all_times = []
    for times in monitor.response_times.values():
        all_times.extend(times)
    
    avg_response_time = sum(all_times) / len(all_times) if all_times else 0
    
    return {
        "uptime_seconds": (datetime.now() - monitor.start_time).total_seconds(),
        "total_requests": total_requests,
        "total_errors": total_errors,
        "error_rate": (total_errors / total_requests * 100) if total_requests > 0 else 0,
        "avg_response_time": avg_response_time,
        "active_endpoints": len(monitor.requests_count),
        "timestamp": datetime.now().isoformat()
    }

@app.get("/monitor/endpoints")
async def get_endpoint_stats():
    """Retorna estatísticas por endpoint"""
    return dict(monitor.endpoint_stats)

@app.get("/monitor/history")
async def get_request_history(limit: int = 100):
    """Retorna histórico de requisições"""
    history = list(monitor.request_history)
    return history[-limit:] if limit < len(history) else history

@app.get("/monitor/dashboard", response_class=HTMLResponse)
async def monitoring_dashboard():
    """Página de monitoramento em tempo real"""
    with open("static/dashboard.html", "r", encoding="utf-8") as f:
        return HTMLResponse(content=f.read())

if __name__ == "__main__":
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=8000,
        reload=True,
        log_level="info"
    )

