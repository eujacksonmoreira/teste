# Sistema de Reservas de Salas de Reuniões

Um sistema completo para gerenciamento de reservas de salas de reuniões com interface moderna, autenticação segura e notificações por email.

## 🚀 Funcionalidades

### Para Usuários
- **Login Seguro**: Autenticação com JWT e senhas criptografadas
- **Calendário Interativo**: Visualização estilo Outlook com views mensal, semanal e diária
- **Reservas Inteligentes**: Sistema que previne duplo agendamento
- **Notificações**: Emails de confirmação e lembretes 30 minutos antes da reunião
- **Gestão Pessoal**: Visualização e gerenciamento das próprias reservas

### Para Administradores
- **Gestão de Usuários**: Criação, edição e exclusão de usuários
- **Gestão de Salas**: Cadastro e configuração de salas de reunião
- **Controle de Acesso**: Sistema de perfis (admin/usuário)
- **Relatórios**: Visualização de todas as reservas do sistema

## 🛠️ Tecnologias Utilizadas

### Backend
- **FastAPI**: Framework web moderno e rápido
- **SQLAlchemy**: ORM para banco de dados
- **SQLite**: Banco de dados (facilmente substituível)
- **JWT**: Autenticação segura
- **bcrypt**: Criptografia de senhas
- **aiosmtplib**: Envio de emails assíncronos
- **Jinja2**: Templates para emails

### Frontend
- **HTML5/CSS3**: Interface moderna e responsiva
- **JavaScript ES6+**: Funcionalidades interativas
- **FullCalendar**: Componente de calendário profissional
- **Font Awesome**: Ícones modernos

## 📋 Pré-requisitos

- Python 3.11+
- pip (gerenciador de pacotes Python)

## 🔧 Instalação

1. **Clone ou extraia o projeto**
```bash
cd fastapi_project
```

2. **Crie e ative o ambiente virtual**
```bash
python3.11 -m venv venv
source venv/bin/activate  # Linux/Mac
# ou
venv\Scripts\activate  # Windows
```

3. **Instale as dependências**
```bash
pip install -r requirements.txt
```

4. **Configure as variáveis de ambiente (opcional)**
```bash
# Para configurar email SMTP, crie um arquivo .env:
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USERNAME=seu_email@gmail.com
SMTP_PASSWORD=sua_senha_app
FROM_EMAIL=seu_email@gmail.com
FROM_NAME=Sistema de Reservas
```

## 🚀 Execução

1. **Inicie o servidor**
```bash
python new_main.py
```

2. **Acesse a aplicação**
- URL: http://localhost:8000
- Login padrão: admin@empresa.com / admin123

## 👥 Uso do Sistema

### Primeiro Acesso (Administrador)
1. Faça login com as credenciais padrão
2. Acesse a aba "Administração"
3. Crie novos usuários na seção "Usuários"
4. Configure salas na seção "Salas"

### Criação de Usuários
1. Na área administrativa, clique em "Novo Usuário"
2. Preencha nome, email e perfil
3. O sistema enviará um email para o usuário definir a senha
4. O usuário acessará o link no email para criar sua senha segura

### Fazendo Reservas
1. Acesse a aba "Calendário"
2. Clique em "Nova Reserva" ou em uma data no calendário
3. Preencha os dados da reunião
4. Selecione sala, horário e adicione descrição
5. O sistema verificará disponibilidade automaticamente

### Visualização de Reservas
- **Calendário**: Mostra todas as reservas (suas reservas com detalhes, outras apenas como "Reservado")
- **Minhas Reservas**: Lista detalhada das suas reservas com opções de edição/cancelamento

## 🔒 Segurança

### Autenticação
- Senhas criptografadas com bcrypt
- Tokens JWT com expiração
- Controle de acesso baseado em perfis

### Validação de Dados
- Validação no frontend e backend
- Prevenção de duplo agendamento
- Sanitização de entradas

### Senhas Seguras
O sistema exige senhas com:
- Mínimo 8 caracteres
- Pelo menos 1 letra maiúscula
- Pelo menos 1 letra minúscula
- Pelo menos 1 número
- Pelo menos 1 caractere especial

## 📧 Sistema de Notificações

### Emails Automáticos
1. **Confirmação de Reserva**: Enviado imediatamente após criar uma reserva
2. **Lembrete**: Enviado 30 minutos antes da reunião
3. **Definição de Senha**: Enviado quando um novo usuário é criado

### Configuração SMTP
Para ativar o envio de emails, configure as variáveis de ambiente SMTP ou edite o arquivo `email_service.py`.

## 🗄️ Estrutura do Banco de Dados

### Tabelas Principais
- **users**: Usuários do sistema
- **rooms**: Salas de reunião
- **reservations**: Reservas de salas
- **email_logs**: Log de emails enviados

### Dados Padrão
O sistema cria automaticamente:
- Usuário administrador (admin@empresa.com)
- 4 salas de exemplo
- Estrutura completa do banco

## 🎨 Interface

### Design Moderno
- Gradientes e efeitos visuais
- Responsivo para desktop e mobile
- Animações suaves e micro-interações
- Paleta de cores profissional

### UX/UI
- Navegação intuitiva por abas
- Modais para ações rápidas
- Feedback visual para todas as ações
- Calendário estilo Outlook

## 📁 Estrutura do Projeto

```
fastapi_project/
├── venv/                   # Ambiente virtual
├── static/                 # Arquivos estáticos
│   ├── index.html         # Aplicação principal
│   ├── set-password.html  # Página de definir senha
│   └── app.js            # JavaScript da aplicação
├── routers/               # Routers da API
│   ├── auth_router.py    # Autenticação
│   ├── users_router.py   # Usuários
│   ├── rooms_router.py   # Salas
│   └── reservations_router.py # Reservas
├── models.py             # Modelos do banco de dados
├── schemas.py            # Schemas Pydantic
├── database.py           # Configuração do banco
├── auth.py              # Sistema de autenticação
├── email_service.py     # Serviço de email
├── background_tasks.py  # Tarefas em background
├── new_main.py         # Aplicação principal
├── requirements.txt    # Dependências
└── README.md          # Esta documentação
```

## 🔧 Personalização

### Adicionando Novas Salas
1. Acesse a área administrativa
2. Vá para a aba "Salas"
3. Clique em "Nova Sala"
4. Configure capacidade, localização e equipamentos

### Configurando Email
Edite as variáveis no arquivo `email_service.py` ou use variáveis de ambiente:
- SMTP_HOST
- SMTP_PORT
- SMTP_USERNAME
- SMTP_PASSWORD

### Alterando Tema
Modifique as variáveis CSS no arquivo `static/index.html` na seção `<style>`.

## 🚀 Deploy em Produção

### Preparação
1. Altere a SECRET_KEY em `auth.py`
2. Configure CORS adequadamente
3. Use um banco de dados robusto (PostgreSQL)
4. Configure HTTPS
5. Configure variáveis de ambiente

### Exemplo com Docker
```dockerfile
FROM python:3.11-slim
WORKDIR /app
COPY requirements.txt .
RUN pip install -r requirements.txt
COPY . .
EXPOSE 8000
CMD ["python", "new_main.py"]
```

## 🐛 Solução de Problemas

### Erro de Banco de Dados
```bash
# Remova o banco e reinicie
rm meeting_rooms.db
python new_main.py
```

### Problemas de Email
- Verifique as configurações SMTP
- Para Gmail, use senha de aplicativo
- Teste conectividade de rede

### Erro de Dependências
```bash
# Reinstale as dependências
pip install --upgrade -r requirements.txt
```

## 📝 Licença

Este projeto é de uso livre para fins educacionais e comerciais.

## 🤝 Contribuição

Para contribuir com o projeto:
1. Faça um fork
2. Crie uma branch para sua feature
3. Commit suas mudanças
4. Abra um Pull Request

## 📞 Suporte

Para dúvidas ou problemas:
- Verifique a documentação
- Consulte os logs do sistema
- Teste em ambiente de desenvolvimento primeiro

---

**Desenvolvido com ❤️ usando FastAPI e tecnologias modernas**

