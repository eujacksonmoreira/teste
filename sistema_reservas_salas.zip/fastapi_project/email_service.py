import aiosmtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from jinja2 import Template
from typing import Optional
from datetime import datetime
import os
from sqlalchemy.orm import Session

from models import EmailLog, User, Reservation, Room

# Configurações de email (em produção, usar variáveis de ambiente)
SMTP_HOST = os.getenv("SMTP_HOST", "smtp.gmail.com")
SMTP_PORT = int(os.getenv("SMTP_PORT", "587"))
SMTP_USERNAME = os.getenv("SMTP_USERNAME", "")
SMTP_PASSWORD = os.getenv("SMTP_PASSWORD", "")
SMTP_USE_TLS = os.getenv("SMTP_USE_TLS", "true").lower() == "true"
FROM_EMAIL = os.getenv("FROM_EMAIL", SMTP_USERNAME)
FROM_NAME = os.getenv("FROM_NAME", "Sistema de Reservas")

class EmailService:
    def __init__(self):
        self.smtp_host = SMTP_HOST
        self.smtp_port = SMTP_PORT
        self.smtp_username = SMTP_USERNAME
        self.smtp_password = SMTP_PASSWORD
        self.smtp_use_tls = SMTP_USE_TLS
        self.from_email = FROM_EMAIL
        self.from_name = FROM_NAME
    
    async def send_email(
        self,
        to_email: str,
        subject: str,
        html_content: str,
        text_content: Optional[str] = None
    ) -> bool:
        """Enviar email"""
        try:
            # Criar mensagem
            message = MIMEMultipart("alternative")
            message["Subject"] = subject
            message["From"] = f"{self.from_name} <{self.from_email}>"
            message["To"] = to_email
            
            # Adicionar conteúdo texto
            if text_content:
                text_part = MIMEText(text_content, "plain", "utf-8")
                message.attach(text_part)
            
            # Adicionar conteúdo HTML
            html_part = MIMEText(html_content, "html", "utf-8")
            message.attach(html_part)
            
            # Enviar email
            await aiosmtplib.send(
                message,
                hostname=self.smtp_host,
                port=self.smtp_port,
                start_tls=self.smtp_use_tls,
                username=self.smtp_username,
                password=self.smtp_password,
            )
            
            return True
            
        except Exception as e:
            print(f"Erro ao enviar email: {e}")
            return False
    
    def log_email(
        self,
        db: Session,
        recipient_email: str,
        subject: str,
        email_type: str,
        success: bool,
        error_message: Optional[str] = None,
        reservation_id: Optional[int] = None,
        user_id: Optional[int] = None
    ):
        """Registrar log do email"""
        email_log = EmailLog(
            recipient_email=recipient_email,
            subject=subject,
            email_type=email_type,
            success=success,
            error_message=error_message,
            reservation_id=reservation_id,
            user_id=user_id
        )
        
        db.add(email_log)
        db.commit()
    
    async def send_password_reset_email(
        self,
        db: Session,
        user: User,
        reset_token: str,
        base_url: str = "http://localhost:8000"
    ) -> bool:
        """Enviar email para definir/resetar senha"""
        
        # Template HTML
        html_template = Template("""
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="utf-8">
            <title>Definir Senha - Sistema de Reservas</title>
            <style>
                body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
                .container { max-width: 600px; margin: 0 auto; padding: 20px; }
                .header { background-color: #007bff; color: white; padding: 20px; text-align: center; }
                .content { padding: 20px; background-color: #f8f9fa; }
                .button { 
                    display: inline-block; 
                    padding: 12px 24px; 
                    background-color: #007bff; 
                    color: white; 
                    text-decoration: none; 
                    border-radius: 5px; 
                    margin: 20px 0;
                }
                .footer { padding: 20px; text-align: center; color: #666; font-size: 12px; }
            </style>
        </head>
        <body>
            <div class="container">
                <div class="header">
                    <h1>Sistema de Reservas de Salas</h1>
                </div>
                <div class="content">
                    <h2>Olá, {{ user_name }}!</h2>
                    <p>Você foi cadastrado no Sistema de Reservas de Salas. Para acessar sua conta, você precisa definir uma senha.</p>
                    
                    <p><strong>Seus dados de acesso:</strong></p>
                    <ul>
                        <li><strong>Email:</strong> {{ user_email }}</li>
                        <li><strong>Nome:</strong> {{ user_name }}</li>
                    </ul>
                    
                    <p>Clique no botão abaixo para definir sua senha:</p>
                    <a href="{{ reset_url }}" class="button">Definir Senha</a>
                    
                    <p>Ou copie e cole o link abaixo no seu navegador:</p>
                    <p><a href="{{ reset_url }}">{{ reset_url }}</a></p>
                    
                    <p><strong>Token de segurança:</strong> {{ reset_token }}</p>
                    
                    <p>Este link é válido por 24 horas. Se você não solicitou este cadastro, ignore este email.</p>
                </div>
                <div class="footer">
                    <p>Sistema de Reservas de Salas - {{ current_year }}</p>
                </div>
            </div>
        </body>
        </html>
        """)
        
        # Template texto
        text_template = Template("""
        Sistema de Reservas de Salas
        
        Olá, {{ user_name }}!
        
        Você foi cadastrado no Sistema de Reservas de Salas. Para acessar sua conta, você precisa definir uma senha.
        
        Seus dados de acesso:
        - Email: {{ user_email }}
        - Nome: {{ user_name }}
        
        Acesse o link abaixo para definir sua senha:
        {{ reset_url }}
        
        Token de segurança: {{ reset_token }}
        
        Este link é válido por 24 horas. Se você não solicitou este cadastro, ignore este email.
        
        Sistema de Reservas de Salas - {{ current_year }}
        """)
        
        # Dados para o template
        reset_url = f"{base_url}/set-password?token={reset_token}"
        template_data = {
            "user_name": user.name,
            "user_email": user.email,
            "reset_token": reset_token,
            "reset_url": reset_url,
            "current_year": datetime.now().year
        }
        
        # Renderizar templates
        html_content = html_template.render(**template_data)
        text_content = text_template.render(**template_data)
        
        # Enviar email
        subject = "Definir Senha - Sistema de Reservas"
        success = await self.send_email(user.email, subject, html_content, text_content)
        
        # Registrar log
        self.log_email(
            db=db,
            recipient_email=user.email,
            subject=subject,
            email_type="password_reset",
            success=success,
            error_message=None if success else "Falha no envio",
            user_id=user.id
        )
        
        return success
    
    async def send_reservation_confirmation_email(
        self,
        db: Session,
        reservation: Reservation,
        user: User,
        room: Room
    ) -> bool:
        """Enviar email de confirmação de reserva"""
        
        # Template HTML
        html_template = Template("""
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="utf-8">
            <title>Reserva Confirmada - Sistema de Reservas</title>
            <style>
                body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
                .container { max-width: 600px; margin: 0 auto; padding: 20px; }
                .header { background-color: #28a745; color: white; padding: 20px; text-align: center; }
                .content { padding: 20px; background-color: #f8f9fa; }
                .reservation-details { 
                    background-color: white; 
                    padding: 15px; 
                    border-left: 4px solid #28a745; 
                    margin: 20px 0; 
                }
                .footer { padding: 20px; text-align: center; color: #666; font-size: 12px; }
            </style>
        </head>
        <body>
            <div class="container">
                <div class="header">
                    <h1>✅ Reserva Confirmada</h1>
                </div>
                <div class="content">
                    <h2>Olá, {{ user_name }}!</h2>
                    <p>Sua reserva foi confirmada com sucesso!</p>
                    
                    <div class="reservation-details">
                        <h3>Detalhes da Reserva</h3>
                        <ul>
                            <li><strong>Título:</strong> {{ reservation_title }}</li>
                            <li><strong>Sala:</strong> {{ room_name }}</li>
                            <li><strong>Data:</strong> {{ start_date }}</li>
                            <li><strong>Horário:</strong> {{ start_time }} às {{ end_time }}</li>
                            <li><strong>Duração:</strong> {{ duration }}</li>
                            {% if room_location %}<li><strong>Local:</strong> {{ room_location }}</li>{% endif %}
                        </ul>
                        {% if reservation_description %}
                        <p><strong>Descrição:</strong><br>{{ reservation_description }}</p>
                        {% endif %}
                    </div>
                    
                    <p><strong>Lembrete:</strong> Você receberá uma notificação 30 minutos antes do início da reunião.</p>
                    
                    <p>Para gerenciar suas reservas, acesse o sistema de reservas.</p>
                </div>
                <div class="footer">
                    <p>Sistema de Reservas de Salas - {{ current_year }}</p>
                </div>
            </div>
        </body>
        </html>
        """)
        
        # Calcular duração
        duration = reservation.end_time - reservation.start_time
        hours = duration.seconds // 3600
        minutes = (duration.seconds % 3600) // 60
        duration_str = f"{hours}h{minutes:02d}min" if hours > 0 else f"{minutes}min"
        
        # Dados para o template
        template_data = {
            "user_name": user.name,
            "reservation_title": reservation.title,
            "room_name": room.name,
            "room_location": room.location,
            "start_date": reservation.start_time.strftime("%d/%m/%Y"),
            "start_time": reservation.start_time.strftime("%H:%M"),
            "end_time": reservation.end_time.strftime("%H:%M"),
            "duration": duration_str,
            "reservation_description": reservation.description,
            "current_year": datetime.now().year
        }
        
        # Renderizar template
        html_content = html_template.render(**template_data)
        
        # Enviar email
        subject = f"Reserva Confirmada - {room.name} em {reservation.start_time.strftime('%d/%m/%Y')}"
        success = await self.send_email(user.email, subject, html_content)
        
        # Registrar log
        self.log_email(
            db=db,
            recipient_email=user.email,
            subject=subject,
            email_type="reservation_confirmation",
            success=success,
            error_message=None if success else "Falha no envio",
            reservation_id=reservation.id,
            user_id=user.id
        )
        
        return success
    
    async def send_reminder_email(
        self,
        db: Session,
        reservation: Reservation,
        user: User,
        room: Room
    ) -> bool:
        """Enviar email de lembrete (30 minutos antes)"""
        
        # Template HTML
        html_template = Template("""
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="utf-8">
            <title>Lembrete de Reunião - Sistema de Reservas</title>
            <style>
                body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
                .container { max-width: 600px; margin: 0 auto; padding: 20px; }
                .header { background-color: #ffc107; color: #212529; padding: 20px; text-align: center; }
                .content { padding: 20px; background-color: #f8f9fa; }
                .reminder-details { 
                    background-color: white; 
                    padding: 15px; 
                    border-left: 4px solid #ffc107; 
                    margin: 20px 0; 
                }
                .footer { padding: 20px; text-align: center; color: #666; font-size: 12px; }
            </style>
        </head>
        <body>
            <div class="container">
                <div class="header">
                    <h1>⏰ Lembrete de Reunião</h1>
                </div>
                <div class="content">
                    <h2>Olá, {{ user_name }}!</h2>
                    <p>Sua reunião começará em aproximadamente 30 minutos!</p>
                    
                    <div class="reminder-details">
                        <h3>Detalhes da Reunião</h3>
                        <ul>
                            <li><strong>Título:</strong> {{ reservation_title }}</li>
                            <li><strong>Sala:</strong> {{ room_name }}</li>
                            <li><strong>Horário:</strong> {{ start_time }} às {{ end_time }}</li>
                            {% if room_location %}<li><strong>Local:</strong> {{ room_location }}</li>{% endif %}
                        </ul>
                        {% if reservation_description %}
                        <p><strong>Descrição:</strong><br>{{ reservation_description }}</p>
                        {% endif %}
                    </div>
                    
                    <p>Não se esqueça de se dirigir à sala com antecedência!</p>
                </div>
                <div class="footer">
                    <p>Sistema de Reservas de Salas - {{ current_year }}</p>
                </div>
            </div>
        </body>
        </html>
        """)
        
        # Dados para o template
        template_data = {
            "user_name": user.name,
            "reservation_title": reservation.title,
            "room_name": room.name,
            "room_location": room.location,
            "start_time": reservation.start_time.strftime("%H:%M"),
            "end_time": reservation.end_time.strftime("%H:%M"),
            "reservation_description": reservation.description,
            "current_year": datetime.now().year
        }
        
        # Renderizar template
        html_content = html_template.render(**template_data)
        
        # Enviar email
        subject = f"Lembrete: Reunião em {room.name} às {reservation.start_time.strftime('%H:%M')}"
        success = await self.send_email(user.email, subject, html_content)
        
        # Registrar log
        self.log_email(
            db=db,
            recipient_email=user.email,
            subject=subject,
            email_type="reminder",
            success=success,
            error_message=None if success else "Falha no envio",
            reservation_id=reservation.id,
            user_id=user.id
        )
        
        return success

# Instância global do serviço de email
email_service = EmailService()

