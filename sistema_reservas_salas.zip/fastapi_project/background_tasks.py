import asyncio
from datetime import datetime, timedelta
from sqlalchemy.orm import Session
from sqlalchemy import and_

from database import SessionLocal
from models import Reservation, User, Room
from email_service import email_service

class BackgroundTaskManager:
    def __init__(self):
        self.running = False
        self.task = None
    
    async def start(self):
        """Iniciar o gerenciador de tarefas em background"""
        if not self.running:
            self.running = True
            self.task = asyncio.create_task(self._run_background_tasks())
            print("Background tasks iniciadas")
    
    async def stop(self):
        """Parar o gerenciador de tarefas em background"""
        if self.running:
            self.running = False
            if self.task:
                self.task.cancel()
                try:
                    await self.task
                except asyncio.CancelledError:
                    pass
            print("Background tasks paradas")
    
    async def _run_background_tasks(self):
        """Loop principal das tarefas em background"""
        while self.running:
            try:
                await self._check_reminder_notifications()
                # Aguardar 5 minutos antes da próxima verificação
                await asyncio.sleep(300)  # 5 minutos
            except asyncio.CancelledError:
                break
            except Exception as e:
                print(f"Erro nas background tasks: {e}")
                await asyncio.sleep(60)  # Aguardar 1 minuto em caso de erro
    
    async def _check_reminder_notifications(self):
        """Verificar e enviar notificações de lembrete"""
        db = SessionLocal()
        try:
            # Buscar reservas que começam em 30 minutos (±2 minutos de tolerância)
            now = datetime.utcnow()
            reminder_time_start = now + timedelta(minutes=28)
            reminder_time_end = now + timedelta(minutes=32)
            
            reservations = db.query(Reservation).filter(
                and_(
                    Reservation.start_time >= reminder_time_start,
                    Reservation.start_time <= reminder_time_end,
                    Reservation.is_cancelled == False,
                    Reservation.reminder_sent == False
                )
            ).all()
            
            for reservation in reservations:
                try:
                    # Buscar dados do usuário e sala
                    user = db.query(User).filter(User.id == reservation.user_id).first()
                    room = db.query(Room).filter(Room.id == reservation.room_id).first()
                    
                    if user and room:
                        # Enviar email de lembrete
                        success = await email_service.send_reminder_email(db, reservation, user, room)
                        
                        if success:
                            # Marcar como enviado
                            reservation.reminder_sent = True
                            db.commit()
                            print(f"Lembrete enviado para {user.email} - Reserva {reservation.id}")
                        else:
                            print(f"Falha ao enviar lembrete para {user.email} - Reserva {reservation.id}")
                
                except Exception as e:
                    print(f"Erro ao processar lembrete da reserva {reservation.id}: {e}")
                    db.rollback()
        
        except Exception as e:
            print(f"Erro ao verificar lembretes: {e}")
        finally:
            db.close()
    
    async def send_reservation_confirmation(self, reservation_id: int):
        """Enviar confirmação de reserva (chamado após criar reserva)"""
        db = SessionLocal()
        try:
            reservation = db.query(Reservation).filter(Reservation.id == reservation_id).first()
            if reservation:
                user = db.query(User).filter(User.id == reservation.user_id).first()
                room = db.query(Room).filter(Room.id == reservation.room_id).first()
                
                if user and room:
                    success = await email_service.send_reservation_confirmation_email(db, reservation, user, room)
                    
                    if success:
                        reservation.notification_sent = True
                        db.commit()
                        print(f"Confirmação enviada para {user.email} - Reserva {reservation.id}")
                    else:
                        print(f"Falha ao enviar confirmação para {user.email} - Reserva {reservation.id}")
        
        except Exception as e:
            print(f"Erro ao enviar confirmação da reserva {reservation_id}: {e}")
        finally:
            db.close()
    
    async def send_password_reset_email(self, user_id: int, base_url: str = "http://localhost:8000"):
        """Enviar email para definir/resetar senha"""
        db = SessionLocal()
        try:
            user = db.query(User).filter(User.id == user_id).first()
            if user and user.password_reset_token:
                success = await email_service.send_password_reset_email(db, user, user.password_reset_token, base_url)
                
                if success:
                    print(f"Email de definição de senha enviado para {user.email}")
                else:
                    print(f"Falha ao enviar email de definição de senha para {user.email}")
        
        except Exception as e:
            print(f"Erro ao enviar email de definição de senha para usuário {user_id}: {e}")
        finally:
            db.close()

# Instância global do gerenciador de tarefas
background_manager = BackgroundTaskManager()

