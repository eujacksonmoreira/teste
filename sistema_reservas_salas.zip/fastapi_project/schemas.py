from pydantic import BaseModel, EmailStr, validator
from typing import Optional, List
from datetime import datetime
from models import UserRole
import re

# Schemas para User
class UserBase(BaseModel):
    email: EmailStr
    name: str
    role: UserRole = UserRole.USER

class UserCreate(UserBase):
    pass  # Senha será gerada e enviada por email

class UserUpdate(BaseModel):
    name: Optional[str] = None
    role: Optional[UserRole] = None
    is_active: Optional[bool] = None

class UserSetPassword(BaseModel):
    token: str
    new_password: str
    
    @validator('new_password')
    def validate_password(cls, v):
        if len(v) < 8:
            raise ValueError('Senha deve ter pelo menos 8 caracteres')
        if not re.search(r'[A-Z]', v):
            raise ValueError('Senha deve conter pelo menos uma letra maiúscula')
        if not re.search(r'[a-z]', v):
            raise ValueError('Senha deve conter pelo menos uma letra minúscula')
        if not re.search(r'\d', v):
            raise ValueError('Senha deve conter pelo menos um número')
        if not re.search(r'[!@#$%^&*(),.?":{}|<>]', v):
            raise ValueError('Senha deve conter pelo menos um caractere especial')
        return v

class UserLogin(BaseModel):
    email: EmailStr
    password: str

class UserResponse(UserBase):
    id: int
    is_active: bool
    created_at: datetime
    updated_at: datetime
    
    class Config:
        from_attributes = True

# Schemas para Room
class RoomBase(BaseModel):
    name: str
    description: Optional[str] = None
    capacity: int
    location: Optional[str] = None
    equipment: Optional[str] = None  # JSON string

class RoomCreate(RoomBase):
    pass

class RoomUpdate(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    capacity: Optional[int] = None
    location: Optional[str] = None
    equipment: Optional[str] = None
    is_active: Optional[bool] = None

class RoomResponse(RoomBase):
    id: int
    is_active: bool
    created_at: datetime
    updated_at: datetime
    
    class Config:
        from_attributes = True

# Schemas para Reservation
class ReservationBase(BaseModel):
    room_id: int
    title: str
    description: Optional[str] = None
    start_time: datetime
    end_time: datetime
    
    @validator('end_time')
    def validate_end_time(cls, v, values):
        if 'start_time' in values and v <= values['start_time']:
            raise ValueError('Horário de fim deve ser posterior ao horário de início')
        return v

class ReservationCreate(ReservationBase):
    pass

class ReservationUpdate(BaseModel):
    title: Optional[str] = None
    description: Optional[str] = None
    start_time: Optional[datetime] = None
    end_time: Optional[datetime] = None
    
    @validator('end_time')
    def validate_end_time(cls, v, values):
        if 'start_time' in values and v and values['start_time'] and v <= values['start_time']:
            raise ValueError('Horário de fim deve ser posterior ao horário de início')
        return v

class ReservationResponse(BaseModel):
    id: int
    user_id: int
    room_id: int
    title: str
    description: Optional[str] = None
    start_time: datetime
    end_time: datetime
    is_cancelled: bool
    created_at: datetime
    updated_at: datetime
    
    # Dados do usuário e sala
    user_name: str
    room_name: str
    
    class Config:
        from_attributes = True

class ReservationPublicResponse(BaseModel):
    """Schema para visualização pública das reservas (sem detalhes privados)"""
    id: int
    room_id: int
    start_time: datetime
    end_time: datetime
    user_name: str  # Apenas o nome de quem reservou
    room_name: str
    
    class Config:
        from_attributes = True

# Schemas para autenticação
class Token(BaseModel):
    access_token: str
    token_type: str
    user: UserResponse

class TokenData(BaseModel):
    email: Optional[str] = None

# Schemas para email
class EmailRequest(BaseModel):
    recipient: EmailStr
    subject: str
    body: str

# Schemas para dashboard/estatísticas
class DashboardStats(BaseModel):
    total_users: int
    total_rooms: int
    total_reservations: int
    active_reservations: int
    reservations_today: int
    most_used_room: Optional[str] = None

class CalendarEvent(BaseModel):
    id: int
    title: str
    start: datetime
    end: datetime
    room_name: str
    user_name: str
    is_own: bool  # Se a reserva pertence ao usuário logado
    
    class Config:
        from_attributes = True

