from pydantic import BaseModel, EmailStr
from typing import Optional, List
from datetime import datetime

# Schemas para usuários
class UserBase(BaseModel):
    username: str
    email: EmailStr
    full_name: Optional[str] = None
    phone: Optional[str] = None
    is_active: bool = True
    is_admin: bool = False

class UserCreate(UserBase):
    password: str
    roles: Optional[List[int]] = []

class UserUpdate(BaseModel):
    username: Optional[str] = None
    email: Optional[EmailStr] = None
    full_name: Optional[str] = None
    phone: Optional[str] = None
    is_active: Optional[bool] = None
    is_admin: Optional[bool] = None
    password: Optional[str] = None
    roles: Optional[List[int]] = None

class UserResponse(UserBase):
    id: int
    created_at: datetime
    updated_at: Optional[datetime] = None
    profile: Optional['ProfileResponse'] = None
    roles: Optional[List['RoleResponse']] = []

    class Config:
        from_attributes = True

# Schemas para perfis
class ProfileBase(BaseModel):
    bio: Optional[str] = None
    avatar_url: Optional[str] = None
    department: Optional[str] = None
    position: Optional[str] = None

class ProfileCreate(ProfileBase):
    pass

class ProfileUpdate(ProfileBase):
    pass

class ProfileResponse(ProfileBase):
    id: int
    user_id: int
    created_at: datetime
    updated_at: Optional[datetime] = None

    class Config:
        from_attributes = True

# Schemas para roles
class RoleBase(BaseModel):
    name: str
    description: Optional[str] = None

class RoleCreate(RoleBase):
    permissions: Optional[List[int]] = []

class RoleUpdate(RoleBase):
    permissions: Optional[List[int]] = None

class RoleResponse(RoleBase):
    id: int
    created_at: datetime
    permissions: Optional[List['PermissionResponse']] = []

    class Config:
        from_attributes = True

# Schemas para permissões
class PermissionBase(BaseModel):
    name: str
    description: Optional[str] = None
    resource: Optional[str] = None
    action: Optional[str] = None

class PermissionCreate(PermissionBase):
    pass

class PermissionUpdate(PermissionBase):
    pass

class PermissionResponse(PermissionBase):
    id: int
    created_at: datetime

    class Config:
        from_attributes = True

# Schemas para autenticação
class Token(BaseModel):
    access_token: str
    token_type: str
    expires_in: int

class TokenData(BaseModel):
    username: Optional[str] = None

class LoginRequest(BaseModel):
    username: str
    password: str

class PasswordChangeRequest(BaseModel):
    current_password: str
    new_password: str

class PasswordResetRequest(BaseModel):
    email: EmailStr

class PasswordResetConfirm(BaseModel):
    token: str
    new_password: str

class AccountActivation(BaseModel):
    token: str
    password: str

# Schemas para reservas
class BookingBase(BaseModel):
    resource_id: int
    start_time: datetime
    end_time: datetime
    title: str
    description: Optional[str] = None

class BookingCreate(BookingBase):
    pass

class BookingUpdate(BaseModel):
    resource_id: Optional[int] = None
    start_time: Optional[datetime] = None
    end_time: Optional[datetime] = None
    title: Optional[str] = None
    description: Optional[str] = None
    status: Optional[str] = None

class BookingResponse(BookingBase):
    id: int
    user_id: int
    status: str
    created_at: datetime
    updated_at: Optional[datetime] = None
    user: Optional[UserResponse] = None
    resource: Optional['ResourceResponse'] = None

    class Config:
        from_attributes = True

# Schemas para recursos
class ResourceBase(BaseModel):
    name: str
    description: Optional[str] = None
    type: str
    capacity: Optional[int] = None
    location: Optional[str] = None
    is_active: bool = True

class ResourceCreate(ResourceBase):
    pass

class ResourceUpdate(ResourceBase):
    pass

class ResourceResponse(ResourceBase):
    id: int
    created_at: datetime
    updated_at: Optional[datetime] = None

    class Config:
        from_attributes = True

# Schemas para configurações do sistema
class SystemConfigBase(BaseModel):
    key: str
    value: str
    category: str
    description: Optional[str] = None
    is_public: bool = False

class SystemConfigCreate(SystemConfigBase):
    pass

class SystemConfigUpdate(BaseModel):
    value: Optional[str] = None
    description: Optional[str] = None
    is_public: Optional[bool] = None

class SystemConfigResponse(SystemConfigBase):
    id: int
    created_at: datetime
    updated_at: Optional[datetime] = None

    class Config:
        from_attributes = True

# Schemas para logs do sistema
class SystemLogBase(BaseModel):
    level: str
    message: str
    module: Optional[str] = None
    function: Optional[str] = None
    user_id: Optional[int] = None
    ip_address: Optional[str] = None
    user_agent: Optional[str] = None
    extra_data: Optional[dict] = None

class SystemLogCreate(SystemLogBase):
    pass

class SystemLogResponse(SystemLogBase):
    id: int
    timestamp: datetime
    user: Optional[UserResponse] = None

    class Config:
        from_attributes = True

# Schemas para relatórios
class ReportRequest(BaseModel):
    report_type: str
    start_date: Optional[datetime] = None
    end_date: Optional[datetime] = None
    filters: Optional[dict] = None

class ReportResponse(BaseModel):
    report_type: str
    data: dict
    generated_at: datetime
    total_records: int

# Schemas para estatísticas
class StatsResponse(BaseModel):
    total_users: int
    active_users: int
    total_bookings: int
    bookings_today: int
    bookings_this_week: int
    bookings_this_month: int
    most_used_resources: List[dict]
    peak_hours: List[dict]

# Schemas para tokens de usuário
class UserTokenBase(BaseModel):
    token: str
    token_type: str
    expires_at: datetime
    is_used: bool = False

class UserTokenCreate(UserTokenBase):
    user_id: int

class UserTokenResponse(UserTokenBase):
    id: int
    user_id: int
    created_at: datetime
    user: Optional[UserResponse] = None

    class Config:
        from_attributes = True

# Atualizar referências forward
UserResponse.model_rebuild()
ProfileResponse.model_rebuild()
RoleResponse.model_rebuild()
BookingResponse.model_rebuild()


# Schemas para agenda semanal
class WeeklyScheduleBase(BaseModel):
    day_of_week: str
    start_time: str
    end_time: str
    title: str
    description: Optional[str] = None
    is_recurring: bool = True

class WeeklyScheduleCreate(WeeklyScheduleBase):
    pass

class WeeklyScheduleUpdate(WeeklyScheduleBase):
    pass

class WeeklyScheduleResponse(WeeklyScheduleBase):
    id: int
    user_id: int
    created_at: datetime
    updated_at: Optional[datetime] = None
    user: Optional[UserResponse] = None

    class Config:
        from_attributes = True

# Schemas para períodos
class PeriodBase(BaseModel):
    name: str
    start_time: str
    end_time: str
    is_active: bool = True

class PeriodCreate(PeriodBase):
    pass

class PeriodUpdate(PeriodBase):
    pass

class PeriodResponse(PeriodBase):
    id: int
    created_at: datetime
    updated_at: Optional[datetime] = None

    class Config:
        from_attributes = True



# Schemas específicos para recursos
class ResourceCreate(ResourceBase):
    pass

class ResourceUpdate(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    type: Optional[str] = None
    capacity: Optional[int] = None
    location: Optional[str] = None
    is_active: Optional[bool] = None

