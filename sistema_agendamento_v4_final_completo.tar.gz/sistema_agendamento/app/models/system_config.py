from sqlalchemy import Column, Integer, String, Text, Boolean, DateTime, JSON
from datetime import datetime
from app.models.database import Base

class SystemConfig(Base):
    __tablename__ = "system_configs"
    
    id = Column(Integer, primary_key=True, index=True)
    key = Column(String(100), unique=True, nullable=False, index=True)
    value = Column(Text, nullable=True)
    value_type = Column(String(20), default='string')  # string, integer, boolean, json
    category = Column(String(50), nullable=False, index=True)
    description = Column(Text, nullable=True)
    is_public = Column(Boolean, default=False)  # Se pode ser acessado por usuários não-admin
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    @classmethod
    def get_default_configs(cls):
        """Configurações padrão do sistema"""
        return [
            # Configurações de Tema
            {
                'key': 'theme_primary_color',
                'value': '#3FA110',
                'value_type': 'string',
                'category': 'theme',
                'description': 'Cor primária do tema',
                'is_public': True
            },
            {
                'key': 'theme_secondary_color',
                'value': '#2E7D0A',
                'value_type': 'string',
                'category': 'theme',
                'description': 'Cor secundária do tema',
                'is_public': True
            },
            {
                'key': 'theme_dark_mode',
                'value': 'false',
                'value_type': 'boolean',
                'category': 'theme',
                'description': 'Modo escuro habilitado por padrão',
                'is_public': True
            },
            {
                'key': 'login_background_color',
                'value': '#f8f9fa',
                'value_type': 'string',
                'category': 'login',
                'description': 'Cor de fundo da página de login',
                'is_public': True
            },
            {
                'key': 'login_button_color',
                'value': '#3FA110',
                'value_type': 'string',
                'category': 'login',
                'description': 'Cor do botão de login',
                'is_public': True
            },
            
            # Configurações do Sistema
            {
                'key': 'system_name',
                'value': 'Sistema de Agendamento',
                'value_type': 'string',
                'category': 'system',
                'description': 'Nome do sistema',
                'is_public': True
            },
            {
                'key': 'system_logo_url',
                'value': '/static/images/logo.png',
                'value_type': 'string',
                'category': 'system',
                'description': 'URL do logo do sistema',
                'is_public': True
            },
            {
                'key': 'max_booking_duration_hours',
                'value': '8',
                'value_type': 'integer',
                'category': 'booking',
                'description': 'Duração máxima de uma reserva em horas',
                'is_public': False
            },
            {
                'key': 'booking_advance_days',
                'value': '30',
                'value_type': 'integer',
                'category': 'booking',
                'description': 'Quantos dias de antecedência é possível fazer reservas',
                'is_public': False
            },
            
            # Configurações de E-mail
            {
                'key': 'email_notifications_enabled',
                'value': 'true',
                'value_type': 'boolean',
                'category': 'email',
                'description': 'Notificações por e-mail habilitadas',
                'is_public': False
            },
            {
                'key': 'smtp_server',
                'value': 'smtp.gmail.com',
                'value_type': 'string',
                'category': 'email',
                'description': 'Servidor SMTP',
                'is_public': False
            },
            {
                'key': 'smtp_port',
                'value': '587',
                'value_type': 'integer',
                'category': 'email',
                'description': 'Porta do servidor SMTP',
                'is_public': False
            },
            
            # Configurações de Segurança
            {
                'key': 'password_min_length',
                'value': '6',
                'value_type': 'integer',
                'category': 'security',
                'description': 'Comprimento mínimo da senha',
                'is_public': False
            },
            {
                'key': 'session_timeout_minutes',
                'value': '480',
                'value_type': 'integer',
                'category': 'security',
                'description': 'Timeout da sessão em minutos',
                'is_public': False
            },
            {
                'key': 'max_login_attempts',
                'value': '5',
                'value_type': 'integer',
                'category': 'security',
                'description': 'Máximo de tentativas de login',
                'is_public': False
            }
        ]
    
    def get_typed_value(self):
        """Retorna o valor convertido para o tipo correto"""
        if self.value is None:
            return None
            
        if self.value_type == 'boolean':
            return self.value.lower() in ('true', '1', 'yes', 'on')
        elif self.value_type == 'integer':
            try:
                return int(self.value)
            except (ValueError, TypeError):
                return 0
        elif self.value_type == 'json':
            try:
                import json
                return json.loads(self.value)
            except (ValueError, TypeError):
                return {}
        else:  # string
            return self.value

