from sqlalchemy import Column, Integer, String, Text, DateTime, Index
from datetime import datetime
from app.models.database import Base

class SystemLog(Base):
    __tablename__ = "system_logs"
    
    id = Column(Integer, primary_key=True, index=True)
    level = Column(String(10), nullable=False, index=True)  # DEBUG, INFO, WARNING, ERROR, CRITICAL
    message = Column(Text, nullable=False)
    module = Column(String(100), nullable=True, index=True)
    function = Column(String(100), nullable=True)
    user_id = Column(Integer, nullable=True, index=True)
    user_ip = Column(String(45), nullable=True)  # IPv4 ou IPv6
    request_id = Column(String(50), nullable=True, index=True)
    extra_data = Column(Text, nullable=True)  # JSON string para dados extras
    created_at = Column(DateTime, default=datetime.utcnow, index=True)
    
    # Índices compostos para melhor performance
    __table_args__ = (
        Index('idx_level_created', 'level', 'created_at'),
        Index('idx_user_created', 'user_id', 'created_at'),
        Index('idx_module_created', 'module', 'created_at'),
    )
    
    @classmethod
    def create_log(cls, level: str, message: str, module: str = None, 
                   function: str = None, user_id: int = None, 
                   user_ip: str = None, request_id: str = None, 
                   extra_data: dict = None):
        """Criar um novo log"""
        import json
        
        return cls(
            level=level.upper(),
            message=message,
            module=module,
            function=function,
            user_id=user_id,
            user_ip=user_ip,
            request_id=request_id,
            extra_data=json.dumps(extra_data) if extra_data else None
        )
    
    def get_extra_data(self):
        """Retorna os dados extras como dicionário"""
        if not self.extra_data:
            return {}
        try:
            import json
            return json.loads(self.extra_data)
        except (ValueError, TypeError):
            return {}
    
    @property
    def level_badge_class(self):
        """Retorna a classe CSS para o badge do nível"""
        level_classes = {
            'DEBUG': 'bg-secondary',
            'INFO': 'bg-info',
            'WARNING': 'bg-warning',
            'ERROR': 'bg-danger',
            'CRITICAL': 'bg-dark'
        }
        return level_classes.get(self.level, 'bg-secondary')
    
    @property
    def level_icon(self):
        """Retorna o ícone para o nível do log"""
        level_icons = {
            'DEBUG': 'fas fa-bug',
            'INFO': 'fas fa-info-circle',
            'WARNING': 'fas fa-exclamation-triangle',
            'ERROR': 'fas fa-times-circle',
            'CRITICAL': 'fas fa-skull-crossbones'
        }
        return level_icons.get(self.level, 'fas fa-circle')

