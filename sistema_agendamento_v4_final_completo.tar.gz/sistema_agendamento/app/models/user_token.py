from sqlalchemy import Column, Integer, String, DateTime, Boolean, ForeignKey
from sqlalchemy.orm import relationship
from datetime import datetime, timedelta
from app.models.database import Base

class UserToken(Base):
    __tablename__ = "user_tokens"
    
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    token_hash = Column(String(64), unique=True, nullable=False, index=True)
    token_type = Column(String(20), nullable=False)  # 'activation' ou 'password_reset'
    expires_at = Column(DateTime, nullable=False)
    used = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    
    # Relacionamentos
    user = relationship("User", back_populates="tokens")
    
    def is_expired(self) -> bool:
        """Verifica se o token expirou"""
        return datetime.utcnow() > self.expires_at
    
    def is_valid(self) -> bool:
        """Verifica se o token é válido (não usado e não expirado)"""
        return not self.used and not self.is_expired()
    
    @classmethod
    def create_activation_token(cls, user_id: int, token_hash: str):
        """Cria um token de ativação"""
        expires_at = datetime.utcnow() + timedelta(hours=24)
        return cls(
            user_id=user_id,
            token_hash=token_hash,
            token_type='activation',
            expires_at=expires_at
        )
    
    @classmethod
    def create_password_reset_token(cls, user_id: int, token_hash: str):
        """Cria um token de reset de senha"""
        expires_at = datetime.utcnow() + timedelta(hours=1)
        return cls(
            user_id=user_id,
            token_hash=token_hash,
            token_type='password_reset',
            expires_at=expires_at
        )

