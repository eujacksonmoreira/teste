from sqlalchemy import Column, Integer, String, Boolean, DateTime, Text, Enum
from sqlalchemy.orm import relationship
from datetime import datetime
import enum
from .database import Base

class ResourceType(enum.Enum):
    ROOM = "room"
    VEHICLE = "vehicle"

class Room(Base):
    __tablename__ = "rooms"
    
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(100), nullable=False)
    description = Column(Text)
    capacity = Column(Integer, default=1)
    location = Column(String(200))
    equipment = Column(Text)  # JSON string com equipamentos disponíveis
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relacionamentos
    bookings = relationship("Booking", back_populates="room")

class Vehicle(Base):
    __tablename__ = "vehicles"
    
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(100), nullable=False)
    model = Column(String(100))
    brand = Column(String(50))
    license_plate = Column(String(20), unique=True)
    year = Column(Integer)
    fuel_type = Column(String(20))  # gasolina, etanol, diesel, flex
    capacity = Column(Integer, default=5)
    description = Column(Text)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relacionamentos
    bookings = relationship("Booking", back_populates="vehicle")

