from sqlalchemy.orm import Session
from app.models.database import SessionLocal
from app.models.user import User
from app.utils.auth import get_password_hash
from config.settings import settings
import logging

logger = logging.getLogger(__name__)

async def create_default_admin():
    """Criar usuário admin padrão se não existir"""
    db = SessionLocal()
    try:
        # Verificar se já existe um admin
        admin_user = db.query(User).filter(User.is_admin == True).first()
        
        if not admin_user:
            # Criar usuário admin padrão
            hashed_password = get_password_hash(settings.ADMIN_PASSWORD)
            admin_user = User(
                email=settings.ADMIN_EMAIL,
                username="admin",
                full_name="Administrador do Sistema",
                hashed_password=hashed_password,
                is_admin=True,
                is_active=True
            )
            
            db.add(admin_user)
            db.commit()
            db.refresh(admin_user)
            
            logger.info(f"Usuário admin padrão criado: {admin_user.username}")
        else:
            logger.info("Usuário admin já existe no sistema")
            
    except Exception as e:
        logger.error(f"Erro ao criar usuário admin padrão: {e}")
        db.rollback()
    finally:
        db.close()

