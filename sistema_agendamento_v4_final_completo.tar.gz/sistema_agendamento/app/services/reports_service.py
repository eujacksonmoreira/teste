from sqlalchemy.orm import Session
from sqlalchemy import func, and_, or_, desc
from datetime import datetime, timedelta, date
from typing import List, Dict, Any, Optional
import logging

from app.models.user import User
from app.models.booking import Booking
from app.models.resources import Room, Vehicle
from app.models.database import get_db

logger = logging.getLogger(__name__)

class ReportsService:
    def __init__(self):
        pass
    
    async def get_dashboard_stats(self, db: Session) -> Dict[str, Any]:
        """Obter estatísticas para o dashboard"""
        try:
            today = date.today()
            week_start = today - timedelta(days=today.weekday())
            month_start = today.replace(day=1)
            
            # Estatísticas básicas
            total_users = db.query(User).count()
            active_users = db.query(User).filter(User.is_active == True).count()
            total_bookings = db.query(Booking).count()
            
            # Reservas hoje
            bookings_today = db.query(Booking).filter(
                func.date(Booking.start_time) == today
            ).count()
            
            # Reservas esta semana
            bookings_week = db.query(Booking).filter(
                func.date(Booking.start_time) >= week_start
            ).count()
            
            # Reservas este mês
            bookings_month = db.query(Booking).filter(
                func.date(Booking.start_time) >= month_start
            ).count()
            
            # Recursos mais utilizados
            popular_rooms = db.query(
                Room.name,
                func.count(Booking.id).label('booking_count')
            ).join(Booking, Room.id == Booking.room_id, isouter=True)\
             .group_by(Room.id, Room.name)\
             .order_by(desc('booking_count'))\
             .limit(5).all()
            
            # Taxa de ocupação por dia da semana
            occupancy_by_weekday = []
            for weekday in range(7):
                count = db.query(Booking).filter(
                    func.extract('dow', Booking.start_time) == weekday
                ).count()
                occupancy_by_weekday.append({
                    'weekday': ['Domingo', 'Segunda', 'Terça', 'Quarta', 'Quinta', 'Sexta', 'Sábado'][weekday],
                    'count': count
                })
            
            return {
                'total_users': total_users,
                'active_users': active_users,
                'total_bookings': total_bookings,
                'bookings_today': bookings_today,
                'bookings_week': bookings_week,
                'bookings_month': bookings_month,
                'popular_rooms': [{'name': room.name, 'count': room.booking_count} for room in popular_rooms],
                'occupancy_by_weekday': occupancy_by_weekday,
                'last_updated': datetime.utcnow().isoformat()
            }
            
        except Exception as e:
            logger.error(f"Erro ao obter estatísticas do dashboard: {str(e)}")
            raise
    
    async def get_bookings_timeline(self, db: Session, days: int = 30) -> List[Dict[str, Any]]:
        """Obter linha do tempo de reservas"""
        try:
            start_date = date.today() - timedelta(days=days)
            
            bookings_timeline = db.query(
                func.date(Booking.start_time).label('date'),
                func.count(Booking.id).label('count')
            ).filter(
                func.date(Booking.start_time) >= start_date
            ).group_by(func.date(Booking.start_time))\
             .order_by(func.date(Booking.start_time)).all()
            
            # Preencher dias sem reservas
            timeline = []
            current_date = start_date
            booking_dict = {booking.date: booking.count for booking in bookings_timeline}
            
            while current_date <= date.today():
                timeline.append({
                    'date': current_date.isoformat(),
                    'count': booking_dict.get(current_date, 0)
                })
                current_date += timedelta(days=1)
            
            return timeline
            
        except Exception as e:
            logger.error(f"Erro ao obter linha do tempo de reservas: {str(e)}")
            raise
    
    async def get_user_activity_report(self, db: Session, days: int = 30) -> List[Dict[str, Any]]:
        """Relatório de atividade dos usuários"""
        try:
            start_date = date.today() - timedelta(days=days)
            
            user_activity = db.query(
                User.username,
                User.full_name,
                func.count(Booking.id).label('booking_count'),
                func.max(Booking.created_at).label('last_booking')
            ).join(Booking, User.id == Booking.user_id, isouter=True)\
             .filter(
                 or_(
                     Booking.created_at >= start_date,
                     Booking.created_at.is_(None)
                 )
             ).group_by(User.id, User.username, User.full_name)\
             .order_by(desc('booking_count')).all()
            
            return [{
                'username': user.username,
                'full_name': user.full_name,
                'booking_count': user.booking_count or 0,
                'last_booking': user.last_booking.isoformat() if user.last_booking else None
            } for user in user_activity]
            
        except Exception as e:
            logger.error(f"Erro ao obter relatório de atividade dos usuários: {str(e)}")
            raise
    
    async def get_resource_utilization_report(self, db: Session) -> Dict[str, Any]:
        """Relatório de utilização de recursos"""
        try:
            # Utilização de salas
            room_utilization = db.query(
                Room.name,
                Room.capacity,
                func.count(Booking.id).label('total_bookings'),
                func.sum(
                    func.extract('epoch', Booking.end_time - Booking.start_time) / 3600
                ).label('total_hours')
            ).join(Booking, Room.id == Booking.room_id, isouter=True)\
             .group_by(Room.id, Room.name, Room.capacity)\
             .order_by(desc('total_bookings')).all()
            
            # Utilização de veículos (se existir)
            vehicle_utilization = []
            try:
                vehicle_utilization = db.query(
                    Vehicle.name,
                    Vehicle.model,
                    func.count(Booking.id).label('total_bookings')
                ).join(Booking, Vehicle.id == Booking.vehicle_id, isouter=True)\
                 .group_by(Vehicle.id, Vehicle.name, Vehicle.model)\
                 .order_by(desc('total_bookings')).all()
            except:
                pass  # Tabela de veículos pode não existir
            
            return {
                'rooms': [{
                    'name': room.name,
                    'capacity': room.capacity,
                    'total_bookings': room.total_bookings or 0,
                    'total_hours': float(room.total_hours or 0),
                    'utilization_rate': (room.total_bookings or 0) / max(room.capacity, 1) * 100
                } for room in room_utilization],
                'vehicles': [{
                    'name': vehicle.name,
                    'model': vehicle.model,
                    'total_bookings': vehicle.total_bookings or 0
                } for vehicle in vehicle_utilization]
            }
            
        except Exception as e:
            logger.error(f"Erro ao obter relatório de utilização de recursos: {str(e)}")
            raise
    
    async def get_peak_hours_analysis(self, db: Session) -> List[Dict[str, Any]]:
        """Análise de horários de pico"""
        try:
            peak_hours = db.query(
                func.extract('hour', Booking.start_time).label('hour'),
                func.count(Booking.id).label('booking_count')
            ).group_by(func.extract('hour', Booking.start_time))\
             .order_by(func.extract('hour', Booking.start_time)).all()
            
            return [{
                'hour': int(hour.hour),
                'hour_label': f"{int(hour.hour):02d}:00",
                'booking_count': hour.booking_count
            } for hour in peak_hours]
            
        except Exception as e:
            logger.error(f"Erro ao obter análise de horários de pico: {str(e)}")
            raise
    
    async def export_bookings_report(self, db: Session, start_date: date, end_date: date) -> List[Dict[str, Any]]:
        """Exportar relatório detalhado de reservas"""
        try:
            bookings = db.query(Booking)\
                .join(User, Booking.user_id == User.id)\
                .join(Room, Booking.room_id == Room.id, isouter=True)\
                .filter(
                    and_(
                        func.date(Booking.start_time) >= start_date,
                        func.date(Booking.start_time) <= end_date
                    )
                ).order_by(Booking.start_time).all()
            
            return [{
                'id': booking.id,
                'user': booking.user.username,
                'user_name': booking.user.full_name,
                'room': booking.room.name if booking.room else 'N/A',
                'title': booking.title,
                'description': booking.description,
                'start_time': booking.start_time.isoformat(),
                'end_time': booking.end_time.isoformat(),
                'status': booking.status,
                'created_at': booking.created_at.isoformat()
            } for booking in bookings]
            
        except Exception as e:
            logger.error(f"Erro ao exportar relatório de reservas: {str(e)}")
            raise

# Instância global do serviço de relatórios
reports_service = ReportsService()

