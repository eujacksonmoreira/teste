import smtplib
import secrets
import hashlib
from datetime import datetime, timedelta
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from typing import Optional
import logging

from config.settings import settings
from app.models.user import User
from app.models.database import get_db

logger = logging.getLogger(__name__)

class EmailService:
    def __init__(self):
        self.smtp_server = getattr(settings, 'SMTP_SERVER', 'smtp.gmail.com')
        self.smtp_port = getattr(settings, 'SMTP_PORT', 587)
        self.smtp_username = getattr(settings, 'SMTP_USERNAME', '')
        self.smtp_password = getattr(settings, 'SMTP_PASSWORD', '')
        self.from_email = getattr(settings, 'FROM_EMAIL', self.smtp_username)
        
    def send_email(self, to_email: str, subject: str, html_content: str) -> bool:
        """Envia um e-mail"""
        try:
            msg = MIMEMultipart('alternative')
            msg['Subject'] = subject
            msg['From'] = self.from_email
            msg['To'] = to_email
            
            html_part = MIMEText(html_content, 'html')
            msg.attach(html_part)
            
            # Para desenvolvimento, apenas log o e-mail
            if not self.smtp_username or not self.smtp_password:
                logger.info(f"EMAIL SIMULADO - Para: {to_email}")
                logger.info(f"Assunto: {subject}")
                logger.info(f"Conteúdo: {html_content}")
                return True
            
            with smtplib.SMTP(self.smtp_server, self.smtp_port) as server:
                server.starttls()
                server.login(self.smtp_username, self.smtp_password)
                server.send_message(msg)
                
            logger.info(f"E-mail enviado com sucesso para {to_email}")
            return True
            
        except Exception as e:
            logger.error(f"Erro ao enviar e-mail para {to_email}: {str(e)}")
            return False
    
    def generate_token(self) -> str:
        """Gera um token seguro"""
        return secrets.token_urlsafe(32)
    
    def hash_token(self, token: str) -> str:
        """Gera hash do token"""
        return hashlib.sha256(token.encode()).hexdigest()
    
    async def send_activation_email(self, user_email: str, user_name: str, activation_token: str) -> bool:
        """Envia e-mail de ativação de conta"""
        activation_url = f"{settings.BASE_URL}/activate-account?token={activation_token}"
        
        html_content = f"""
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="UTF-8">
            <title>Ativação de Conta - Sistema de Agendamento</title>
        </head>
        <body style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
            <div style="background: linear-gradient(135deg, #3FA110, #2E7D0A); color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0;">
                <h1 style="margin: 0; font-size: 28px;">Sistema de Agendamento</h1>
                <p style="margin: 10px 0 0 0; font-size: 16px;">Ativação de Conta</p>
            </div>
            
            <div style="background: white; padding: 30px; border: 1px solid #ddd; border-radius: 0 0 10px 10px;">
                <h2 style="color: #3FA110; margin-top: 0;">Olá, {user_name}!</h2>
                
                <p>Sua conta foi criada com sucesso no Sistema de Agendamento. Para ativar sua conta e definir sua senha, clique no botão abaixo:</p>
                
                <div style="text-align: center; margin: 30px 0;">
                    <a href="{activation_url}" 
                       style="background: #3FA110; color: white; padding: 15px 30px; text-decoration: none; border-radius: 5px; font-weight: bold; display: inline-block;">
                        Ativar Conta e Definir Senha
                    </a>
                </div>
                
                <p style="color: #666; font-size: 14px;">
                    Se o botão não funcionar, copie e cole o link abaixo no seu navegador:<br>
                    <a href="{activation_url}" style="color: #3FA110;">{activation_url}</a>
                </p>
                
                <p style="color: #666; font-size: 14px;">
                    <strong>Importante:</strong> Este link é válido por 24 horas. Após esse período, será necessário solicitar um novo link de ativação.
                </p>
                
                <hr style="border: 1px solid #eee; margin: 30px 0;">
                
                <p style="color: #999; font-size: 12px; text-align: center;">
                    Este e-mail foi enviado automaticamente. Não responda a este e-mail.
                </p>
            </div>
        </body>
        </html>
        """
        
        return self.send_email(user_email, "Ativação de Conta - Sistema de Agendamento", html_content)
    
    async def send_password_reset_email(self, user_email: str, user_name: str, reset_token: str) -> bool:
        """Envia e-mail de reset de senha"""
        reset_url = f"{settings.BASE_URL}/reset-password?token={reset_token}"
        
        html_content = f"""
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="UTF-8">
            <title>Redefinição de Senha - Sistema de Agendamento</title>
        </head>
        <body style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
            <div style="background: linear-gradient(135deg, #3FA110, #2E7D0A); color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0;">
                <h1 style="margin: 0; font-size: 28px;">Sistema de Agendamento</h1>
                <p style="margin: 10px 0 0 0; font-size: 16px;">Redefinição de Senha</p>
            </div>
            
            <div style="background: white; padding: 30px; border: 1px solid #ddd; border-radius: 0 0 10px 10px;">
                <h2 style="color: #3FA110; margin-top: 0;">Olá, {user_name}!</h2>
                
                <p>Recebemos uma solicitação para redefinir a senha da sua conta. Se você fez esta solicitação, clique no botão abaixo para criar uma nova senha:</p>
                
                <div style="text-align: center; margin: 30px 0;">
                    <a href="{reset_url}" 
                       style="background: #3FA110; color: white; padding: 15px 30px; text-decoration: none; border-radius: 5px; font-weight: bold; display: inline-block;">
                        Redefinir Senha
                    </a>
                </div>
                
                <p style="color: #666; font-size: 14px;">
                    Se o botão não funcionar, copie e cole o link abaixo no seu navegador:<br>
                    <a href="{reset_url}" style="color: #3FA110;">{reset_url}</a>
                </p>
                
                <p style="color: #666; font-size: 14px;">
                    <strong>Importante:</strong> Este link é válido por 1 hora. Após esse período, será necessário solicitar um novo link de redefinição.
                </p>
                
                <p style="color: #666; font-size: 14px;">
                    Se você não solicitou a redefinição de senha, ignore este e-mail. Sua senha atual continuará válida.
                </p>
                
                <hr style="border: 1px solid #eee; margin: 30px 0;">
                
                <p style="color: #999; font-size: 12px; text-align: center;">
                    Este e-mail foi enviado automaticamente. Não responda a este e-mail.
                </p>
            </div>
        </body>
        </html>
        """
        
        return self.send_email(user_email, "Redefinição de Senha - Sistema de Agendamento", html_content)

# Instância global do serviço de e-mail
email_service = EmailService()

