from sqlalchemy.orm import Session
from typing import Dict, Any, Optional, List
import logging
import json

from app.models.system_config import SystemConfig
from app.models.system_log import SystemLog
from app.models.database import get_db

logger = logging.getLogger(__name__)

class ConfigService:
    def __init__(self):
        self._cache = {}
        self._cache_timestamp = None
    
    async def initialize_default_configs(self, db: Session):
        """Inicializar configurações padrão se não existirem"""
        try:
            existing_configs = db.query(SystemConfig).count()
            if existing_configs > 0:
                return
            
            default_configs = SystemConfig.get_default_configs()
            for config_data in default_configs:
                config = SystemConfig(**config_data)
                db.add(config)
            
            db.commit()
            logger.info("Configurações padrão inicializadas com sucesso")
            
        except Exception as e:
            logger.error(f"Erro ao inicializar configurações padrão: {str(e)}")
            db.rollback()
            raise
    
    async def get_config(self, key: str, db: Session, default_value: Any = None) -> Any:
        """Obter uma configuração específica"""
        try:
            config = db.query(SystemConfig).filter(SystemConfig.key == key).first()
            if config:
                return config.get_typed_value()
            return default_value
        except Exception as e:
            logger.error(f"Erro ao obter configuração {key}: {str(e)}")
            return default_value
    
    async def set_config(self, key: str, value: Any, db: Session, 
                        value_type: str = 'string', category: str = 'custom',
                        description: str = None, is_public: bool = False) -> bool:
        """Definir uma configuração"""
        try:
            config = db.query(SystemConfig).filter(SystemConfig.key == key).first()
            
            # Converter valor para string
            if isinstance(value, bool):
                str_value = 'true' if value else 'false'
                value_type = 'boolean'
            elif isinstance(value, int):
                str_value = str(value)
                value_type = 'integer'
            elif isinstance(value, (dict, list)):
                str_value = json.dumps(value)
                value_type = 'json'
            else:
                str_value = str(value)
            
            if config:
                config.value = str_value
                config.value_type = value_type
                config.updated_at = datetime.utcnow()
            else:
                config = SystemConfig(
                    key=key,
                    value=str_value,
                    value_type=value_type,
                    category=category,
                    description=description,
                    is_public=is_public
                )
                db.add(config)
            
            db.commit()
            
            # Limpar cache
            self._cache.pop(key, None)
            
            logger.info(f"Configuração {key} atualizada com sucesso")
            return True
            
        except Exception as e:
            logger.error(f"Erro ao definir configuração {key}: {str(e)}")
            db.rollback()
            return False
    
    async def get_configs_by_category(self, category: str, db: Session, 
                                    public_only: bool = False) -> List[Dict[str, Any]]:
        """Obter configurações por categoria"""
        try:
            query = db.query(SystemConfig).filter(SystemConfig.category == category)
            
            if public_only:
                query = query.filter(SystemConfig.is_public == True)
            
            configs = query.all()
            
            return [{
                'key': config.key,
                'value': config.get_typed_value(),
                'value_type': config.value_type,
                'category': config.category,
                'description': config.description,
                'is_public': config.is_public
            } for config in configs]
            
        except Exception as e:
            logger.error(f"Erro ao obter configurações da categoria {category}: {str(e)}")
            return []
    
    async def get_public_configs(self, db: Session) -> Dict[str, Any]:
        """Obter todas as configurações públicas"""
        try:
            configs = db.query(SystemConfig).filter(SystemConfig.is_public == True).all()
            
            return {
                config.key: config.get_typed_value() 
                for config in configs
            }
            
        except Exception as e:
            logger.error(f"Erro ao obter configurações públicas: {str(e)}")
            return {}
    
    async def update_multiple_configs(self, configs: Dict[str, Any], db: Session) -> bool:
        """Atualizar múltiplas configurações"""
        try:
            for key, value in configs.items():
                await self.set_config(key, value, db)
            
            return True
            
        except Exception as e:
            logger.error(f"Erro ao atualizar múltiplas configurações: {str(e)}")
            return False

class LogService:
    def __init__(self):
        pass
    
    async def create_log(self, level: str, message: str, db: Session,
                        module: str = None, function: str = None,
                        user_id: int = None, user_ip: str = None,
                        request_id: str = None, extra_data: dict = None) -> bool:
        """Criar um novo log"""
        try:
            log = SystemLog.create_log(
                level=level,
                message=message,
                module=module,
                function=function,
                user_id=user_id,
                user_ip=user_ip,
                request_id=request_id,
                extra_data=extra_data
            )
            
            db.add(log)
            db.commit()
            return True
            
        except Exception as e:
            logger.error(f"Erro ao criar log: {str(e)}")
            db.rollback()
            return False
    
    async def get_logs(self, db: Session, level: str = None, module: str = None,
                      user_id: int = None, limit: int = 100, offset: int = 0) -> List[SystemLog]:
        """Obter logs com filtros"""
        try:
            query = db.query(SystemLog)
            
            if level:
                query = query.filter(SystemLog.level == level.upper())
            
            if module:
                query = query.filter(SystemLog.module == module)
            
            if user_id:
                query = query.filter(SystemLog.user_id == user_id)
            
            logs = query.order_by(SystemLog.created_at.desc())\
                       .offset(offset)\
                       .limit(limit)\
                       .all()
            
            return logs
            
        except Exception as e:
            logger.error(f"Erro ao obter logs: {str(e)}")
            return []
    
    async def get_log_stats(self, db: Session) -> Dict[str, Any]:
        """Obter estatísticas dos logs"""
        try:
            from sqlalchemy import func
            from datetime import datetime, timedelta
            
            # Contagem por nível
            level_counts = db.query(
                SystemLog.level,
                func.count(SystemLog.id).label('count')
            ).group_by(SystemLog.level).all()
            
            # Logs das últimas 24 horas
            yesterday = datetime.utcnow() - timedelta(days=1)
            recent_count = db.query(SystemLog)\
                            .filter(SystemLog.created_at >= yesterday)\
                            .count()
            
            # Total de logs
            total_count = db.query(SystemLog).count()
            
            return {
                'level_counts': {level.level: level.count for level in level_counts},
                'recent_count': recent_count,
                'total_count': total_count
            }
            
        except Exception as e:
            logger.error(f"Erro ao obter estatísticas dos logs: {str(e)}")
            return {}
    
    async def cleanup_old_logs(self, db: Session, days_to_keep: int = 30) -> int:
        """Limpar logs antigos"""
        try:
            from datetime import datetime, timedelta
            
            cutoff_date = datetime.utcnow() - timedelta(days=days_to_keep)
            
            deleted_count = db.query(SystemLog)\
                             .filter(SystemLog.created_at < cutoff_date)\
                             .delete()
            
            db.commit()
            
            logger.info(f"Removidos {deleted_count} logs antigos")
            return deleted_count
            
        except Exception as e:
            logger.error(f"Erro ao limpar logs antigos: {str(e)}")
            db.rollback()
            return 0

# Instâncias globais dos serviços
config_service = ConfigService()
log_service = LogService()

