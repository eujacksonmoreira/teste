from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from typing import Dict, Any, Optional, List
from pydantic import BaseModel
import logging

from app.models.database import get_db
from app.services.config_service import config_service, log_service
from app.utils.dependencies import get_current_active_user
from app.models.user import User

logger = logging.getLogger(__name__)
router = APIRouter()

class ConfigUpdate(BaseModel):
    key: str
    value: Any
    value_type: Optional[str] = 'string'
    category: Optional[str] = 'custom'
    description: Optional[str] = None
    is_public: Optional[bool] = False

class MultipleConfigUpdate(BaseModel):
    configs: Dict[str, Any]

@router.get("/configs/public")
async def get_public_configs(db: Session = Depends(get_db)):
    """Obter configurações públicas (acessível sem autenticação)"""
    try:
        configs = await config_service.get_public_configs(db)
        return configs
    except Exception as e:
        logger.error(f"Erro ao obter configurações públicas: {str(e)}")
        raise HTTPException(status_code=500, detail="Erro interno do servidor")

@router.get("/configs/category/{category}")
async def get_configs_by_category(
    category: str,
    public_only: bool = Query(False),
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """Obter configurações por categoria"""
    try:
        configs = await config_service.get_configs_by_category(
            category, db, public_only
        )
        return {"configs": configs}
    except Exception as e:
        logger.error(f"Erro ao obter configurações da categoria {category}: {str(e)}")
        raise HTTPException(status_code=500, detail="Erro interno do servidor")

@router.get("/configs/{key}")
async def get_config(
    key: str,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """Obter uma configuração específica"""
    try:
        value = await config_service.get_config(key, db)
        if value is None:
            raise HTTPException(status_code=404, detail="Configuração não encontrada")
        
        return {"key": key, "value": value}
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Erro ao obter configuração {key}: {str(e)}")
        raise HTTPException(status_code=500, detail="Erro interno do servidor")

@router.post("/configs")
async def set_config(
    config_data: ConfigUpdate,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """Definir uma configuração"""
    try:
        # Verificar se o usuário é admin
        if not current_user.is_admin:
            raise HTTPException(status_code=403, detail="Acesso negado")
        
        success = await config_service.set_config(
            key=config_data.key,
            value=config_data.value,
            db=db,
            value_type=config_data.value_type,
            category=config_data.category,
            description=config_data.description,
            is_public=config_data.is_public
        )
        
        if success:
            # Log da alteração
            await log_service.create_log(
                level='INFO',
                message=f"Configuração {config_data.key} alterada",
                db=db,
                module='config',
                function='set_config',
                user_id=current_user.id,
                extra_data={'key': config_data.key, 'new_value': config_data.value}
            )
            
            return {"message": "Configuração atualizada com sucesso"}
        else:
            raise HTTPException(status_code=500, detail="Erro ao atualizar configuração")
            
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Erro ao definir configuração: {str(e)}")
        raise HTTPException(status_code=500, detail="Erro interno do servidor")

@router.put("/configs/multiple")
async def update_multiple_configs(
    config_data: MultipleConfigUpdate,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """Atualizar múltiplas configurações"""
    try:
        # Verificar se o usuário é admin
        if not current_user.is_admin:
            raise HTTPException(status_code=403, detail="Acesso negado")
        
        success = await config_service.update_multiple_configs(
            config_data.configs, db
        )
        
        if success:
            # Log da alteração
            await log_service.create_log(
                level='INFO',
                message=f"Múltiplas configurações alteradas",
                db=db,
                module='config',
                function='update_multiple_configs',
                user_id=current_user.id,
                extra_data={'configs_count': len(config_data.configs)}
            )
            
            return {"message": "Configurações atualizadas com sucesso"}
        else:
            raise HTTPException(status_code=500, detail="Erro ao atualizar configurações")
            
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Erro ao atualizar múltiplas configurações: {str(e)}")
        raise HTTPException(status_code=500, detail="Erro interno do servidor")

@router.get("/logs")
async def get_logs(
    level: Optional[str] = Query(None),
    module: Optional[str] = Query(None),
    user_id: Optional[int] = Query(None),
    limit: int = Query(100, ge=1, le=1000),
    offset: int = Query(0, ge=0),
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """Obter logs do sistema"""
    try:
        # Verificar se o usuário é admin
        if not current_user.is_admin:
            raise HTTPException(status_code=403, detail="Acesso negado")
        
        logs = await log_service.get_logs(
            db=db,
            level=level,
            module=module,
            user_id=user_id,
            limit=limit,
            offset=offset
        )
        
        return {
            "logs": [{
                "id": log.id,
                "level": log.level,
                "message": log.message,
                "module": log.module,
                "function": log.function,
                "user_id": log.user_id,
                "user_ip": log.user_ip,
                "request_id": log.request_id,
                "extra_data": log.get_extra_data(),
                "created_at": log.created_at.isoformat(),
                "level_badge_class": log.level_badge_class,
                "level_icon": log.level_icon
            } for log in logs],
            "pagination": {
                "limit": limit,
                "offset": offset,
                "total": len(logs)
            }
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Erro ao obter logs: {str(e)}")
        raise HTTPException(status_code=500, detail="Erro interno do servidor")

@router.get("/logs/stats")
async def get_log_stats(
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """Obter estatísticas dos logs"""
    try:
        # Verificar se o usuário é admin
        if not current_user.is_admin:
            raise HTTPException(status_code=403, detail="Acesso negado")
        
        stats = await log_service.get_log_stats(db)
        return stats
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Erro ao obter estatísticas dos logs: {str(e)}")
        raise HTTPException(status_code=500, detail="Erro interno do servidor")

@router.delete("/logs/cleanup")
async def cleanup_old_logs(
    days_to_keep: int = Query(30, ge=1, le=365),
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """Limpar logs antigos"""
    try:
        # Verificar se o usuário é admin
        if not current_user.is_admin:
            raise HTTPException(status_code=403, detail="Acesso negado")
        
        deleted_count = await log_service.cleanup_old_logs(db, days_to_keep)
        
        # Log da limpeza
        await log_service.create_log(
            level='INFO',
            message=f"Limpeza de logs realizada: {deleted_count} logs removidos",
            db=db,
            module='log',
            function='cleanup_old_logs',
            user_id=current_user.id,
            extra_data={'deleted_count': deleted_count, 'days_to_keep': days_to_keep}
        )
        
        return {
            "message": f"Limpeza concluída: {deleted_count} logs removidos",
            "deleted_count": deleted_count
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Erro ao limpar logs: {str(e)}")
        raise HTTPException(status_code=500, detail="Erro interno do servidor")

