from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List

from app.models.database import get_db
from app.models.user import User
from app.utils.schemas import UserCreate, UserResponse
from app.utils.dependencies import get_admin_user
from app.utils.auth import get_password_hash

router = APIRouter()

@router.post("/", response_model=UserResponse)
async def create_user(
    user_data: UserCreate,
    current_user: User = Depends(get_admin_user),
    db: Session = Depends(get_db)
):
    """Criar novo usuário (apenas admin)"""
    # Verificar se email já existe
    existing_user = db.query(User).filter(User.email == user_data.email).first()
    if existing_user:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Email já está em uso"
        )
    
    # Verificar se username já existe
    existing_username = db.query(User).filter(User.username == user_data.username).first()
    if existing_username:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Nome de usuário já está em uso"
        )
    
    # Criar usuário
    user_dict = user_data.dict(exclude={'password', 'roles'})
    user_dict['password_hash'] = get_password_hash(user_data.password)
    user_dict['is_active'] = False  # Usuário inativo até ativar conta
    
    user = User(**user_dict)
    db.add(user)
    db.commit()
    db.refresh(user)
    
    # Adicionar roles se fornecidas
    if hasattr(user_data, 'roles') and user_data.roles:
        from app.models.permissions import UserRole
        for role_id in user_data.roles:
            user_role = UserRole(user_id=user.id, role_id=role_id)
            db.add(user_role)
        db.commit()
    
    # Enviar email de ativação
    try:
        from app.services.email_service import EmailService
        email_service = EmailService()
        await email_service.send_activation_email(user.email, user.username)
    except Exception as e:
        print(f"Erro ao enviar email de ativação: {e}")
    
    return user

@router.get("/{user_id}/roles")
async def get_user_roles(
    user_id: int,
    current_user: User = Depends(get_admin_user),
    db: Session = Depends(get_db)
):
    """Obter roles do usuário (apenas admin)"""
    from app.models.permissions import UserRole, Role
    
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Usuário não encontrado"
        )
    
    roles = db.query(Role).join(UserRole).filter(UserRole.user_id == user_id).all()
    return {"user_id": user_id, "roles": roles}

@router.put("/{user_id}/roles")
async def update_user_roles(
    user_id: int,
    role_ids: List[int],
    current_user: User = Depends(get_admin_user),
    db: Session = Depends(get_db)
):
    """Atualizar roles do usuário (apenas admin)"""
    from app.models.permissions import UserRole, Role
    
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Usuário não encontrado"
        )
    
    # Verificar se todas as roles existem
    existing_roles = db.query(Role).filter(Role.id.in_(role_ids)).all()
    if len(existing_roles) != len(role_ids):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Uma ou mais roles não existem"
        )
    
    # Remover roles existentes
    db.query(UserRole).filter(UserRole.user_id == user_id).delete()
    
    # Adicionar novas roles
    for role_id in role_ids:
        user_role = UserRole(user_id=user_id, role_id=role_id)
        db.add(user_role)
    
    db.commit()
    
    return {"message": "Roles atualizadas com sucesso"}

@router.post("/{user_id}/reset-password")
async def admin_reset_password(
    user_id: int,
    current_user: User = Depends(get_admin_user),
    db: Session = Depends(get_db)
):
    """Admin resetar senha do usuário"""
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Usuário não encontrado"
        )
    
    # Enviar email de reset de senha
    try:
        from app.services.email_service import EmailService
        email_service = EmailService()
        await email_service.send_password_reset_email(user.email, user.username)
        
        return {"message": "Email de reset de senha enviado com sucesso"}
    except Exception as e:
        print(f"Erro ao enviar email de reset: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Erro ao enviar email de reset de senha"
        )

