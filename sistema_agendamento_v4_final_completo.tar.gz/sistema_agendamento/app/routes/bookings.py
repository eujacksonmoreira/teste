from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.orm import Session
from sqlalchemy import and_, or_
from typing import List, Optional
from datetime import datetime, date

from app.models.database import get_db
from app.models.user import User
from app.models.resources import Room, Vehicle
from app.models.booking import Booking, BookingType, BookingStatus
from app.utils.schemas import (
    BookingCreate, BookingUpdate, BookingResponse,
    ResourceResponse
)
from app.utils.dependencies import get_current_active_user

router = APIRouter()

# Rotas para listar recursos disponíveis
@router.get("/rooms", response_model=List[ResourceResponse])
async def list_available_rooms(
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """Listar salas disponíveis"""
    rooms = db.query(Room).filter(Room.is_active == True).all()
    return rooms

@router.get("/vehicles", response_model=List[ResourceResponse])
async def list_available_vehicles(
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """Listar veículos disponíveis"""
    vehicles = db.query(Vehicle).filter(Vehicle.is_active == True).all()
    return vehicles

# Função auxiliar para verificar conflitos
def check_booking_conflict(
    db: Session,
    resource_id: int,
    resource_type: BookingType,
    start_datetime: datetime,
    end_datetime: datetime,
    exclude_booking_id: Optional[int] = None
) -> bool:
    """Verificar se há conflito de horário para um recurso"""
    query = db.query(Booking).filter(
        and_(
            Booking.status != BookingStatus.CANCELLED,
            or_(
                and_(Booking.room_id == resource_id, resource_type == BookingType.ROOM),
                and_(Booking.vehicle_id == resource_id, resource_type == BookingType.VEHICLE)
            ),
            or_(
                and_(Booking.start_datetime <= start_datetime, Booking.end_datetime > start_datetime),
                and_(Booking.start_datetime < end_datetime, Booking.end_datetime >= end_datetime),
                and_(Booking.start_datetime >= start_datetime, Booking.end_datetime <= end_datetime)
            )
        )
    )
    
    if exclude_booking_id:
        query = query.filter(Booking.id != exclude_booking_id)
    
    return query.first() is not None

# Rotas de reservas
@router.post("/", response_model=BookingResponse)
async def create_booking(
    booking_data: BookingCreate,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """Criar nova reserva"""
    # Determinar tipo de reserva e recurso
    if booking_data.room_id:
        resource_type = BookingType.ROOM
        resource_id = booking_data.room_id
        
        # Verificar se sala existe e está ativa
        room = db.query(Room).filter(Room.id == resource_id, Room.is_active == True).first()
        if not room:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Sala não encontrada ou inativa"
            )
    
    elif booking_data.vehicle_id:
        resource_type = BookingType.VEHICLE
        resource_id = booking_data.vehicle_id
        
        # Verificar se veículo existe e está ativo
        vehicle = db.query(Vehicle).filter(Vehicle.id == resource_id, Vehicle.is_active == True).first()
        if not vehicle:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Veículo não encontrado ou inativo"
            )
    
    else:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Deve ser especificada uma sala ou veículo"
        )
    
    # Verificar conflitos de horário
    if check_booking_conflict(
        db, resource_id, resource_type, 
        booking_data.start_datetime, booking_data.end_datetime
    ):
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="Já existe uma reserva neste horário para o recurso selecionado"
        )
    
    # Criar reserva
    booking = Booking(
        user_id=current_user.id,
        room_id=booking_data.room_id,
        vehicle_id=booking_data.vehicle_id,
        booking_type=resource_type,
        title=booking_data.title,
        description=booking_data.description,
        start_datetime=booking_data.start_datetime,
        end_datetime=booking_data.end_datetime,
        status=BookingStatus.CONFIRMED
    )
    
    db.add(booking)
    db.commit()
    db.refresh(booking)
    
    return booking

@router.get("/", response_model=List[BookingResponse])
async def list_bookings(
    skip: int = 0,
    limit: int = 100,
    start_date: Optional[date] = Query(None, description="Data de início para filtrar reservas"),
    end_date: Optional[date] = Query(None, description="Data de fim para filtrar reservas"),
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """Listar reservas do usuário atual"""
    query = db.query(Booking).filter(Booking.user_id == current_user.id)
    
    if start_date:
        query = query.filter(Booking.start_datetime >= start_date)
    if end_date:
        query = query.filter(Booking.start_datetime <= end_date)
    
    bookings = query.offset(skip).limit(limit).all()
    return bookings

@router.get("/all", response_model=List[BookingResponse])
async def list_all_bookings(
    skip: int = 0,
    limit: int = 100,
    start_date: Optional[date] = Query(None),
    end_date: Optional[date] = Query(None),
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """Listar todas as reservas (para visualização geral)"""
    query = db.query(Booking).filter(Booking.status != BookingStatus.CANCELLED)
    
    if start_date:
        query = query.filter(Booking.start_datetime >= start_date)
    if end_date:
        query = query.filter(Booking.start_datetime <= end_date)
    
    bookings = query.offset(skip).limit(limit).all()
    return bookings

@router.get("/{booking_id}", response_model=BookingResponse)
async def get_booking(
    booking_id: int,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """Obter reserva por ID"""
    booking = db.query(Booking).filter(Booking.id == booking_id).first()
    if not booking:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Reserva não encontrada"
        )
    
    # Usuários podem ver apenas suas próprias reservas, admins podem ver todas
    if not current_user.is_admin and booking.user_id != current_user.id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Acesso negado"
        )
    
    return booking

@router.put("/{booking_id}", response_model=BookingResponse)
async def update_booking(
    booking_id: int,
    booking_update: BookingUpdate,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """Atualizar reserva"""
    booking = db.query(Booking).filter(Booking.id == booking_id).first()
    if not booking:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Reserva não encontrada"
        )
    
    # Apenas o dono da reserva ou admin pode editar
    if not current_user.is_admin and booking.user_id != current_user.id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Acesso negado"
        )
    
    # Se alterando horários, verificar conflitos
    update_data = booking_update.dict(exclude_unset=True)
    if 'start_datetime' in update_data or 'end_datetime' in update_data:
        new_start = update_data.get('start_datetime', booking.start_datetime)
        new_end = update_data.get('end_datetime', booking.end_datetime)
        
        resource_id = booking.room_id if booking.room_id else booking.vehicle_id
        resource_type = BookingType.ROOM if booking.room_id else BookingType.VEHICLE
        
        if check_booking_conflict(db, resource_id, resource_type, new_start, new_end, booking.id):
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail="Já existe uma reserva neste horário para o recurso"
            )
    
    # Atualizar campos
    for field, value in update_data.items():
        setattr(booking, field, value)
    
    db.commit()
    db.refresh(booking)
    return booking

@router.delete("/{booking_id}")
async def cancel_booking(
    booking_id: int,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """Cancelar reserva"""
    booking = db.query(Booking).filter(Booking.id == booking_id).first()
    if not booking:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Reserva não encontrada"
        )
    
    # Apenas o dono da reserva ou admin pode cancelar
    if not current_user.is_admin and booking.user_id != current_user.id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Acesso negado"
        )
    
    booking.status = BookingStatus.CANCELLED
    db.commit()
    
    return {"message": "Reserva cancelada com sucesso"}

