from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.orm import Session
from typing import List, Optional
from datetime import date, datetime, timedelta

from app.models.database import get_db
from app.models.user import User
from app.models.schedule import WeeklySchedule, DayOfWeek, Period
from app.utils.schemas import (
    WeeklyScheduleCreate, WeeklyScheduleUpdate, WeeklyScheduleResponse
)
from app.utils.dependencies import get_current_active_user

router = APIRouter()

def get_week_start_date(target_date: date) -> date:
    """Obter a data de início da semana (segunda-feira) para uma data específica"""
    days_since_monday = target_date.weekday()
    week_start = target_date - timedelta(days=days_since_monday)
    return week_start

@router.post("/", response_model=WeeklyScheduleResponse)
async def create_schedule_entry(
    schedule_data: WeeklyScheduleCreate,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """Criar entrada na agenda semanal"""
    # Verificar se já existe entrada para este usuário, semana, dia e período
    existing_entry = db.query(WeeklySchedule).filter(
        WeeklySchedule.user_id == current_user.id,
        WeeklySchedule.week_start_date == schedule_data.week_start_date,
        WeeklySchedule.day_of_week == schedule_data.day_of_week,
        WeeklySchedule.period == schedule_data.period
    ).first()
    
    if existing_entry:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="Já existe uma entrada para este dia e período"
        )
    
    # Criar nova entrada
    schedule_entry = WeeklySchedule(
        user_id=current_user.id,
        **schedule_data.dict()
    )
    
    db.add(schedule_entry)
    db.commit()
    db.refresh(schedule_entry)
    
    return schedule_entry

@router.get("/", response_model=List[WeeklyScheduleResponse])
async def get_user_schedule(
    week_start_date: Optional[date] = Query(None, description="Data de início da semana"),
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """Obter agenda semanal do usuário atual"""
    query = db.query(WeeklySchedule).filter(WeeklySchedule.user_id == current_user.id)
    
    if week_start_date:
        query = query.filter(WeeklySchedule.week_start_date == week_start_date)
    
    schedule_entries = query.order_by(
        WeeklySchedule.week_start_date,
        WeeklySchedule.day_of_week,
        WeeklySchedule.period
    ).all()
    
    return schedule_entries

@router.get("/current-week", response_model=List[WeeklyScheduleResponse])
async def get_current_week_schedule(
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """Obter agenda da semana atual"""
    today = date.today()
    week_start = get_week_start_date(today)
    
    schedule_entries = db.query(WeeklySchedule).filter(
        WeeklySchedule.user_id == current_user.id,
        WeeklySchedule.week_start_date == week_start
    ).order_by(
        WeeklySchedule.day_of_week,
        WeeklySchedule.period
    ).all()
    
    return schedule_entries

@router.get("/team", response_model=List[WeeklyScheduleResponse])
async def get_team_schedule(
    week_start_date: Optional[date] = Query(None, description="Data de início da semana"),
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """Obter agenda semanal de toda a equipe"""
    if not week_start_date:
        today = date.today()
        week_start_date = get_week_start_date(today)
    
    schedule_entries = db.query(WeeklySchedule).filter(
        WeeklySchedule.week_start_date == week_start_date
    ).order_by(
        WeeklySchedule.user_id,
        WeeklySchedule.day_of_week,
        WeeklySchedule.period
    ).all()
    
    return schedule_entries

@router.get("/{schedule_id}", response_model=WeeklyScheduleResponse)
async def get_schedule_entry(
    schedule_id: int,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """Obter entrada específica da agenda"""
    schedule_entry = db.query(WeeklySchedule).filter(WeeklySchedule.id == schedule_id).first()
    
    if not schedule_entry:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Entrada da agenda não encontrada"
        )
    
    # Usuários podem ver apenas suas próprias entradas, admins podem ver todas
    if not current_user.is_admin and schedule_entry.user_id != current_user.id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Acesso negado"
        )
    
    return schedule_entry

@router.put("/{schedule_id}", response_model=WeeklyScheduleResponse)
async def update_schedule_entry(
    schedule_id: int,
    schedule_update: WeeklyScheduleUpdate,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """Atualizar entrada da agenda"""
    schedule_entry = db.query(WeeklySchedule).filter(WeeklySchedule.id == schedule_id).first()
    
    if not schedule_entry:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Entrada da agenda não encontrada"
        )
    
    # Apenas o dono da entrada ou admin pode editar
    if not current_user.is_admin and schedule_entry.user_id != current_user.id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Acesso negado"
        )
    
    # Atualizar campos fornecidos
    update_data = schedule_update.dict(exclude_unset=True)
    for field, value in update_data.items():
        setattr(schedule_entry, field, value)
    
    db.commit()
    db.refresh(schedule_entry)
    return schedule_entry

@router.delete("/{schedule_id}")
async def delete_schedule_entry(
    schedule_id: int,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """Deletar entrada da agenda"""
    schedule_entry = db.query(WeeklySchedule).filter(WeeklySchedule.id == schedule_id).first()
    
    if not schedule_entry:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Entrada da agenda não encontrada"
        )
    
    # Apenas o dono da entrada ou admin pode deletar
    if not current_user.is_admin and schedule_entry.user_id != current_user.id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Acesso negado"
        )
    
    db.delete(schedule_entry)
    db.commit()
    
    return {"message": "Entrada da agenda deletada com sucesso"}

@router.post("/bulk-create")
async def create_week_schedule(
    week_start_date: date,
    schedule_data: List[dict],
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """Criar agenda completa para uma semana"""
    # Validar formato dos dados
    valid_days = [day.value for day in DayOfWeek]
    valid_periods = [period.value for period in Period]
    
    created_entries = []
    
    for entry_data in schedule_data:
        if 'day_of_week' not in entry_data or 'period' not in entry_data:
            continue
            
        if entry_data['day_of_week'] not in valid_days or entry_data['period'] not in valid_periods:
            continue
            
        # Verificar se já existe entrada
        existing_entry = db.query(WeeklySchedule).filter(
            WeeklySchedule.user_id == current_user.id,
            WeeklySchedule.week_start_date == week_start_date,
            WeeklySchedule.day_of_week == entry_data['day_of_week'],
            WeeklySchedule.period == entry_data['period']
        ).first()
        
        if existing_entry:
            # Atualizar entrada existente
            for field, value in entry_data.items():
                if field in ['location', 'activity', 'description'] and value:
                    setattr(existing_entry, field, value)
            created_entries.append(existing_entry)
        else:
            # Criar nova entrada
            schedule_entry = WeeklySchedule(
                user_id=current_user.id,
                week_start_date=week_start_date,
                day_of_week=entry_data['day_of_week'],
                period=entry_data['period'],
                location=entry_data.get('location', ''),
                activity=entry_data.get('activity', ''),
                description=entry_data.get('description', '')
            )
            db.add(schedule_entry)
            created_entries.append(schedule_entry)
    
    db.commit()
    
    return {"message": f"Agenda criada/atualizada com {len(created_entries)} entradas"}

