from fastapi import APIRouter, HTTPException, Depends, Form, Request
from fastapi.responses import HTMLResponse
from sqlalchemy.orm import Session
from pydantic import BaseModel, EmailStr
from typing import Optional
import logging

from app.models.database import get_db
from app.models.user import User
from app.models.user_token import UserToken
from app.services.email_service import email_service
from app.utils.auth import get_password_hash

logger = logging.getLogger(__name__)
router = APIRouter()

class ActivationRequest(BaseModel):
    token: str
    password: str
    confirm_password: str

class PasswordResetRequest(BaseModel):
    email: EmailStr

class PasswordResetConfirm(BaseModel):
    token: str
    password: str
    confirm_password: str

@router.get("/activate-account", response_class=HTMLResponse)
async def activate_account_page(request: Request, token: Optional[str] = None):
    """Página de ativação de conta"""
    return templates.TemplateResponse("activate_account.html", {
        "request": request,
        "token": token
    })

@router.post("/api/auth/activate-account")
async def activate_account(
    activation_data: ActivationRequest,
    db: Session = Depends(get_db)
):
    """Ativar conta e definir senha"""
    try:
        # Verificar se as senhas coincidem
        if activation_data.password != activation_data.confirm_password:
            raise HTTPException(status_code=400, detail="As senhas não coincidem")
        
        if len(activation_data.password) < 6:
            raise HTTPException(status_code=400, detail="A senha deve ter pelo menos 6 caracteres")
        
        # Buscar token
        token_hash = email_service.hash_token(activation_data.token)
        user_token = db.query(UserToken).filter(
            UserToken.token_hash == token_hash,
            UserToken.token_type == 'activation'
        ).first()
        
        if not user_token:
            raise HTTPException(status_code=400, detail="Token inválido")
        
        if not user_token.is_valid():
            raise HTTPException(status_code=400, detail="Token expirado ou já utilizado")
        
        # Buscar usuário
        user = db.query(User).filter(User.id == user_token.user_id).first()
        if not user:
            raise HTTPException(status_code=400, detail="Usuário não encontrado")
        
        # Ativar conta e definir senha
        user.is_active = True
        user.hashed_password = get_password_hash(activation_data.password)
        
        # Marcar token como usado
        user_token.used = True
        
        db.commit()
        
        logger.info(f"Conta ativada com sucesso para o usuário: {user.username}")
        
        return {"message": "Conta ativada com sucesso! Você já pode fazer login."}
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Erro ao ativar conta: {str(e)}")
        db.rollback()
        raise HTTPException(status_code=500, detail="Erro interno do servidor")

@router.get("/reset-password", response_class=HTMLResponse)
async def reset_password_page(request: Request, token: Optional[str] = None):
    """Página de reset de senha"""
    return templates.TemplateResponse("reset_password.html", {
        "request": request,
        "token": token
    })

@router.post("/api/auth/request-password-reset")
async def request_password_reset(
    reset_data: PasswordResetRequest,
    db: Session = Depends(get_db)
):
    """Solicitar reset de senha"""
    try:
        # Buscar usuário por e-mail
        user = db.query(User).filter(User.email == reset_data.email).first()
        
        # Sempre retornar sucesso por segurança (não revelar se e-mail existe)
        if not user:
            return {"message": "Se o e-mail estiver cadastrado, você receberá as instruções para redefinir sua senha."}
        
        # Invalidar tokens de reset anteriores
        db.query(UserToken).filter(
            UserToken.user_id == user.id,
            UserToken.token_type == 'password_reset',
            UserToken.used == False
        ).update({"used": True})
        
        # Gerar novo token
        reset_token = email_service.generate_token()
        token_hash = email_service.hash_token(reset_token)
        
        # Criar registro do token
        user_token = UserToken.create_password_reset_token(user.id, token_hash)
        db.add(user_token)
        db.commit()
        
        # Enviar e-mail
        await email_service.send_password_reset_email(
            user.email,
            user.full_name or user.username,
            reset_token
        )
        
        logger.info(f"E-mail de reset de senha enviado para: {user.email}")
        
        return {"message": "Se o e-mail estiver cadastrado, você receberá as instruções para redefinir sua senha."}
        
    except Exception as e:
        logger.error(f"Erro ao solicitar reset de senha: {str(e)}")
        db.rollback()
        raise HTTPException(status_code=500, detail="Erro interno do servidor")

@router.post("/api/auth/reset-password")
async def reset_password(
    reset_data: PasswordResetConfirm,
    db: Session = Depends(get_db)
):
    """Confirmar reset de senha"""
    try:
        # Verificar se as senhas coincidem
        if reset_data.password != reset_data.confirm_password:
            raise HTTPException(status_code=400, detail="As senhas não coincidem")
        
        if len(reset_data.password) < 6:
            raise HTTPException(status_code=400, detail="A senha deve ter pelo menos 6 caracteres")
        
        # Buscar token
        token_hash = email_service.hash_token(reset_data.token)
        user_token = db.query(UserToken).filter(
            UserToken.token_hash == token_hash,
            UserToken.token_type == 'password_reset'
        ).first()
        
        if not user_token:
            raise HTTPException(status_code=400, detail="Token inválido")
        
        if not user_token.is_valid():
            raise HTTPException(status_code=400, detail="Token expirado ou já utilizado")
        
        # Buscar usuário
        user = db.query(User).filter(User.id == user_token.user_id).first()
        if not user:
            raise HTTPException(status_code=400, detail="Usuário não encontrado")
        
        # Atualizar senha
        user.hashed_password = get_password_hash(reset_data.password)
        
        # Marcar token como usado
        user_token.used = True
        
        db.commit()
        
        logger.info(f"Senha redefinida com sucesso para o usuário: {user.username}")
        
        return {"message": "Senha redefinida com sucesso! Você já pode fazer login com a nova senha."}
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Erro ao redefinir senha: {str(e)}")
        db.rollback()
        raise HTTPException(status_code=500, detail="Erro interno do servidor")

@router.post("/api/admin/reset-user-password")
async def admin_reset_user_password(
    user_id: int = Form(...),
    db: Session = Depends(get_db)
    # TODO: Adicionar verificação de permissão de admin
):
    """Admin pode resetar senha de qualquer usuário"""
    try:
        # Buscar usuário
        user = db.query(User).filter(User.id == user_id).first()
        if not user:
            raise HTTPException(status_code=404, detail="Usuário não encontrado")
        
        # Invalidar tokens de reset anteriores
        db.query(UserToken).filter(
            UserToken.user_id == user.id,
            UserToken.token_type == 'password_reset',
            UserToken.used == False
        ).update({"used": True})
        
        # Gerar novo token
        reset_token = email_service.generate_token()
        token_hash = email_service.hash_token(reset_token)
        
        # Criar registro do token
        user_token = UserToken.create_password_reset_token(user.id, token_hash)
        db.add(user_token)
        db.commit()
        
        # Enviar e-mail
        await email_service.send_password_reset_email(
            user.email,
            user.full_name or user.username,
            reset_token
        )
        
        logger.info(f"Admin solicitou reset de senha para usuário: {user.username}")
        
        return {"message": f"E-mail de redefinição de senha enviado para {user.email}"}
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Erro ao resetar senha do usuário: {str(e)}")
        db.rollback()
        raise HTTPException(status_code=500, detail="Erro interno do servidor")

