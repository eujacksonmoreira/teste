from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List

from app.models.database import get_db
from app.models.user import User, Profile
from app.utils.schemas import (
    UserResponse, UserUpdate, ProfileCreate, 
    ProfileUpdate, ProfileResponse
)
from app.utils.dependencies import get_current_active_user, get_admin_user
from app.utils.auth import get_password_hash

router = APIRouter()

# Rotas de usuários
@router.get("/", response_model=List[UserResponse])
async def list_users(
    skip: int = 0,
    limit: int = 100,
    current_user: User = Depends(get_admin_user),
    db: Session = Depends(get_db)
):
    """Listar todos os usuários (apenas admin)"""
    users = db.query(User).offset(skip).limit(limit).all()
    return users

@router.get("/{user_id}", response_model=UserResponse)
async def get_user(
    user_id: int,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """Obter usuário por ID"""
    # Usuários podem ver apenas seu próprio perfil, admins podem ver qualquer um
    if not current_user.is_admin and current_user.id != user_id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Acesso negado"
        )
    
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Usuário não encontrado"
        )
    
    return user

@router.put("/{user_id}", response_model=UserResponse)
async def update_user(
    user_id: int,
    user_update: UserUpdate,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """Atualizar usuário"""
    # Usuários podem editar apenas seu próprio perfil, admins podem editar qualquer um
    if not current_user.is_admin and current_user.id != user_id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Acesso negado"
        )
    
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Usuário não encontrado"
        )
    
    # Atualizar campos fornecidos
    update_data = user_update.dict(exclude_unset=True)
    
    # Tratar senha separadamente
    if 'password' in update_data:
        update_data['password_hash'] = get_password_hash(update_data.pop('password'))
    
    # Atualizar roles se fornecidas (apenas admin)
    if 'roles' in update_data and current_user.is_admin:
        from app.models.permissions import UserRole
        # Remover roles existentes
        db.query(UserRole).filter(UserRole.user_id == user_id).delete()
        
        # Adicionar novas roles
        for role_id in update_data.pop('roles'):
            user_role = UserRole(user_id=user_id, role_id=role_id)
            db.add(user_role)
    
    # Atualizar outros campos
    for field, value in update_data.items():
        if hasattr(user, field):
            setattr(user, field, value)
    
    db.commit()
    db.refresh(user)
    return user

@router.delete("/{user_id}")
async def delete_user(
    user_id: int,
    current_user: User = Depends(get_admin_user),
    db: Session = Depends(get_db)
):
    """Deletar usuário (apenas admin)"""
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Usuário não encontrado"
        )
    
    # Não permitir deletar o próprio usuário admin
    if user.id == current_user.id:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Não é possível deletar seu próprio usuário"
        )
    
    db.delete(user)
    db.commit()
    return {"message": "Usuário deletado com sucesso"}

# Rotas de perfil
@router.get("/{user_id}/profile", response_model=ProfileResponse)
async def get_user_profile(
    user_id: int,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """Obter perfil do usuário"""
    # Verificar permissão
    if not current_user.is_admin and current_user.id != user_id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Acesso negado"
        )
    
    profile = db.query(Profile).filter(Profile.user_id == user_id).first()
    if not profile:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Perfil não encontrado"
        )
    
    return profile

@router.post("/{user_id}/profile", response_model=ProfileResponse)
async def create_user_profile(
    user_id: int,
    profile_data: ProfileCreate,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """Criar perfil do usuário"""
    # Verificar permissão
    if not current_user.is_admin and current_user.id != user_id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Acesso negado"
        )
    
    # Verificar se usuário existe
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Usuário não encontrado"
        )
    
    # Verificar se perfil já existe
    existing_profile = db.query(Profile).filter(Profile.user_id == user_id).first()
    if existing_profile:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Perfil já existe para este usuário"
        )
    
    # Criar perfil
    profile = Profile(user_id=user_id, **profile_data.dict())
    db.add(profile)
    db.commit()
    db.refresh(profile)
    
    return profile

@router.put("/{user_id}/profile", response_model=ProfileResponse)
async def update_user_profile(
    user_id: int,
    profile_update: ProfileUpdate,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """Atualizar perfil do usuário"""
    # Verificar permissão
    if not current_user.is_admin and current_user.id != user_id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Acesso negado"
        )
    
    profile = db.query(Profile).filter(Profile.user_id == user_id).first()
    if not profile:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Perfil não encontrado"
        )
    
    # Atualizar campos fornecidos
    update_data = profile_update.dict(exclude_unset=True)
    for field, value in update_data.items():
        setattr(profile, field, value)
    
    db.commit()
    db.refresh(profile)
    return profile


from fastapi import UploadFile, File
import os
import uuid
from pathlib import Path

@router.post("/{user_id}/avatar")
async def upload_avatar(
    user_id: int,
    avatar: UploadFile = File(...),
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """Upload de avatar do usuário"""
    # Verificar permissão
    if not current_user.is_admin and current_user.id != user_id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Acesso negado"
        )
    
    # Verificar se usuário existe
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Usuário não encontrado"
        )
    
    # Validar tipo de arquivo
    if not avatar.content_type.startswith('image/'):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Apenas arquivos de imagem são permitidos"
        )
    
    # Validar tamanho (máximo 5MB)
    if avatar.size > 5 * 1024 * 1024:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Arquivo muito grande. Máximo 5MB"
        )
    
    # Criar diretório se não existir
    upload_dir = Path("static/uploads/avatars")
    upload_dir.mkdir(parents=True, exist_ok=True)
    
    # Gerar nome único para o arquivo
    file_extension = avatar.filename.split('.')[-1]
    filename = f"{uuid.uuid4()}.{file_extension}"
    file_path = upload_dir / filename
    
    # Salvar arquivo
    with open(file_path, "wb") as buffer:
        content = await avatar.read()
        buffer.write(content)
    
    # Atualizar ou criar perfil com URL do avatar
    profile = db.query(Profile).filter(Profile.user_id == user_id).first()
    avatar_url = f"/static/uploads/avatars/{filename}"
    
    if profile:
        # Remover avatar anterior se existir
        if profile.avatar_url and profile.avatar_url.startswith('/static/uploads/'):
            old_file_path = Path(profile.avatar_url[1:])  # Remove '/' inicial
            if old_file_path.exists():
                old_file_path.unlink()
        
        profile.avatar_url = avatar_url
    else:
        # Criar novo perfil
        profile = Profile(user_id=user_id, avatar_url=avatar_url)
        db.add(profile)
    
    db.commit()
    db.refresh(profile)
    
    return {"avatar_url": avatar_url}

