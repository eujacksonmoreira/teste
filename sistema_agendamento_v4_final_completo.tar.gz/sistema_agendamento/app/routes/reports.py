from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from datetime import date, datetime
from typing import Optional, List
import logging

from app.models.database import get_db
from app.services.reports_service import reports_service
from app.utils.dependencies import get_current_active_user
from app.models.user import User

logger = logging.getLogger(__name__)
router = APIRouter()

@router.get("/dashboard/stats")
async def get_dashboard_stats(
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """Obter estatísticas para o dashboard"""
    try:
        stats = await reports_service.get_dashboard_stats(db)
        return stats
    except Exception as e:
        logger.error(f"Erro ao obter estatísticas do dashboard: {str(e)}")
        raise HTTPException(status_code=500, detail="Erro interno do servidor")

@router.get("/dashboard/timeline")
async def get_bookings_timeline(
    days: int = Query(30, ge=1, le=365),
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """Obter linha do tempo de reservas"""
    try:
        timeline = await reports_service.get_bookings_timeline(db, days)
        return {"timeline": timeline}
    except Exception as e:
        logger.error(f"Erro ao obter linha do tempo: {str(e)}")
        raise HTTPException(status_code=500, detail="Erro interno do servidor")

@router.get("/reports/user-activity")
async def get_user_activity_report(
    days: int = Query(30, ge=1, le=365),
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """Relatório de atividade dos usuários"""
    try:
        report = await reports_service.get_user_activity_report(db, days)
        return {"users": report}
    except Exception as e:
        logger.error(f"Erro ao obter relatório de atividade: {str(e)}")
        raise HTTPException(status_code=500, detail="Erro interno do servidor")

@router.get("/reports/resource-utilization")
async def get_resource_utilization_report(
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """Relatório de utilização de recursos"""
    try:
        report = await reports_service.get_resource_utilization_report(db)
        return report
    except Exception as e:
        logger.error(f"Erro ao obter relatório de utilização: {str(e)}")
        raise HTTPException(status_code=500, detail="Erro interno do servidor")

@router.get("/reports/peak-hours")
async def get_peak_hours_analysis(
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """Análise de horários de pico"""
    try:
        analysis = await reports_service.get_peak_hours_analysis(db)
        return {"peak_hours": analysis}
    except Exception as e:
        logger.error(f"Erro ao obter análise de horários: {str(e)}")
        raise HTTPException(status_code=500, detail="Erro interno do servidor")

@router.get("/reports/bookings/export")
async def export_bookings_report(
    start_date: date = Query(..., description="Data de início (YYYY-MM-DD)"),
    end_date: date = Query(..., description="Data de fim (YYYY-MM-DD)"),
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """Exportar relatório detalhado de reservas"""
    try:
        if start_date > end_date:
            raise HTTPException(status_code=400, detail="Data de início deve ser anterior à data de fim")
        
        report = await reports_service.export_bookings_report(db, start_date, end_date)
        return {
            "bookings": report,
            "period": {
                "start_date": start_date.isoformat(),
                "end_date": end_date.isoformat()
            },
            "total_count": len(report)
        }
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Erro ao exportar relatório: {str(e)}")
        raise HTTPException(status_code=500, detail="Erro interno do servidor")

