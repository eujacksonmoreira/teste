// Dark Theme Toggle
class ThemeManager {
    constructor() {
        this.currentTheme = localStorage.getItem('theme') || 'light';
        this.init();
    }
    
    init() {
        // Aplicar tema inicial
        this.applyTheme(this.currentTheme);
        
        // Criar botão de toggle
        this.createToggleButton();
        
        // Event listeners
        this.setupEventListeners();
    }
    
    createToggleButton() {
        const toggleButton = document.createElement('button');
        toggleButton.className = 'theme-toggle';
        toggleButton.innerHTML = this.getToggleIcon();
        toggleButton.setAttribute('aria-label', 'Alternar tema');
        toggleButton.setAttribute('title', 'Alternar entre tema claro e escuro');
        
        document.body.appendChild(toggleButton);
        this.toggleButton = toggleButton;
    }
    
    getToggleIcon() {
        return this.currentTheme === 'dark' 
            ? '<i class="fas fa-sun"></i>' 
            : '<i class="fas fa-moon"></i>';
    }
    
    setupEventListeners() {
        this.toggleButton.addEventListener('click', () => {
            this.toggleTheme();
        });
        
        // Detectar preferência do sistema
        const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
        mediaQuery.addListener((e) => {
            if (!localStorage.getItem('theme')) {
                this.applyTheme(e.matches ? 'dark' : 'light');
            }
        });
    }
    
    toggleTheme() {
        this.currentTheme = this.currentTheme === 'light' ? 'dark' : 'light';
        this.applyTheme(this.currentTheme);
        localStorage.setItem('theme', this.currentTheme);
    }
    
    applyTheme(theme) {
        document.documentElement.setAttribute('data-theme', theme);
        
        if (this.toggleButton) {
            this.toggleButton.innerHTML = this.getToggleIcon();
        }
        
        // Atualizar meta theme-color para mobile
        let metaThemeColor = document.querySelector('meta[name="theme-color"]');
        if (!metaThemeColor) {
            metaThemeColor = document.createElement('meta');
            metaThemeColor.name = 'theme-color';
            document.head.appendChild(metaThemeColor);
        }
        
        metaThemeColor.content = theme === 'dark' ? '#1f2937' : '#f9fafb';
        
        this.currentTheme = theme;
    }
    
    setTheme(theme) {
        if (['light', 'dark'].includes(theme)) {
            this.applyTheme(theme);
            localStorage.setItem('theme', theme);
        }
    }
    
    getCurrentTheme() {
        return this.currentTheme;
    }
}

// Inicializar gerenciador de tema
document.addEventListener('DOMContentLoaded', function() {
    window.themeManager = new ThemeManager();
});

// Utility functions para animações
class AnimationUtils {
    static fadeIn(element, duration = 300) {
        element.style.opacity = '0';
        element.style.display = 'block';
        
        let start = null;
        function animate(timestamp) {
            if (!start) start = timestamp;
            const progress = timestamp - start;
            const opacity = Math.min(progress / duration, 1);
            
            element.style.opacity = opacity;
            
            if (progress < duration) {
                requestAnimationFrame(animate);
            }
        }
        
        requestAnimationFrame(animate);
    }
    
    static slideIn(element, direction = 'left', duration = 300) {
        const transforms = {
            left: 'translateX(-20px)',
            right: 'translateX(20px)',
            up: 'translateY(-20px)',
            down: 'translateY(20px)'
        };
        
        element.style.transform = transforms[direction];
        element.style.opacity = '0';
        element.style.display = 'block';
        
        let start = null;
        function animate(timestamp) {
            if (!start) start = timestamp;
            const progress = timestamp - start;
            const percent = Math.min(progress / duration, 1);
            
            element.style.opacity = percent;
            element.style.transform = `${transforms[direction].replace(/[-\d.]+/, (match) => {
                return parseFloat(match) * (1 - percent);
            })}`;
            
            if (progress < duration) {
                requestAnimationFrame(animate);
            } else {
                element.style.transform = '';
            }
        }
        
        requestAnimationFrame(animate);
    }
    
    static pulse(element, duration = 200) {
        element.style.transform = 'scale(1.05)';
        element.style.transition = `transform ${duration}ms ease-out`;
        
        setTimeout(() => {
            element.style.transform = 'scale(1)';
        }, duration);
    }
}

// Melhorias de UX
document.addEventListener('DOMContentLoaded', function() {
    // Animação de entrada para cards
    const cards = document.querySelectorAll('.card');
    cards.forEach((card, index) => {
        card.style.opacity = '0';
        card.style.transform = 'translateY(20px)';
        
        setTimeout(() => {
            card.style.transition = 'all 0.5s ease-out';
            card.style.opacity = '1';
            card.style.transform = 'translateY(0)';
        }, index * 100);
    });
    
    // Efeito hover melhorado para botões
    const buttons = document.querySelectorAll('.btn');
    buttons.forEach(button => {
        button.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-2px)';
        });
        
        button.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0)';
        });
        
        button.addEventListener('click', function() {
            AnimationUtils.pulse(this);
        });
    });
    
    // Loading states para formulários
    const forms = document.querySelectorAll('form');
    forms.forEach(form => {
        form.addEventListener('submit', function() {
            const submitButton = this.querySelector('button[type="submit"]');
            if (submitButton) {
                const originalText = submitButton.innerHTML;
                submitButton.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Salvando...';
                submitButton.disabled = true;
                
                // Restaurar depois de 3 segundos (fallback)
                setTimeout(() => {
                    submitButton.innerHTML = originalText;
                    submitButton.disabled = false;
                }, 3000);
            }
        });
    });
    
    // Smooth scroll para links internos
    const internalLinks = document.querySelectorAll('a[href^="#"]');
    internalLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });
    
    // Auto-hide alerts
    const alerts = document.querySelectorAll('.alert');
    alerts.forEach(alert => {
        if (!alert.querySelector('.btn-close')) {
            setTimeout(() => {
                alert.style.transition = 'opacity 0.5s ease-out';
                alert.style.opacity = '0';
                setTimeout(() => {
                    alert.remove();
                }, 500);
            }, 5000);
        }
    });
    
    // Melhorar acessibilidade
    const focusableElements = document.querySelectorAll('button, a, input, select, textarea, [tabindex]');
    focusableElements.forEach(element => {
        element.addEventListener('focus', function() {
            this.style.outline = '2px solid var(--sicredi-green)';
            this.style.outlineOffset = '2px';
        });
        
        element.addEventListener('blur', function() {
            this.style.outline = '';
            this.style.outlineOffset = '';
        });
    });
});

// Responsive utilities
class ResponsiveUtils {
    static isMobile() {
        return window.innerWidth <= 768;
    }
    
    static isTablet() {
        return window.innerWidth > 768 && window.innerWidth <= 1024;
    }
    
    static isDesktop() {
        return window.innerWidth > 1024;
    }
    
    static onResize(callback) {
        let timeout;
        window.addEventListener('resize', function() {
            clearTimeout(timeout);
            timeout = setTimeout(callback, 100);
        });
    }
}

// Inicializar utilitários responsivos
ResponsiveUtils.onResize(() => {
    // Ajustar layout baseado no tamanho da tela
    const tables = document.querySelectorAll('.table');
    tables.forEach(table => {
        const wrapper = table.closest('.table-responsive');
        if (ResponsiveUtils.isMobile()) {
            wrapper.style.fontSize = '0.75rem';
        } else {
            wrapper.style.fontSize = '';
        }
    });
});

// Performance optimization
class PerformanceUtils {
    static debounce(func, wait) {
        let timeout;
        return function executedFunction(...args) {
            const later = () => {
                clearTimeout(timeout);
                func(...args);
            };
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
        };
    }
    
    static throttle(func, limit) {
        let inThrottle;
        return function() {
            const args = arguments;
            const context = this;
            if (!inThrottle) {
                func.apply(context, args);
                inThrottle = true;
                setTimeout(() => inThrottle = false, limit);
            }
        };
    }
    
    static lazyLoad(selector) {
        const elements = document.querySelectorAll(selector);
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('fade-in');
                    observer.unobserve(entry.target);
                }
            });
        });
        
        elements.forEach(el => observer.observe(el));
    }
}

// Exportar para uso global
window.AnimationUtils = AnimationUtils;
window.ResponsiveUtils = ResponsiveUtils;
window.PerformanceUtils = PerformanceUtils;

