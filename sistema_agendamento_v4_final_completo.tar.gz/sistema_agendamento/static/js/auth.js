class AuthManager {
    constructor() {
        this.token = localStorage.getItem(\'token\');
        this.user = null;
        this.initPromise = this.init(); // Armazena a promessa de inicialização
    }

    async init() {
        console.log(\'AuthManager: Inicializando...\');
        if (this.token) {
            console.log(\'AuthManager: Token encontrado, tentando obter usuário atual...\');
            try {
                this.user = await this.getCurrentUser(); // Atribui o usuário aqui
                console.log(\'AuthManager: Usuário atual obtido com sucesso:\', this.user);
                this.updateNavbar();
            } catch (error) {
                console.error(\'AuthManager: Erro ao inicializar autenticação (getCurrentUser falhou):\', error);
                if (error.response?.status === 401) {
                    console.log(\'AuthManager: Token inválido ou expirado, limpando autenticação.\');
                    this.clearInvalidAuth();
                }
            }
        } else {
            console.log(\'AuthManager: Nenhum token encontrado.\');
            this.updateNavbar();
        }
        return this; // Retorna a instância para encadeamento
    }

    clearInvalidAuth() {
        console.log(\'AuthManager: Limpando autenticação inválida.\');
        this.token = null;
        this.user = null;
        localStorage.removeItem(\'token\');
        this.updateNavbar();
    }

    async login(username, password) {
        console.log(\'AuthManager: Tentando login para:\', username);
        try {
            const response = await axios.post(\'/api/auth/login-json\', {
                username: username,
                password: password
            });

            this.token = response.data.access_token;
            localStorage.setItem(\'token\', this.token);
            console.log(\'AuthManager: Login bem-sucedido, token recebido.\');
            
            this.user = await this.getCurrentUser(); // Atribui o usuário aqui
            console.log(\'AuthManager: Usuário atual obtido após login:\', this.user);
            this.updateNavbar();
            
            return { success: true, user: this.user };
        } catch (error) {
            console.error(\'AuthManager: Erro no login:\', error);
            return { 
                success: false, 
                message: error.response?.data?.detail || \'Erro ao fazer login\' 
            };
        }
    }

    async getCurrentUser() {
        console.log(\'AuthManager: Obtendo usuário atual...\');
        if (!this.token) {
            console.log(\'AuthManager: getCurrentUser - Token não encontrado.\');
            throw new Error(\'Token não encontrado\');
        }

        try {
            const response = await axios.get(\'/api/auth/me\', {
                headers: { Authorization: `Bearer ${this.token}` }
            });
            
            return response.data; // Retorna os dados do usuário
        } catch (error) {
            console.error(\'AuthManager: getCurrentUser - Erro ao obter usuário atual:\', error);
            throw error;
        }
    }

    logout() {
        console.log(\'AuthManager: Realizando logout.\');
        this.token = null;
        this.user = null;
        localStorage.removeItem(\'token\');
        this.updateNavbar();
        
        showAlert(\'Logout realizado com sucesso!\', \'success\');
    }

    updateNavbar() {
        console.log(\'AuthManager: Atualizando barra de navegação. Usuário logado:\', !!this.user);
        const userDropdown = document.getElementById(\'userDropdown\');
        const loginButton = document.getElementById(\'loginButton\');
        const userName = document.getElementById(\'userName\');
        const adminMenu = document.getElementById(\'adminMenu\');

        if (this.user) {
            if (userDropdown) userDropdown.style.display = \'block\';
            if (loginButton) loginButton.style.display = \'none\';
            if (userName) userName.textContent = this.user.full_name || this.user.username;
            
            if (this.user.is_admin && adminMenu) {
                adminMenu.style.display = \'block\';
            }
        } else {
            if (userDropdown) userDropdown.style.display = \'none\';
            if (loginButton) loginButton.style.display = \'block\';
            if (adminMenu) adminMenu.style.display = \'none\';
        }
    }

    isAuthenticated() {
        const authenticated = !!this.token && !!this.user;
        console.log(\'AuthManager: isAuthenticated - Token:\', !!this.token, \'User:\', !!this.user, \'Result:\', authenticated);
        return authenticated;
    }

    isAdmin() {
        const admin = this.user && this.user.is_admin;
        console.log(\'AuthManager: isAdmin - User:\', !!this.user, \'Is Admin:\', admin);
        return admin;
    }

    getAuthHeaders() {
        if (!this.token) {
            console.log(\'AuthManager: getAuthHeaders - Usuário não autenticado, sem token.\');
            throw new Error(\'Usuário não autenticado\');
        }
        console.log(\'AuthManager: getAuthHeaders - Retornando cabeçalhos de autenticação.\');
        return { Authorization: `Bearer ${this.token}` };
    }

    async makeAuthenticatedRequest(method, url, data = null) {
        console.log(\'AuthManager: Fazendo requisição autenticada para:\', url);
        try {
            const config = {
                method: method,
                url: url,
                headers: this.getAuthHeaders()
            };

            if (data) {
                config.data = data;
            }

            const response = await axios(config);
            console.log(\'AuthManager: Requisição autenticada bem-sucedida para:\', url);
            return { success: true, data: response.data };
        } catch (error) {
            console.error(\'AuthManager: Erro na requisição autenticada para\', url, \':\', error);
            
            if (error.response?.status === 401) {
                console.log(\'AuthManager: Requisição autenticada - 401 recebido. Limpando autenticação.\');
                showAlert(\'Sessão expirada. Por favor, faça login novamente.\', \'warning\');
                this.clearInvalidAuth();
                return { success: false, message: \'Sessão expirada. Faça login novamente.\' };
            }
            
            return { 
                success: false, 
                message: error.response?.data?.detail || \'Erro na requisição\' 
            };
        }
    }
}

const authManager = new AuthManager();

function logout() {
    console.log(\'Global Logout: Chamado.\');
    authManager.logout();
    setTimeout(() => {
        window.location.href = \'/\';
    }, 1000);
}

axios.interceptors.request.use(
    (config) => {
        const token = localStorage.getItem(\'token\');
        if (token && !config.headers.Authorization) {
            console.log(\'Axios Interceptor (Request): Adicionando token ao cabeçalho.\');
            config.headers.Authorization = `Bearer ${token}`;
        }
        return config;
    },
    (error) => {
        console.error(\'Axios Interceptor (Request): Erro na requisição:\', error);
        return Promise.reject(error);
    }
);

axios.interceptors.response.use(
    (response) => response,
    (error) => {
        console.error('Axios Interceptor (Response): Erro na resposta:', error);
        if (error.response?.status === 401 && !error.config._isRetry) {
            console.log('Axios Interceptor (Response): 401 recebido.');
            error.config._isRetry = true;
            authManager.clearInvalidAuth();
            
            // Só redirecionar para login se não estivermos já na página de login
            if (window.location.pathname !== '/login') {
                showAlert("Sessão expirada. Por favor, faça login novamente.", "warning");
                window.location.href = "/login";
            }
        }
        return Promise.reject(error);
    }
);

async function requireAuth() {
    console.log(\'requireAuth: Verificando autenticação...\');
    await authManager.initPromise; // Espera a inicialização do AuthManager
    if (!authManager.isAuthenticated()) {
        console.log(\'requireAuth: Usuário não autenticado, exibindo alerta.\');
        showAlert(\'Você precisa fazer login para acessar esta funcionalidade.\', \'warning\');
        window.location.href = \'/login\'; // Redireciona para login
        return false;
    }
    console.log(\'requireAuth: Usuário autenticado.\');
    return true;
}

async function requireAdmin() {
    console.log(\'requireAdmin: Verificando privilégios de administrador...\');
    await authManager.initPromise; // Espera a inicialização do AuthManager
    if (!authManager.isAuthenticated()) {
        console.log(\'requireAdmin: Usuário não autenticado, exibindo alerta.\');
        showAlert(\'Você precisa fazer login para acessar esta funcionalidade.\', \'warning\');
        window.location.href = \'/login\'; // Redireciona para login
        return false;
    }
    
    if (!authManager.isAdmin()) {
        console.log(\'requireAdmin: Usuário não é administrador, exibindo alerta.\');
        showAlert(\'Acesso negado. Privilégios de administrador necessários.\', \'danger\');
        window.location.href = \'/\'; // Redireciona para home
        return false;
    }
    console.log(\'requireAdmin: Usuário é administrador.\');
    return true;
}
