from pydantic_settings import BaseSettings
from typing import Optional
import os

class Settings(BaseSettings):
    # Configurações do banco de dados
    DATABASE_URL: str = "sqlite:///./sistema_agendamento.db"
    
    # Configurações JWT
    SECRET_KEY: str = "sua-chave-secreta-muito-forte-aqui-123456789"
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 30
    
    # Configurações da aplicação
    APP_NAME: str = "Sistema de Agendamento"
    APP_VERSION: str = "1.0.0"
    DEBUG: bool = True
    
    # Configurações do servidor
    HOST: str = "0.0.0.0"
    PORT: int = 8000
    
    # Configurações de CORS
    ALLOWED_ORIGINS: list = ["*"]
    
    # Configurações de logging
    LOG_LEVEL: str = "INFO"
    LOG_FILE: str = "logs/app.log"
    
    # Configurações de admin padrão
    ADMIN_EMAIL: str = "admin@sistema.com"
    ADMIN_PASSWORD: str = "admin123"
    
    class Config:
        env_file = ".env"
        case_sensitive = True

# Instância global das configurações
settings = Settings()

