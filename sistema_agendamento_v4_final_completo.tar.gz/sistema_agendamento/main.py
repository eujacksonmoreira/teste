from fastapi import FastAPI, Request
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse
import uvicorn
import logging

from config.settings import settings
from config.logging import setup_logging
from app.models.database import engine, Base
from app.routes import auth, users, bookings, schedule, admin, roles, account_activation, reports, system_config, users_admin

# Configurar logging
logger = setup_logging()

# Criar tabelas do banco de dados
Base.metadata.create_all(bind=engine)

# Criar aplicação FastAPI
app = FastAPI(
    title=settings.APP_NAME,
    version=settings.APP_VERSION,
    debug=settings.DEBUG
)

# Configurar CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.ALLOWED_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Configurar arquivos estáticos e templates
app.mount("/static", StaticFiles(directory="static"), name="static")
templates = Jinja2Templates(directory="templates")

# Incluir rotas da API
try:
    app.include_router(auth.router, prefix="/api/auth", tags=["auth"])
    app.include_router(users.router, prefix="/api/users", tags=["users"])
    app.include_router(users_admin.router, prefix="/api/users", tags=["users-admin"])
    app.include_router(bookings.router, prefix="/api/bookings", tags=["bookings"])
    app.include_router(schedule.router, prefix="/api/schedule", tags=["schedule"])
    app.include_router(admin.router, prefix="/api/admin", tags=["admin"])
    app.include_router(roles.router, prefix="/api/roles", tags=["roles"])
    app.include_router(account_activation.router, prefix="/api/account", tags=["account"])
    app.include_router(reports.router, prefix="/api/reports", tags=["reports"])
    app.include_router(system_config.router, prefix="/api/system", tags=["system"])
    logger.info("Rotas da API incluídas com sucesso")
except Exception as e:
    logger.error(f"Erro ao incluir rotas da API: {e}")
    raise

# Rotas das páginas HTML
@app.get("/", response_class=HTMLResponse)
async def home(request: Request):
    """Página inicial do sistema"""
    return templates.TemplateResponse("index.html", {"request": request})

@app.get("/login", response_class=HTMLResponse)
async def login_page(request: Request):
    """Página de login"""
    return templates.TemplateResponse("login_simple.html", {"request": request})

@app.get("/bookings", response_class=HTMLResponse)
async def bookings_page(request: Request):
    """Página de reservas"""
    return templates.TemplateResponse("bookings.html", {"request": request})

@app.get("/schedule", response_class=HTMLResponse)
async def schedule_page(request: Request):
    """Página de agenda semanal"""
    return templates.TemplateResponse("schedule.html", {"request": request})

@app.get("/profile", response_class=HTMLResponse)
async def profile_page(request: Request):
    """Página de perfil"""
    return templates.TemplateResponse("profile.html", {"request": request})

@app.get("/admin/users", response_class=HTMLResponse)
async def user_management_page(request: Request):
    """Página de gerenciamento de usuários"""
    return templates.TemplateResponse("user_management.html", {"request": request})

@app.get("/admin", response_class=HTMLResponse)
async def admin_page(request: Request):
    """Página de administração"""
    return templates.TemplateResponse("admin.html", {"request": request})

@app.get("/dashboard", response_class=HTMLResponse)
async def dashboard_page(request: Request):
    """Página de dashboard analítico"""
    return templates.TemplateResponse("dashboard.html", {"request": request})

@app.get("/system/logs", response_class=HTMLResponse)
async def system_logs_page(request: Request):
    """Página de logs do sistema"""
    return templates.TemplateResponse("system_logs.html", {"request": request})

@app.get("/system/parameters", response_class=HTMLResponse)
async def system_parameters_page(request: Request):
    """Página de parâmetros do sistema"""
    return templates.TemplateResponse("system_parameters.html", {"request": request})

@app.get("/health")
async def health_check():
    """Endpoint para verificação de saúde da aplicação"""
    return {"status": "ok", "message": "Sistema funcionando corretamente"}

@app.on_event("startup")
async def startup_event():
    """Eventos executados na inicialização da aplicação"""
    logger.info(f"Iniciando {settings.APP_NAME} v{settings.APP_VERSION}")
    
    # Criar usuário admin padrão se não existir
    from app.services.user_service import create_default_admin
    await create_default_admin()

@app.on_event("shutdown")
async def shutdown_event():
    """Eventos executados no encerramento da aplicação"""
    logger.info("Encerrando aplicação")

if __name__ == "__main__":
    uvicorn.run(
        "main:app",
        host=settings.HOST,
        port=settings.PORT,
        reload=settings.DEBUG,
        log_level=settings.LOG_LEVEL.lower()
    )

