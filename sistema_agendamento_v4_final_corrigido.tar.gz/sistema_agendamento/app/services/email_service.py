import smtplib
import ssl
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from typing import List, Optional
import logging
from datetime import datetime, timedelta
import secrets
import jwt

from config.settings import settings

logger = logging.getLogger(__name__)

class EmailService:
    def __init__(self):
        self.smtp_host = settings.SMTP_HOST
        self.smtp_port = settings.SMTP_PORT
        self.smtp_username = settings.SMTP_USERNAME
        self.smtp_password = settings.SMTP_PASSWORD
        self.smtp_use_tls = settings.SMTP_USE_TLS
        self.email_from = settings.EMAIL_FROM
        self.email_from_name = settings.EMAIL_FROM_NAME

    def _create_smtp_connection(self):
        """Criar conexão SMTP"""
        try:
            if self.smtp_use_tls:
                context = ssl.create_default_context()
                server = smtplib.SMTP(self.smtp_host, self.smtp_port)
                server.starttls(context=context)
            else:
                server = smtplib.SMTP(self.smtp_host, self.smtp_port)
            
            if self.smtp_username and self.smtp_password:
                server.login(self.smtp_username, self.smtp_password)
            
            return server
        except Exception as e:
            logger.error(f"Erro ao conectar com servidor SMTP: {e}")
            raise

    def send_email(self, to_email: str, subject: str, html_content: str, text_content: Optional[str] = None):
        """Enviar email"""
        try:
            # Se não há configuração de SMTP, simular envio (modo desenvolvimento)
            if not self.smtp_username or not self.smtp_password:
                logger.info(f"[SIMULAÇÃO] Email enviado para {to_email}")
                logger.info(f"[SIMULAÇÃO] Assunto: {subject}")
                logger.info(f"[SIMULAÇÃO] Conteúdo HTML: {html_content}")
                return True

            message = MIMEMultipart("alternative")
            message["Subject"] = subject
            message["From"] = f"{self.email_from_name} <{self.email_from}>"
            message["To"] = to_email

            # Adicionar conteúdo texto se fornecido
            if text_content:
                text_part = MIMEText(text_content, "plain", "utf-8")
                message.attach(text_part)

            # Adicionar conteúdo HTML
            html_part = MIMEText(html_content, "html", "utf-8")
            message.attach(html_part)

            # Enviar email
            with self._create_smtp_connection() as server:
                server.send_message(message)

            logger.info(f"Email enviado com sucesso para {to_email}")
            return True

        except Exception as e:
            logger.error(f"Erro ao enviar email para {to_email}: {e}")
            return False

    def generate_token(self, data: dict, expire_hours: int) -> str:
        """Gerar token JWT para ativação/reset"""
        expire = datetime.utcnow() + timedelta(hours=expire_hours)
        to_encode = data.copy()
        to_encode.update({"exp": expire})
        
        return jwt.encode(to_encode, settings.SECRET_KEY, algorithm=settings.ALGORITHM)

    def verify_token(self, token: str) -> dict:
        """Verificar e decodificar token"""
        try:
            payload = jwt.decode(token, settings.SECRET_KEY, algorithms=[settings.ALGORITHM])
            return payload
        except jwt.ExpiredSignatureError:
            raise ValueError("Token expirado")
        except jwt.JWTError:
            raise ValueError("Token inválido")

    def send_activation_email(self, user_email: str, user_name: str, user_id: int):
        """Enviar email de ativação de conta"""
        # Gerar token de ativação
        token_data = {
            "user_id": user_id,
            "email": user_email,
            "type": "activation"
        }
        token = self.generate_token(token_data, settings.ACTIVATION_TOKEN_EXPIRE_HOURS)
        
        # URL de ativação
        activation_url = f"{settings.FRONTEND_URL}/activate-account?token={token}"
        
        # Conteúdo do email
        subject = "Ative sua conta - Sistema de Agendamento"
        
        html_content = f"""
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="UTF-8">
            <title>Ativação de Conta</title>
            <style>
                body {{ font-family: Arial, sans-serif; line-height: 1.6; color: #333; }}
                .container {{ max-width: 600px; margin: 0 auto; padding: 20px; }}
                .header {{ background: linear-gradient(135deg, #28a745, #20c997); color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0; }}
                .content {{ background: #f8f9fa; padding: 30px; border-radius: 0 0 10px 10px; }}
                .button {{ display: inline-block; background: #007bff; color: white; padding: 12px 30px; text-decoration: none; border-radius: 5px; margin: 20px 0; }}
                .footer {{ text-align: center; margin-top: 30px; color: #666; font-size: 14px; }}
            </style>
        </head>
        <body>
            <div class="container">
                <div class="header">
                    <h1>Bem-vindo ao Sistema de Agendamento!</h1>
                </div>
                <div class="content">
                    <h2>Olá, {user_name}!</h2>
                    <p>Sua conta foi criada com sucesso. Para começar a usar o sistema, você precisa ativar sua conta e definir uma senha.</p>
                    
                    <p>Clique no botão abaixo para ativar sua conta:</p>
                    
                    <a href="{activation_url}" class="button">Ativar Conta</a>
                    
                    <p>Ou copie e cole este link no seu navegador:</p>
                    <p style="word-break: break-all; background: #e9ecef; padding: 10px; border-radius: 5px;">{activation_url}</p>
                    
                    <p><strong>Este link expira em {settings.ACTIVATION_TOKEN_EXPIRE_HOURS} horas.</strong></p>
                    
                    <p>Se você não solicitou esta conta, pode ignorar este email.</p>
                </div>
                <div class="footer">
                    <p>Sistema de Agendamento - {datetime.now().year}</p>
                </div>
            </div>
        </body>
        </html>
        """
        
        text_content = f"""
        Bem-vindo ao Sistema de Agendamento!
        
        Olá, {user_name}!
        
        Sua conta foi criada com sucesso. Para começar a usar o sistema, você precisa ativar sua conta e definir uma senha.
        
        Acesse este link para ativar sua conta:
        {activation_url}
        
        Este link expira em {settings.ACTIVATION_TOKEN_EXPIRE_HOURS} horas.
        
        Se você não solicitou esta conta, pode ignorar este email.
        
        Sistema de Agendamento - {datetime.now().year}
        """
        
        return self.send_email(user_email, subject, html_content, text_content)

    def send_password_reset_email(self, user_email: str, user_name: str, user_id: int):
        """Enviar email de reset de senha"""
        # Gerar token de reset
        token_data = {
            "user_id": user_id,
            "email": user_email,
            "type": "password_reset"
        }
        token = self.generate_token(token_data, settings.RESET_PASSWORD_TOKEN_EXPIRE_HOURS)
        
        # URL de reset
        reset_url = f"{settings.FRONTEND_URL}/reset-password?token={token}"
        
        # Conteúdo do email
        subject = "Redefinir senha - Sistema de Agendamento"
        
        html_content = f"""
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="UTF-8">
            <title>Redefinir Senha</title>
            <style>
                body {{ font-family: Arial, sans-serif; line-height: 1.6; color: #333; }}
                .container {{ max-width: 600px; margin: 0 auto; padding: 20px; }}
                .header {{ background: linear-gradient(135deg, #dc3545, #fd7e14); color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0; }}
                .content {{ background: #f8f9fa; padding: 30px; border-radius: 0 0 10px 10px; }}
                .button {{ display: inline-block; background: #dc3545; color: white; padding: 12px 30px; text-decoration: none; border-radius: 5px; margin: 20px 0; }}
                .footer {{ text-align: center; margin-top: 30px; color: #666; font-size: 14px; }}
                .warning {{ background: #fff3cd; border: 1px solid #ffeaa7; padding: 15px; border-radius: 5px; margin: 20px 0; }}
            </style>
        </head>
        <body>
            <div class="container">
                <div class="header">
                    <h1>Redefinir Senha</h1>
                </div>
                <div class="content">
                    <h2>Olá, {user_name}!</h2>
                    <p>Recebemos uma solicitação para redefinir a senha da sua conta no Sistema de Agendamento.</p>
                    
                    <p>Clique no botão abaixo para criar uma nova senha:</p>
                    
                    <a href="{reset_url}" class="button">Redefinir Senha</a>
                    
                    <p>Ou copie e cole este link no seu navegador:</p>
                    <p style="word-break: break-all; background: #e9ecef; padding: 10px; border-radius: 5px;">{reset_url}</p>
                    
                    <div class="warning">
                        <strong>⚠️ Importante:</strong>
                        <ul>
                            <li>Este link expira em {settings.RESET_PASSWORD_TOKEN_EXPIRE_HOURS} horas</li>
                            <li>Se você não solicitou esta redefinição, ignore este email</li>
                            <li>Sua senha atual permanece válida até que você defina uma nova</li>
                        </ul>
                    </div>
                </div>
                <div class="footer">
                    <p>Sistema de Agendamento - {datetime.now().year}</p>
                </div>
            </div>
        </body>
        </html>
        """
        
        text_content = f"""
        Redefinir Senha - Sistema de Agendamento
        
        Olá, {user_name}!
        
        Recebemos uma solicitação para redefinir a senha da sua conta no Sistema de Agendamento.
        
        Acesse este link para criar uma nova senha:
        {reset_url}
        
        IMPORTANTE:
        - Este link expira em {settings.RESET_PASSWORD_TOKEN_EXPIRE_HOURS} horas
        - Se você não solicitou esta redefinição, ignore este email
        - Sua senha atual permanece válida até que você defina uma nova
        
        Sistema de Agendamento - {datetime.now().year}
        """
        
        return self.send_email(user_email, subject, html_content, text_content)

# Instância global do serviço de email
email_service = EmailService()

