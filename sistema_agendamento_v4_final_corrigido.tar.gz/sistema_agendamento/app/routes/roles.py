from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List

from app.models.database import get_db
from app.models.user import User
from app.models.permissions import Role, Permission, UserRole
from app.utils.dependencies import get_current_active_user, get_admin_user

router = APIRouter()

# Rotas de Roles
@router.get("/", response_model=List[dict])
async def list_roles(
    current_user: User = Depends(get_admin_user),
    db: Session = Depends(get_db)
):
    """Listar todas as roles"""
    roles = db.query(Role).all()
    result = []
    
    for role in roles:
        permissions = db.query(Permission).filter(Permission.role_id == role.id).first()
        result.append({
            "id": role.id,
            "name": role.name,
            "description": role.description,
            "permissions": {
                "can_edit_bookings": permissions.can_edit_bookings if permissions else False,
                "can_edit_schedule": permissions.can_edit_schedule if permissions else False,
                "can_view_all_bookings": permissions.can_view_all_bookings if permissions else False,
                "can_manage_users": permissions.can_manage_users if permissions else False,
                "can_manage_resources": permissions.can_manage_resources if permissions else False,
            },
            "created_at": role.created_at
        })
    
    return result

@router.post("/", response_model=dict)
async def create_role(
    role_data: dict,
    current_user: User = Depends(get_admin_user),
    db: Session = Depends(get_db)
):
    """Criar nova role"""
    # Verificar se role já existe
    existing_role = db.query(Role).filter(Role.name == role_data["name"]).first()
    if existing_role:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Role com este nome já existe"
        )
    
    # Criar role
    role = Role(
        name=role_data["name"],
        description=role_data.get("description", "")
    )
    db.add(role)
    db.commit()
    db.refresh(role)
    
    # Criar permissões
    permissions_data = role_data.get("permissions", {})
    permission = Permission(
        role_id=role.id,
        can_edit_bookings=permissions_data.get("can_edit_bookings", False),
        can_edit_schedule=permissions_data.get("can_edit_schedule", False),
        can_view_all_bookings=permissions_data.get("can_view_all_bookings", False),
        can_manage_users=permissions_data.get("can_manage_users", False),
        can_manage_resources=permissions_data.get("can_manage_resources", False)
    )
    db.add(permission)
    db.commit()
    
    return {
        "id": role.id,
        "name": role.name,
        "description": role.description,
        "permissions": permissions_data
    }

@router.put("/{role_id}", response_model=dict)
async def update_role(
    role_id: int,
    role_data: dict,
    current_user: User = Depends(get_admin_user),
    db: Session = Depends(get_db)
):
    """Atualizar role"""
    role = db.query(Role).filter(Role.id == role_id).first()
    if not role:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Role não encontrada"
        )
    
    # Atualizar role
    role.name = role_data.get("name", role.name)
    role.description = role_data.get("description", role.description)
    
    # Atualizar permissões
    permissions_data = role_data.get("permissions", {})
    permission = db.query(Permission).filter(Permission.role_id == role_id).first()
    
    if permission:
        permission.can_edit_bookings = permissions_data.get("can_edit_bookings", False)
        permission.can_edit_schedule = permissions_data.get("can_edit_schedule", False)
        permission.can_view_all_bookings = permissions_data.get("can_view_all_bookings", False)
        permission.can_manage_users = permissions_data.get("can_manage_users", False)
        permission.can_manage_resources = permissions_data.get("can_manage_resources", False)
    else:
        permission = Permission(
            role_id=role.id,
            can_edit_bookings=permissions_data.get("can_edit_bookings", False),
            can_edit_schedule=permissions_data.get("can_edit_schedule", False),
            can_view_all_bookings=permissions_data.get("can_view_all_bookings", False),
            can_manage_users=permissions_data.get("can_manage_users", False),
            can_manage_resources=permissions_data.get("can_manage_resources", False)
        )
        db.add(permission)
    
    db.commit()
    
    return {
        "id": role.id,
        "name": role.name,
        "description": role.description,
        "permissions": permissions_data
    }

@router.delete("/{role_id}")
async def delete_role(
    role_id: int,
    current_user: User = Depends(get_admin_user),
    db: Session = Depends(get_db)
):
    """Deletar role"""
    role = db.query(Role).filter(Role.id == role_id).first()
    if not role:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Role não encontrada"
        )
    
    # Verificar se há usuários com esta role
    user_roles = db.query(UserRole).filter(UserRole.role_id == role_id).count()
    if user_roles > 0:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Não é possível deletar role que está sendo usada por usuários"
        )
    
    # Deletar permissões associadas
    db.query(Permission).filter(Permission.role_id == role_id).delete()
    
    # Deletar role
    db.delete(role)
    db.commit()
    
    return {"message": "Role deletada com sucesso"}

# Rotas de User Roles
@router.post("/users/{user_id}/roles/{role_id}")
async def assign_role_to_user(
    user_id: int,
    role_id: int,
    current_user: User = Depends(get_admin_user),
    db: Session = Depends(get_db)
):
    """Atribuir role a um usuário"""
    # Verificar se usuário existe
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Usuário não encontrado"
        )
    
    # Verificar se role existe
    role = db.query(Role).filter(Role.id == role_id).first()
    if not role:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Role não encontrada"
        )
    
    # Verificar se usuário já tem esta role
    existing_user_role = db.query(UserRole).filter(
        UserRole.user_id == user_id,
        UserRole.role_id == role_id
    ).first()
    
    if existing_user_role:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Usuário já possui esta role"
        )
    
    # Criar associação
    user_role = UserRole(
        user_id=user_id,
        role_id=role_id,
        assigned_by=current_user.id
    )
    db.add(user_role)
    db.commit()
    
    return {"message": "Role atribuída com sucesso"}

@router.delete("/users/{user_id}/roles/{role_id}")
async def remove_role_from_user(
    user_id: int,
    role_id: int,
    current_user: User = Depends(get_admin_user),
    db: Session = Depends(get_db)
):
    """Remover role de um usuário"""
    user_role = db.query(UserRole).filter(
        UserRole.user_id == user_id,
        UserRole.role_id == role_id
    ).first()
    
    if not user_role:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Usuário não possui esta role"
        )
    
    db.delete(user_role)
    db.commit()
    
    return {"message": "Role removida com sucesso"}

@router.get("/users/{user_id}/roles")
async def get_user_roles(
    user_id: int,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """Obter roles de um usuário"""
    # Verificar permissão
    if not current_user.is_admin and current_user.id != user_id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Acesso negado"
        )
    
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Usuário não encontrado"
        )
    
    # Obter roles do usuário
    user_roles = db.query(UserRole).filter(UserRole.user_id == user_id).all()
    result = []
    
    for user_role in user_roles:
        role = user_role.role
        permissions = db.query(Permission).filter(Permission.role_id == role.id).first()
        
        result.append({
            "id": role.id,
            "name": role.name,
            "description": role.description,
            "permissions": {
                "can_edit_bookings": permissions.can_edit_bookings if permissions else False,
                "can_edit_schedule": permissions.can_edit_schedule if permissions else False,
                "can_view_all_bookings": permissions.can_view_all_bookings if permissions else False,
                "can_manage_users": permissions.can_manage_users if permissions else False,
                "can_manage_resources": permissions.can_manage_resources if permissions else False,
            },
            "assigned_at": user_role.assigned_at
        })
    
    return result

@router.get("/users/{user_id}/permissions")
async def get_user_permissions(
    user_id: int,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    """Obter permissões consolidadas de um usuário"""
    # Verificar permissão
    if not current_user.is_admin and current_user.id != user_id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Acesso negado"
        )
    
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Usuário não encontrado"
        )
    
    return user.get_permissions()

