from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from sqlalchemy import func, and_, or_
from typing import List, Dict, Any
from datetime import datetime, date, timedelta

from app.models.database import get_db
from app.models.user import User, Profile
from app.models.resources import Room, Vehicle
from app.models.booking import Booking
from app.models.schedule import WeeklySchedule
from app.utils.schemas import (
    UserResponse, RoomCreate, RoomUpdate, RoomResponse,
    VehicleCreate, VehicleUpdate, VehicleResponse, UserCreateByAdmin, UserUpdate
)
from app.utils.dependencies import get_admin_user
from app.utils.auth import get_password_hash
from app.services.email_service import email_service

router = APIRouter()

# Relatórios e estatísticas
@router.get("/stats/dashboard")
async def get_dashboard_stats(
    current_user: User = Depends(get_admin_user),
    db: Session = Depends(get_db)
):
    """Obter estatísticas para o dashboard administrativo"""
    today = date.today()
    
    # Contadores básicos
    total_users = db.query(User).filter(User.is_active == True).count()
    total_rooms = db.query(Room).filter(Room.is_active == True).count()
    total_vehicles = db.query(Vehicle).filter(Vehicle.is_active == True).count()
    
    # Reservas de hoje
    reservas_hoje = db.query(Booking).filter(
        func.date(Booking.start_time) == today,
        Booking.status == 'confirmed'
    ).count()
    
    # Reservas por tipo (últimos 30 dias)
    last_30_days = today - timedelta(days=30)
    reservas_por_tipo = db.query(
        Booking.resource_type,
        func.count(Booking.id).label('count')
    ).filter(
        Booking.created_at >= last_30_days
    ).group_by(Booking.resource_type).all()
    
    # Usuários mais ativos (últimos 30 dias)
    usuarios_ativos = db.query(
        User.full_name,
        func.count(Booking.id).label('total_reservas')
    ).join(Booking).filter(
        Booking.created_at >= last_30_days
    ).group_by(User.id, User.full_name).order_by(
        func.count(Booking.id).desc()
    ).limit(5).all()
    
    # Recursos mais utilizados (últimos 30 dias)
    recursos_populares = db.query(
        Booking.resource_type,
        Booking.resource_id,
        func.count(Booking.id).label('total_uso')
    ).filter(
        Booking.created_at >= last_30_days
    ).group_by(
        Booking.resource_type, Booking.resource_id
    ).order_by(
        func.count(Booking.id).desc()
    ).limit(10).all()
    
    # Adicionar nomes dos recursos
    recursos_com_nomes = []
    for recurso in recursos_populares:
        nome = "Recurso Desconhecido"
        if recurso.resource_type == "room":
            room = db.query(Room).filter(Room.id == recurso.resource_id).first()
            if room:
                nome = room.name
        elif recurso.resource_type == "vehicle":
            vehicle = db.query(Vehicle).filter(Vehicle.id == recurso.resource_id).first()
            if vehicle:
                nome = vehicle.name
        
        recursos_com_nomes.append({
            "type": recurso.resource_type,
            "id": recurso.resource_id,
            "name": nome,
            "total_uso": recurso.total_uso
        })
    
    return {
        "total_users": total_users,
        "total_rooms": total_rooms,
        "total_vehicles": total_vehicles,
        "reservas_hoje": reservas_hoje,
        "reservas_por_tipo": [{"type": r.resource_type, "count": r.count} for r in reservas_por_tipo],
        "usuarios_ativos": [{"name": u.full_name, "reservas": u.total_reservas} for u in usuarios_ativos],
        "recursos_populares": recursos_com_nomes
    }

@router.get("/reports/bookings")
async def get_bookings_report(
    start_date: date = None,
    end_date: date = None,
    resource_type: str = None,
    current_user: User = Depends(get_admin_user),
    db: Session = Depends(get_db)
):
    """Relatório detalhado de reservas"""
    query = db.query(Booking).join(User)
    
    # Filtros
    if start_date:
        query = query.filter(func.date(Booking.start_time) >= start_date)
    if end_date:
        query = query.filter(func.date(Booking.end_time) <= end_date)
    if resource_type:
        query = query.filter(Booking.resource_type == resource_type)
    
    bookings = query.order_by(Booking.start_time.desc()).all()
    
    # Formatar dados
    report_data = []
    for booking in bookings:
        resource_name = "Recurso Desconhecido"
        if booking.resource_type == "room":
            room = db.query(Room).filter(Room.id == booking.resource_id).first()
            if room:
                resource_name = room.name
        elif booking.resource_type == "vehicle":
            vehicle = db.query(Vehicle).filter(Vehicle.id == booking.resource_id).first()
            if vehicle:
                resource_name = vehicle.name
        
        report_data.append({
            "id": booking.id,
            "user_name": booking.user.full_name,
            "user_email": booking.user.email,
            "resource_type": booking.resource_type,
            "resource_name": resource_name,
            "title": booking.title,
            "start_time": booking.start_time.isoformat(),
            "end_time": booking.end_time.isoformat(),
            "status": booking.status,
            "created_at": booking.created_at.isoformat()
        })
    
    return {
        "total": len(report_data),
        "bookings": report_data
    }

@router.get("/reports/users")
async def get_users_report(
    current_user: User = Depends(get_admin_user),
    db: Session = Depends(get_db)
):
    """Relatório de usuários"""
    users = db.query(User).outerjoin(Profile).all()
    
    report_data = []
    for user in users:
        # Contar reservas do usuário
        total_reservas = db.query(Booking).filter(Booking.user_id == user.id).count()
        reservas_ativas = db.query(Booking).filter(
            Booking.user_id == user.id,
            Booking.status == 'confirmed',
            Booking.start_time > datetime.utcnow()
        ).count()
        
        report_data.append({
            "id": user.id,
            "username": user.username,
            "full_name": user.full_name,
            "email": user.email,
            "is_active": user.is_active,
            "is_admin": user.is_admin,
            "is_email_verified": user.is_email_verified,
            "department": user.profile.department if user.profile else None,
            "position": user.profile.position if user.profile else None,
            "phone": user.profile.phone if user.profile else None,
            "total_reservas": total_reservas,
            "reservas_ativas": reservas_ativas,
            "created_at": user.created_at.isoformat()
        })
    
    return {
        "total": len(report_data),
        "users": report_data
    }

@router.get("/system/logs")
async def get_system_logs(
    lines: int = 100,
    current_user: User = Depends(get_admin_user)
):
    """Obter logs do sistema"""
    try:
        import os
        from config.settings import settings
        
        log_file = settings.LOG_FILE
        if not os.path.exists(log_file):
            return {"logs": [], "message": "Arquivo de log não encontrado"}
        
        with open(log_file, 'r', encoding='utf-8') as f:
            all_lines = f.readlines()
            recent_lines = all_lines[-lines:] if len(all_lines) > lines else all_lines
        
        return {
            "logs": [line.strip() for line in recent_lines],
            "total_lines": len(all_lines),
            "showing": len(recent_lines)
        }
    except Exception as e:
        return {"logs": [], "error": str(e)}

@router.get("/system/config")
async def get_system_config(
    current_user: User = Depends(get_admin_user)
):
    """Obter configurações do sistema"""
    from config.settings import settings
    
    # Retornar apenas configurações seguras (sem senhas)
    safe_config = {
        "app_name": settings.APP_NAME,
        "app_version": settings.APP_VERSION,
        "debug": settings.DEBUG,
        "host": settings.HOST,
        "port": settings.PORT,
        "database_url": settings.DATABASE_URL.replace(settings.DATABASE_URL.split('/')[-1], '***'),
        "access_token_expire_minutes": settings.ACCESS_TOKEN_EXPIRE_MINUTES,
        "smtp_host": settings.SMTP_HOST,
        "smtp_port": settings.SMTP_PORT,
        "smtp_use_tls": settings.SMTP_USE_TLS,
        "email_from": settings.EMAIL_FROM,
        "email_from_name": settings.EMAIL_FROM_NAME,
        "frontend_url": settings.FRONTEND_URL,
        "reset_password_token_expire_hours": settings.RESET_PASSWORD_TOKEN_EXPIRE_HOURS,
        "activation_token_expire_hours": settings.ACTIVATION_TOKEN_EXPIRE_HOURS
    }
    
    return safe_config

# Gerenciamento de usuários por admin
@router.get("/users", response_model=List[UserResponse])
async def list_all_users(
    skip: int = 0,
    limit: int = 100,
    current_user: User = Depends(get_admin_user),
    db: Session = Depends(get_db)
):
    """Listar todos os usuários"""
    users = db.query(User).offset(skip).limit(limit).all()
    return users

@router.post("/users", response_model=UserResponse)
async def create_user_by_admin(
    user_data: UserCreateByAdmin,
    current_user: User = Depends(get_admin_user),
    db: Session = Depends(get_db)
):
    """Criar usuário pelo administrador"""
    # Verificar se usuário já existe
    if db.query(User).filter(User.email == user_data.email).first():
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Email já cadastrado"
        )
    
    if db.query(User).filter(User.username == user_data.username).first():
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Nome de usuário já existe"
        )
    
    # Criar novo usuário sem senha
    db_user = User(
        email=user_data.email,
        username=user_data.username,
        full_name=user_data.full_name,
        hashed_password=None,
        is_active=False,
        is_admin=user_data.is_admin or False,
        is_email_verified=False
    )
    
    db.add(db_user)
    db.commit()
    db.refresh(db_user)
    
    # Criar perfil se informações foram fornecidas
    if user_data.department or user_data.position or user_data.phone:
        profile = Profile(
            user_id=db_user.id,
            department=user_data.department,
            position=user_data.position,
            phone=user_data.phone
        )
        db.add(profile)
        db.commit()
    
    # Enviar email de ativação
    try:
        email_service.send_activation_email(
            user_email=db_user.email,
            user_name=db_user.full_name,
            user_id=db_user.id
        )
    except Exception as e:
        print(f"Erro ao enviar email de ativação: {e}")
    
    return db_user

@router.put("/users/{user_id}", response_model=UserResponse)
async def update_user_by_admin(
    user_id: int,
    user_update: UserUpdate,
    current_user: User = Depends(get_admin_user),
    db: Session = Depends(get_db)
):
    """Atualizar usuário pelo administrador"""
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Usuário não encontrado"
        )
    
    # Atualizar dados do usuário
    update_data = user_update.dict(exclude_unset=True, exclude={'department', 'position', 'phone'})
    for field, value in update_data.items():
        setattr(user, field, value)
    
    # Atualizar perfil se necessário
    profile_data = {
        'department': user_update.department,
        'position': user_update.position,
        'phone': user_update.phone
    }
    
    if any(v is not None for v in profile_data.values()):
        profile = db.query(Profile).filter(Profile.user_id == user_id).first()
        if not profile:
            profile = Profile(user_id=user_id)
            db.add(profile)
        
        for field, value in profile_data.items():
            if value is not None:
                setattr(profile, field, value)
    
    db.commit()
    db.refresh(user)
    return user

@router.post("/users/{user_id}/toggle-admin")
async def toggle_user_admin(
    user_id: int,
    current_user: User = Depends(get_admin_user),
    db: Session = Depends(get_db)
):
    """Alternar status de admin do usuário"""
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Usuário não encontrado"
        )
    
    # Não permitir remover admin do próprio usuário
    if user.id == current_user.id:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Não é possível alterar seu próprio status de admin"
        )
    
    user.is_admin = not user.is_admin
    db.commit()
    db.refresh(user)
    
    return {"message": f"Status de admin {'ativado' if user.is_admin else 'desativado'} para {user.username}"}

@router.post("/users/{user_id}/toggle-active")
async def toggle_user_active(
    user_id: int,
    current_user: User = Depends(get_admin_user),
    db: Session = Depends(get_db)
):
    """Alternar status ativo do usuário"""
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Usuário não encontrado"
        )
    
    # Não permitir desativar o próprio usuário
    if user.id == current_user.id:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Não é possível desativar seu próprio usuário"
        )
    
    user.is_active = not user.is_active
    db.commit()
    db.refresh(user)
    
    return {"message": f"Usuário {user.username} {'ativado' if user.is_active else 'desativado'}"}

@router.post("/users/{user_id}/reset-password")
async def admin_reset_user_password(
    user_id: int,
    current_user: User = Depends(get_admin_user),
    db: Session = Depends(get_db)
):
    """Administrador solicitar reset de senha para usuário"""
    user = db.query(User).filter(User.id == user_id).first()
    
    if not user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Usuário não encontrado"
        )
    
    # Enviar email de reset
    try:
        email_service.send_password_reset_email(
            user_email=user.email,
            user_name=user.full_name,
            user_id=user.id
        )
        return {"message": f"Email de reset de senha enviado para {user.email}"}
    except Exception as e:
        print(f"Erro ao enviar email de reset: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Erro ao enviar email de reset"
        )

# Gerenciamento de salas
@router.get("/rooms", response_model=List[RoomResponse])
async def list_rooms(
    skip: int = 0,
    limit: int = 100,
    current_user: User = Depends(get_admin_user),
    db: Session = Depends(get_db)
):
    """Listar todas as salas"""
    rooms = db.query(Room).offset(skip).limit(limit).all()
    return rooms

@router.post("/rooms", response_model=RoomResponse)
async def create_room(
    room_data: RoomCreate,
    current_user: User = Depends(get_admin_user),
    db: Session = Depends(get_db)
):
    """Criar nova sala"""
    room = Room(**room_data.dict())
    db.add(room)
    db.commit()
    db.refresh(room)
    return room

@router.put("/rooms/{room_id}", response_model=RoomResponse)
async def update_room(
    room_id: int,
    room_update: RoomUpdate,
    current_user: User = Depends(get_admin_user),
    db: Session = Depends(get_db)
):
    """Atualizar sala"""
    room = db.query(Room).filter(Room.id == room_id).first()
    if not room:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Sala não encontrada"
        )
    
    update_data = room_update.dict(exclude_unset=True)
    for field, value in update_data.items():
        setattr(room, field, value)
    
    db.commit()
    db.refresh(room)
    return room

@router.delete("/rooms/{room_id}")
async def delete_room(
    room_id: int,
    current_user: User = Depends(get_admin_user),
    db: Session = Depends(get_db)
):
    """Deletar sala"""
    room = db.query(Room).filter(Room.id == room_id).first()
    if not room:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Sala não encontrada"
        )
    
    db.delete(room)
    db.commit()
    return {"message": "Sala deletada com sucesso"}

# Gerenciamento de veículos
@router.get("/vehicles", response_model=List[VehicleResponse])
async def list_vehicles(
    skip: int = 0,
    limit: int = 100,
    current_user: User = Depends(get_admin_user),
    db: Session = Depends(get_db)
):
    """Listar todos os veículos"""
    vehicles = db.query(Vehicle).offset(skip).limit(limit).all()
    return vehicles

@router.post("/vehicles", response_model=VehicleResponse)
async def create_vehicle(
    vehicle_data: VehicleCreate,
    current_user: User = Depends(get_admin_user),
    db: Session = Depends(get_db)
):
    """Criar novo veículo"""
    vehicle = Vehicle(**vehicle_data.dict())
    db.add(vehicle)
    db.commit()
    db.refresh(vehicle)
    return vehicle

@router.put("/vehicles/{vehicle_id}", response_model=VehicleResponse)
async def update_vehicle(
    vehicle_id: int,
    vehicle_update: VehicleUpdate,
    current_user: User = Depends(get_admin_user),
    db: Session = Depends(get_db)
):
    """Atualizar veículo"""
    vehicle = db.query(Vehicle).filter(Vehicle.id == vehicle_id).first()
    if not vehicle:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Veículo não encontrado"
        )
    
    update_data = vehicle_update.dict(exclude_unset=True)
    for field, value in update_data.items():
        setattr(vehicle, field, value)
    
    db.commit()
    db.refresh(vehicle)
    return vehicle

@router.delete("/vehicles/{vehicle_id}")
async def delete_vehicle(
    vehicle_id: int,
    current_user: User = Depends(get_admin_user),
    db: Session = Depends(get_db)
):
    """Deletar veículo"""
    vehicle = db.query(Vehicle).filter(Vehicle.id == vehicle_id).first()
    if not vehicle:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Veículo não encontrado"
        )
    
    db.delete(vehicle)
    db.commit()
    return {"message": "Veículo deletado com sucesso"}

