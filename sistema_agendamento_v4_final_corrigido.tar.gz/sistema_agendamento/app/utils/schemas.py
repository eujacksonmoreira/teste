from pydantic import BaseModel, EmailStr, validator
from typing import Optional
from datetime import datetime, date

# Schemas de Usuário
class UserBase(BaseModel):
    email: EmailStr
    username: str
    full_name: str

class UserCreate(UserBase):
    password: Optional[str] = None  # Senha opcional para criação com ativação por email
    send_activation_email: bool = True  # Enviar email de ativação por padrão
    
    @validator('password')
    def validate_password(cls, v):
        if v and len(v) < 6:
            raise ValueError('Senha deve ter pelo menos 6 caracteres')
        return v

class UserCreateByAdmin(UserBase):
    """Schema para criação de usuário pelo admin (sem senha, com email de ativação)"""
    is_admin: Optional[bool] = False
    department: Optional[str] = None
    position: Optional[str] = None
    phone: Optional[str] = None

class UserUpdate(BaseModel):
    email: Optional[EmailStr] = None
    username: Optional[str] = None
    full_name: Optional[str] = None
    is_active: Optional[bool] = None
    is_admin: Optional[bool] = None
    department: Optional[str] = None
    position: Optional[str] = None
    phone: Optional[str] = None

class UserResponse(UserBase):
    id: int
    is_active: bool
    is_admin: bool
    is_email_verified: bool
    created_at: datetime
    
    class Config:
        from_attributes = True

# Schemas de Ativação e Reset de Senha
class ActivateAccountRequest(BaseModel):
    token: str
    password: str
    
    @validator('password')
    def validate_password(cls, v):
        if len(v) < 6:
            raise ValueError('Senha deve ter pelo menos 6 caracteres')
        return v

class PasswordResetRequest(BaseModel):
    email: EmailStr

class PasswordResetConfirm(BaseModel):
    token: str
    new_password: str
    
    @validator('new_password')
    def validate_password(cls, v):
        if len(v) < 6:
            raise ValueError('Senha deve ter pelo menos 6 caracteres')
        return v

class ResendActivationRequest(BaseModel):
    email: EmailStr

# Schemas de Perfil
class ProfileBase(BaseModel):
    department: Optional[str] = None
    position: Optional[str] = None
    phone: Optional[str] = None
    bio: Optional[str] = None
    avatar_url: Optional[str] = None

class ProfileCreate(ProfileBase):
    pass

class ProfileUpdate(ProfileBase):
    pass

class ProfileResponse(ProfileBase):
    id: int
    user_id: int
    created_at: datetime
    
    class Config:
        from_attributes = True

# Schemas de Autenticação
class Token(BaseModel):
    access_token: str
    token_type: str

class TokenData(BaseModel):
    username: Optional[str] = None

class LoginRequest(BaseModel):
    username: str
    password: str

# Schemas de Sala
class RoomBase(BaseModel):
    name: str
    description: Optional[str] = None
    capacity: int = 1
    location: Optional[str] = None
    equipment: Optional[str] = None

class RoomCreate(RoomBase):
    pass

class RoomUpdate(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    capacity: Optional[int] = None
    location: Optional[str] = None
    equipment: Optional[str] = None
    is_active: Optional[bool] = None

class RoomResponse(RoomBase):
    id: int
    is_active: bool
    created_at: datetime
    
    class Config:
        from_attributes = True

# Schemas de Veículo
class VehicleBase(BaseModel):
    name: str
    model: Optional[str] = None
    brand: Optional[str] = None
    license_plate: Optional[str] = None
    year: Optional[int] = None
    fuel_type: Optional[str] = None
    capacity: int = 5
    description: Optional[str] = None

class VehicleCreate(VehicleBase):
    pass

class VehicleUpdate(BaseModel):
    name: Optional[str] = None
    model: Optional[str] = None
    brand: Optional[str] = None
    license_plate: Optional[str] = None
    year: Optional[int] = None
    fuel_type: Optional[str] = None
    capacity: Optional[int] = None
    description: Optional[str] = None
    is_active: Optional[bool] = None

class VehicleResponse(VehicleBase):
    id: int
    is_active: bool
    created_at: datetime
    
    class Config:
        from_attributes = True


# Schemas de Reserva
class BookingBase(BaseModel):
    title: str
    description: Optional[str] = None
    start_datetime: datetime
    end_datetime: datetime
    
    @validator('end_datetime')
    def validate_end_datetime(cls, v, values):
        if 'start_datetime' in values and v <= values['start_datetime']:
            raise ValueError('Data/hora de fim deve ser posterior ao início')
        return v
    
    @validator('start_datetime', 'end_datetime')
    def validate_same_day(cls, v, values):
        if 'start_datetime' in values:
            start_date = values['start_datetime'].date()
            end_date = v.date()
            if start_date != end_date:
                raise ValueError('Reservas devem ser no mesmo dia')
        return v

class BookingCreate(BookingBase):
    room_id: Optional[int] = None
    vehicle_id: Optional[int] = None
    
    @validator('room_id')
    def validate_resource(cls, v, values):
        if not v and not values.get('vehicle_id'):
            raise ValueError('Deve ser especificada uma sala ou veículo')
        if v and values.get('vehicle_id'):
            raise ValueError('Não é possível reservar sala e veículo simultaneamente')
        return v

class BookingUpdate(BaseModel):
    title: Optional[str] = None
    description: Optional[str] = None
    start_datetime: Optional[datetime] = None
    end_datetime: Optional[datetime] = None

class BookingResponse(BookingBase):
    id: int
    user_id: int
    room_id: Optional[int] = None
    vehicle_id: Optional[int] = None
    booking_type: str
    status: str
    created_at: datetime
    
    # Relacionamentos
    user: Optional[UserResponse] = None
    room: Optional[RoomResponse] = None
    vehicle: Optional[VehicleResponse] = None
    
    class Config:
        from_attributes = True

# Schemas de Agenda Semanal
class WeeklyScheduleBase(BaseModel):
    week_start_date: date
    day_of_week: str
    period: str
    location: str
    activity: Optional[str] = None
    description: Optional[str] = None

class WeeklyScheduleCreate(WeeklyScheduleBase):
    pass

class WeeklyScheduleUpdate(BaseModel):
    location: Optional[str] = None
    activity: Optional[str] = None
    description: Optional[str] = None

class WeeklyScheduleResponse(WeeklyScheduleBase):
    id: int
    user_id: int
    created_at: datetime
    
    class Config:
        from_attributes = True

