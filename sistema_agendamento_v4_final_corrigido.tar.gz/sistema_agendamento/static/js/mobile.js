// Funcionalidades específicas para dispositivos móveis
class MobileManager {
    constructor() {
        this.isMobile = this.detectMobile();
        this.isTouch = this.detectTouch();
        this.init();
    }

    detectMobile() {
        return window.innerWidth <= 768 || /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
    }

    detectTouch() {
        return 'ontouchstart' in window || navigator.maxTouchPoints > 0;
    }

    init() {
        if (this.isMobile) {
            this.setupMobileNavigation();
            this.setupTouchInteractions();
            this.setupMobileOptimizations();
        }

        this.setupResponsiveHandlers();
        this.setupOrientationHandler();
    }

    setupMobileNavigation() {
        // Criar navegação móvel fixa no bottom
        this.createBottomNavigation();
        
        // Melhorar navegação do navbar
        this.improveMobileNavbar();
    }

    createBottomNavigation() {
        // Verificar se já existe
        if (document.querySelector('.mobile-nav')) return;

        const mobileNav = document.createElement('div');
        mobileNav.className = 'mobile-nav d-md-none';
        
        const nav = document.createElement('nav');
        nav.className = 'nav';

        const navItems = [
            { href: '/', icon: 'fas fa-home', label: 'Início' },
            { href: '/bookings', icon: 'fas fa-calendar-check', label: 'Reservas' },
            { href: '/schedule', icon: 'fas fa-calendar-week', label: 'Agenda' },
            { href: '/admin', icon: 'fas fa-cogs', label: 'Admin', adminOnly: true }
        ];

        navItems.forEach(item => {
            if (item.adminOnly && !this.isAdmin()) return;

            const link = document.createElement('a');
            link.href = item.href;
            link.className = 'nav-link';
            link.innerHTML = `
                <i class="${item.icon}"></i>
                <span>${item.label}</span>
            `;

            // Marcar como ativo se for a página atual
            if (window.location.pathname === item.href) {
                link.classList.add('active');
            }

            nav.appendChild(link);
        });

        mobileNav.appendChild(nav);
        document.body.appendChild(mobileNav);
    }

    improveMobileNavbar() {
        const navbar = document.querySelector('.navbar');
        if (!navbar) return;

        // Adicionar classe para mobile
        navbar.classList.add('mobile-optimized');

        // Melhorar o collapse do navbar
        const navbarToggler = navbar.querySelector('.navbar-toggler');
        const navbarCollapse = navbar.querySelector('.navbar-collapse');

        if (navbarToggler && navbarCollapse) {
            navbarToggler.addEventListener('click', () => {
                // Adicionar animação suave
                navbarCollapse.style.transition = 'all 0.3s ease';
            });

            // Fechar navbar ao clicar em um link
            navbarCollapse.addEventListener('click', (e) => {
                if (e.target.classList.contains('nav-link')) {
                    const bsCollapse = new bootstrap.Collapse(navbarCollapse, {
                        toggle: false
                    });
                    bsCollapse.hide();
                }
            });
        }
    }

    setupTouchInteractions() {
        // Melhorar interações touch
        this.setupSwipeGestures();
        this.setupTouchFeedback();
        this.setupPullToRefresh();
    }

    setupSwipeGestures() {
        let startX, startY, endX, endY;

        document.addEventListener('touchstart', (e) => {
            startX = e.touches[0].clientX;
            startY = e.touches[0].clientY;
        }, { passive: true });

        document.addEventListener('touchend', (e) => {
            if (!startX || !startY) return;

            endX = e.changedTouches[0].clientX;
            endY = e.changedTouches[0].clientY;

            const diffX = startX - endX;
            const diffY = startY - endY;

            // Detectar swipe horizontal
            if (Math.abs(diffX) > Math.abs(diffY) && Math.abs(diffX) > 50) {
                if (diffX > 0) {
                    // Swipe left
                    this.handleSwipeLeft();
                } else {
                    // Swipe right
                    this.handleSwipeRight();
                }
            }

            // Reset
            startX = startY = endX = endY = null;
        }, { passive: true });
    }

    handleSwipeLeft() {
        // Implementar navegação por swipe se necessário
        console.log('Swipe left detected');
    }

    handleSwipeRight() {
        // Implementar navegação por swipe se necessário
        console.log('Swipe right detected');
    }

    setupTouchFeedback() {
        // Adicionar feedback visual para toques
        document.addEventListener('touchstart', (e) => {
            const target = e.target.closest('.btn, .card-hover-effect, .nav-link');
            if (target) {
                target.style.transform = 'scale(0.98)';
                target.style.transition = 'transform 0.1s ease';
            }
        }, { passive: true });

        document.addEventListener('touchend', (e) => {
            const target = e.target.closest('.btn, .card-hover-effect, .nav-link');
            if (target) {
                setTimeout(() => {
                    target.style.transform = '';
                    target.style.transition = '';
                }, 100);
            }
        }, { passive: true });
    }

    setupPullToRefresh() {
        let startY = 0;
        let pullDistance = 0;
        const threshold = 100;

        document.addEventListener('touchstart', (e) => {
            if (window.scrollY === 0) {
                startY = e.touches[0].clientY;
            }
        }, { passive: true });

        document.addEventListener('touchmove', (e) => {
            if (startY && window.scrollY === 0) {
                pullDistance = e.touches[0].clientY - startY;
                
                if (pullDistance > 0 && pullDistance < threshold * 2) {
                    // Mostrar indicador de pull to refresh
                    this.showPullToRefreshIndicator(pullDistance / threshold);
                }
            }
        }, { passive: true });

        document.addEventListener('touchend', () => {
            if (pullDistance > threshold) {
                this.triggerRefresh();
            }
            this.hidePullToRefreshIndicator();
            startY = 0;
            pullDistance = 0;
        }, { passive: true });
    }

    showPullToRefreshIndicator(progress) {
        let indicator = document.querySelector('.pull-to-refresh-indicator');
        if (!indicator) {
            indicator = document.createElement('div');
            indicator.className = 'pull-to-refresh-indicator';
            indicator.style.cssText = `
                position: fixed;
                top: 0;
                left: 50%;
                transform: translateX(-50%);
                background: var(--sicredi-green);
                color: white;
                padding: 0.5rem 1rem;
                border-radius: 0 0 10px 10px;
                font-size: 0.8rem;
                z-index: 1050;
                transition: all 0.2s ease;
            `;
            document.body.appendChild(indicator);
        }

        const opacity = Math.min(progress, 1);
        indicator.style.opacity = opacity;
        indicator.style.transform = `translateX(-50%) translateY(${-20 + (20 * opacity)}px)`;
        indicator.textContent = progress >= 1 ? 'Solte para atualizar' : 'Puxe para atualizar';
    }

    hidePullToRefreshIndicator() {
        const indicator = document.querySelector('.pull-to-refresh-indicator');
        if (indicator) {
            indicator.style.opacity = '0';
            setTimeout(() => {
                if (indicator.parentNode) {
                    indicator.remove();
                }
            }, 200);
        }
    }

    triggerRefresh() {
        // Mostrar loading
        this.showRefreshLoading();
        
        // Simular refresh (recarregar página ou atualizar dados)
        setTimeout(() => {
            window.location.reload();
        }, 1000);
    }

    showRefreshLoading() {
        const indicator = document.querySelector('.pull-to-refresh-indicator');
        if (indicator) {
            indicator.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Atualizando...';
        }
    }

    setupMobileOptimizations() {
        // Otimizações específicas para mobile
        this.optimizeViewport();
        this.optimizeScrolling();
        this.optimizeModals();
        this.optimizeTables();
    }

    optimizeViewport() {
        // Prevenir zoom em inputs no iOS
        const inputs = document.querySelectorAll('input, select, textarea');
        inputs.forEach(input => {
            if (input.style.fontSize === '' || parseFloat(input.style.fontSize) < 16) {
                input.style.fontSize = '16px';
            }
        });
    }

    optimizeScrolling() {
        // Melhorar scroll em iOS
        document.body.style.webkitOverflowScrolling = 'touch';
        
        // Adicionar momentum scrolling para elementos com overflow
        const scrollableElements = document.querySelectorAll('.table-responsive, .modal-body');
        scrollableElements.forEach(element => {
            element.style.webkitOverflowScrolling = 'touch';
        });
    }

    optimizeModals() {
        // Melhorar modais para mobile
        const modals = document.querySelectorAll('.modal');
        modals.forEach(modal => {
            modal.addEventListener('shown.bs.modal', () => {
                // Prevenir scroll do body
                document.body.style.overflow = 'hidden';
                
                // Focar no primeiro input se existir
                const firstInput = modal.querySelector('input, select, textarea');
                if (firstInput && this.isTouch) {
                    // Delay para evitar problemas com teclado virtual
                    setTimeout(() => {
                        firstInput.focus();
                    }, 300);
                }
            });

            modal.addEventListener('hidden.bs.modal', () => {
                // Restaurar scroll do body
                document.body.style.overflow = '';
            });
        });
    }

    optimizeTables() {
        // Melhorar tabelas para mobile
        const tables = document.querySelectorAll('.table');
        tables.forEach(table => {
            if (!table.closest('.table-responsive')) {
                const wrapper = document.createElement('div');
                wrapper.className = 'table-responsive';
                table.parentNode.insertBefore(wrapper, table);
                wrapper.appendChild(table);
            }
        });
    }

    setupResponsiveHandlers() {
        // Handlers para mudanças de tamanho de tela
        let resizeTimer;
        window.addEventListener('resize', () => {
            clearTimeout(resizeTimer);
            resizeTimer = setTimeout(() => {
                this.handleResize();
            }, 250);
        });
    }

    handleResize() {
        const wasMobile = this.isMobile;
        this.isMobile = this.detectMobile();

        if (wasMobile !== this.isMobile) {
            // Mudou entre mobile e desktop
            if (this.isMobile) {
                this.setupMobileNavigation();
            } else {
                this.removeMobileNavigation();
            }
        }

        // Atualizar altura de elementos se necessário
        this.updateElementHeights();
    }

    removeMobileNavigation() {
        const mobileNav = document.querySelector('.mobile-nav');
        if (mobileNav) {
            mobileNav.remove();
        }
        document.body.style.paddingBottom = '';
    }

    updateElementHeights() {
        // Atualizar altura de elementos baseado na viewport
        const vh = window.innerHeight * 0.01;
        document.documentElement.style.setProperty('--vh', `${vh}px`);
    }

    setupOrientationHandler() {
        // Handler para mudança de orientação
        window.addEventListener('orientationchange', () => {
            setTimeout(() => {
                this.handleOrientationChange();
            }, 100);
        });
    }

    handleOrientationChange() {
        // Atualizar viewport height
        this.updateElementHeights();
        
        // Fechar navbar se estiver aberto
        const navbarCollapse = document.querySelector('.navbar-collapse.show');
        if (navbarCollapse) {
            const bsCollapse = new bootstrap.Collapse(navbarCollapse, {
                toggle: false
            });
            bsCollapse.hide();
        }

        // Reposicionar elementos se necessário
        this.repositionElements();
    }

    repositionElements() {
        // Reposicionar elementos após mudança de orientação
        const modals = document.querySelectorAll('.modal.show');
        modals.forEach(modal => {
            // Forçar recálculo da posição do modal
            modal.style.display = 'none';
            modal.offsetHeight; // Trigger reflow
            modal.style.display = 'block';
        });
    }

    isAdmin() {
        // Verificar se o usuário é admin
        return window.authManager && window.authManager.user && window.authManager.user.is_admin;
    }

    // Métodos públicos
    isMobileDevice() {
        return this.isMobile;
    }

    isTouchDevice() {
        return this.isTouch;
    }

    showMobileAlert(message, type = 'info') {
        // Mostrar alerta otimizado para mobile
        const alert = document.createElement('div');
        alert.className = `alert alert-${type} mobile-alert`;
        alert.style.cssText = `
            position: fixed;
            top: 20px;
            left: 20px;
            right: 20px;
            z-index: 1060;
            border-radius: 8px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.3);
            animation: slideDown 0.3s ease;
        `;
        alert.innerHTML = `
            ${message}
            <button type="button" class="btn-close" onclick="this.parentElement.remove()"></button>
        `;

        document.body.appendChild(alert);

        // Auto-remover após 5 segundos
        setTimeout(() => {
            if (alert.parentNode) {
                alert.style.animation = 'slideUp 0.3s ease';
                setTimeout(() => alert.remove(), 300);
            }
        }, 5000);
    }
}

// CSS para animações
const mobileStyles = `
@keyframes slideDown {
    from { transform: translateY(-100%); opacity: 0; }
    to { transform: translateY(0); opacity: 1; }
}

@keyframes slideUp {
    from { transform: translateY(0); opacity: 1; }
    to { transform: translateY(-100%); opacity: 0; }
}

.mobile-alert {
    animation: slideDown 0.3s ease;
}
`;

// Adicionar estilos
const styleSheet = document.createElement('style');
styleSheet.textContent = mobileStyles;
document.head.appendChild(styleSheet);

// Inicializar quando o DOM estiver carregado
document.addEventListener('DOMContentLoaded', function() {
    window.mobileManager = new MobileManager();
});

// Exportar para uso em outros scripts
if (typeof module !== 'undefined' && module.exports) {
    module.exports = MobileManager;
}

