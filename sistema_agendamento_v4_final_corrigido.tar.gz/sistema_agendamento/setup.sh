#!/bin/bash

# Script de configuração do Sistema de Agendamento
# Este script instala e configura o sistema completo

set -e

echo "🚀 Iniciando configuração do Sistema de Agendamento..."

# Cores para output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Função para imprimir mensagens coloridas
print_status() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Verificar se está executando como root para algumas operações
check_root() {
    if [[ $EUID -ne 0 ]]; then
        print_warning "Algumas operações podem precisar de privilégios sudo"
    fi
}

# Instalar dependências do sistema
install_system_dependencies() {
    print_status "Instalando dependências do sistema..."
    
    # Atualizar lista de pacotes
    sudo apt update
    
    # Instalar Python 3.11 e pip se não estiverem instalados
    if ! command -v python3.11 &> /dev/null; then
        print_status "Instalando Python 3.11..."
        sudo apt install -y python3.11 python3.11-venv python3.11-dev
    fi
    
    if ! command -v pip3 &> /dev/null; then
        print_status "Instalando pip..."
        sudo apt install -y python3-pip
    fi
    
    # Instalar Nginx se não estiver instalado
    if ! command -v nginx &> /dev/null; then
        print_status "Instalando Nginx..."
        sudo apt install -y nginx
    fi
    
    # Instalar SQLite se não estiver instalado
    if ! command -v sqlite3 &> /dev/null; then
        print_status "Instalando SQLite..."
        sudo apt install -y sqlite3
    fi
    
    print_success "Dependências do sistema instaladas!"
}

# Criar ambiente virtual Python
setup_python_environment() {
    print_status "Configurando ambiente virtual Python..."
    
    # Criar ambiente virtual se não existir
    if [ ! -d "venv" ]; then
        python3.11 -m venv venv
        print_success "Ambiente virtual criado!"
    fi
    
    # Ativar ambiente virtual
    source venv/bin/activate
    
    # Atualizar pip
    pip install --upgrade pip
    
    # Instalar dependências
    print_status "Instalando dependências Python..."
    pip install -r requirements.txt
    
    print_success "Ambiente Python configurado!"
}

# Configurar banco de dados
setup_database() {
    print_status "Configurando banco de dados..."
    
    # Criar diretório de logs se não existir
    mkdir -p logs
    
    # Criar arquivo .env se não existir
    if [ ! -f ".env" ]; then
        print_status "Criando arquivo .env..."
        cp .env.example .env
        print_warning "Configure o arquivo .env com suas configurações específicas"
    fi
    
    print_success "Banco de dados configurado!"
}

# Configurar Nginx
setup_nginx() {
    print_status "Configurando Nginx..."
    
    # Copiar configuração do Nginx
    sudo cp nginx.conf /etc/nginx/sites-available/sistema_agendamento
    
    # Criar link simbólico se não existir
    if [ ! -L "/etc/nginx/sites-enabled/sistema_agendamento" ]; then
        sudo ln -s /etc/nginx/sites-available/sistema_agendamento /etc/nginx/sites-enabled/
    fi
    
    # Testar configuração do Nginx
    if sudo nginx -t; then
        print_success "Configuração do Nginx válida!"
        
        # Recarregar Nginx
        sudo systemctl reload nginx
        print_success "Nginx recarregado!"
    else
        print_error "Erro na configuração do Nginx!"
        return 1
    fi
}

# Criar serviço systemd
create_systemd_service() {
    print_status "Criando serviço systemd..."
    
    # Obter caminho absoluto do projeto
    PROJECT_PATH=$(pwd)
    USER=$(whoami)
    
    # Criar arquivo de serviço
    sudo tee /etc/systemd/system/sistema-agendamento.service > /dev/null <<EOF
[Unit]
Description=Sistema de Agendamento FastAPI
After=network.target

[Service]
Type=simple
User=$USER
WorkingDirectory=$PROJECT_PATH
Environment=PATH=$PROJECT_PATH/venv/bin
ExecStart=$PROJECT_PATH/venv/bin/uvicorn main:app --host 0.0.0.0 --port 8000
Restart=always
RestartSec=3

[Install]
WantedBy=multi-user.target
EOF
    
    # Recarregar systemd
    sudo systemctl daemon-reload
    
    # Habilitar serviço
    sudo systemctl enable sistema-agendamento
    
    print_success "Serviço systemd criado!"
}

# Inicializar aplicação
initialize_app() {
    print_status "Inicializando aplicação..."
    
    # Ativar ambiente virtual
    source venv/bin/activate
    
    # Executar aplicação em background para criar tabelas
    python main.py &
    APP_PID=$!
    
    # Aguardar alguns segundos para a aplicação inicializar
    sleep 5
    
    # Parar aplicação
    kill $APP_PID 2>/dev/null || true
    
    print_success "Aplicação inicializada!"
}

# Função principal
main() {
    print_status "Sistema de Agendamento - Script de Configuração"
    echo "================================================"
    
    check_root
    
    # Verificar se estamos no diretório correto
    if [ ! -f "main.py" ] || [ ! -f "requirements.txt" ]; then
        print_error "Execute este script no diretório raiz do projeto!"
        exit 1
    fi
    
    # Executar configurações
    install_system_dependencies
    setup_python_environment
    setup_database
    
    # Perguntar se deseja configurar Nginx
    read -p "Deseja configurar o Nginx? (y/n): " -n 1 -r
    echo
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        setup_nginx
    fi
    
    # Perguntar se deseja criar serviço systemd
    read -p "Deseja criar serviço systemd? (y/n): " -n 1 -r
    echo
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        create_systemd_service
    fi
    
    initialize_app
    
    echo
    print_success "🎉 Configuração concluída com sucesso!"
    echo
    echo "Para iniciar o sistema:"
    echo "  1. Ative o ambiente virtual: source venv/bin/activate"
    echo "  2. Execute a aplicação: python main.py"
    echo "  3. Ou use o serviço systemd: sudo systemctl start sistema-agendamento"
    echo
    echo "Acesse o sistema em: http://localhost:8000"
    echo "Credenciais padrão: admin / admin123"
    echo
    print_warning "Lembre-se de configurar o arquivo .env com suas configurações específicas!"
}

# Executar função principal
main "$@"

