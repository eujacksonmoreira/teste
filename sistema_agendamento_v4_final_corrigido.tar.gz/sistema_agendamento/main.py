from fastapi import FastAPI, Request
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse
import uvicorn
import logging

from config.settings import settings
from config.logging import setup_logging
from app.models.database import engine, Base
from app.routes import auth, users, bookings, schedule, admin, roles

# Configurar logging
logger = setup_logging()

# Criar tabelas do banco de dados
Base.metadata.create_all(bind=engine)

# Criar aplicação FastAPI
app = FastAPI(
    title=settings.APP_NAME,
    version=settings.APP_VERSION,
    debug=settings.DEBUG
)

# Configurar CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.ALLOWED_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Configurar arquivos estáticos e templates
app.mount("/static", StaticFiles(directory="static"), name="static")
templates = Jinja2Templates(directory="templates")

# Incluir rotas da API
try:
    app.include_router(auth.router, prefix="/api/auth", tags=["Autenticação"])
    app.include_router(users.router, prefix="/api/users", tags=["Usuários"])
    app.include_router(bookings.router, prefix="/api/bookings", tags=["Reservas"])
    app.include_router(schedule.router, prefix="/api/schedule", tags=["Agenda"])
    app.include_router(admin.router, prefix="/api/admin", tags=["Administração"])
    app.include_router(roles.router, prefix="/api/roles", tags=["Roles e Permissões"])
except ImportError as e:
    logger.warning(f"Erro ao importar rotas: {e}")

# Rotas das páginas HTML
@app.get("/", response_class=HTMLResponse)
async def home(request: Request):
    """Página inicial do sistema"""
    return templates.TemplateResponse("index.html", {"request": request})

@app.get("/login", response_class=HTMLResponse)
async def login_page(request: Request):
    """Página de login"""
    return templates.TemplateResponse("login.html", {"request": request})

@app.get("/bookings", response_class=HTMLResponse)
async def bookings_page(request: Request):
    """Página de reservas"""
    return templates.TemplateResponse("bookings.html", {"request": request})

@app.get("/schedule", response_class=HTMLResponse)
async def schedule_page(request: Request):
    """Página de agenda semanal"""
    return templates.TemplateResponse("schedule.html", {"request": request})

@app.get("/profile", response_class=HTMLResponse)
async def profile_page(request: Request):
    """Página de perfil"""
    return templates.TemplateResponse("profile.html", {"request": request})

@app.get("/admin/users", response_class=HTMLResponse)
async def user_management_page(request: Request):
    """Página de gerenciamento de usuários"""
    return templates.TemplateResponse("user_management.html", {"request": request})

@app.get("/login", response_class=HTMLResponse)
async def login_page(request: Request):
    """Página de login exclusiva"""
    return templates.TemplateResponse("login.html", {"request": request})

@app.get("/activate-account", response_class=HTMLResponse)
async def activate_account_page(request: Request):
    """Página de ativação de conta"""
    return templates.TemplateResponse("activate_account.html", {"request": request})

@app.get("/reset-password", response_class=HTMLResponse)
async def reset_password_page(request: Request):
    """Página de redefinição de senha"""
    return templates.TemplateResponse("reset_password.html", {"request": request})

@app.get("/admin/parameters", response_class=HTMLResponse)
async def admin_parameters_page(request: Request):
    """Página de parâmetros administrativos"""
    return templates.TemplateResponse("admin_parameters.html", {"request": request})

@app.get("/admin/reports", response_class=HTMLResponse)
async def admin_reports_page(request: Request):
    """Página de relatórios administrativos"""
    return templates.TemplateResponse("admin_reports.html", {"request": request})

@app.get("/admin/dashboard", response_class=HTMLResponse)
async def admin_dashboard_page(request: Request):
    """Página de dashboard administrativo"""
    return templates.TemplateResponse("admin_dashboard.html", {"request": request})

@app.get("/admin", response_class=HTMLResponse)
async def admin_page(request: Request):
    """Página de administração"""
    return templates.TemplateResponse("admin.html", {"request": request})

@app.get("/health")
async def health_check():
    """Endpoint para verificação de saúde da aplicação"""
    return {"status": "ok", "message": "Sistema funcionando corretamente"}

@app.on_event("startup")
async def startup_event():
    """Eventos executados na inicialização da aplicação"""
    logger.info(f"Iniciando {settings.APP_NAME} v{settings.APP_VERSION}")
    
    # Criar usuário admin padrão se não existir
    from app.services.user_service import create_default_admin
    await create_default_admin()

@app.on_event("shutdown")
async def shutdown_event():
    """Eventos executados no encerramento da aplicação"""
    logger.info("Encerrando aplicação")

if __name__ == "__main__":
    uvicorn.run(
        "main:app",
        host=settings.HOST,
        port=settings.PORT,
        reload=settings.DEBUG,
        log_level=settings.LOG_LEVEL.lower()
    )

