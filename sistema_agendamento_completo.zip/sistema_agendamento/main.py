from fastapi import FastAPI, Request
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse
import uvicorn
import logging

from config.settings import settings
from config.logging import setup_logging
from app.models.database import engine, Base
from app.routes import auth, users, bookings, schedule, admin

# Configurar logging
logger = setup_logging()

# Criar tabelas do banco de dados
Base.metadata.create_all(bind=engine)

# Criar aplicação FastAPI
app = FastAPI(
    title=settings.APP_NAME,
    version=settings.APP_VERSION,
    debug=settings.DEBUG
)

# Configurar CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.ALLOWED_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Configurar arquivos estáticos e templates
app.mount("/static", StaticFiles(directory="static"), name="static")
templates = Jinja2Templates(directory="templates")

# Incluir rotas da API
try:
    app.include_router(auth.router, prefix="/api/auth", tags=["Autenticação"])
    app.include_router(users.router, prefix="/api/users", tags=["Usuários"])
    app.include_router(bookings.router, prefix="/api/bookings", tags=["Reservas"])
    app.include_router(schedule.router, prefix="/api/schedule", tags=["Agenda"])
    app.include_router(admin.router, prefix="/api/admin", tags=["Administração"])
except ImportError as e:
    logger.warning(f"Erro ao importar rotas: {e}")

# Rotas das páginas HTML
@app.get("/", response_class=HTMLResponse)
async def home(request: Request):
    """Página inicial do sistema"""
    return templates.TemplateResponse("index.html", {"request": request})

@app.get("/login", response_class=HTMLResponse)
async def login_page(request: Request):
    """Página de login"""
    return templates.TemplateResponse("login.html", {"request": request})

@app.get("/register", response_class=HTMLResponse)
async def register_page(request: Request):
    """Página de registro"""
    return templates.TemplateResponse("register.html", {"request": request})

@app.get("/bookings", response_class=HTMLResponse)
async def bookings_page(request: Request):
    """Página de reservas"""
    return templates.TemplateResponse("bookings.html", {"request": request})

@app.get("/schedule", response_class=HTMLResponse)
async def schedule_page(request: Request):
    """Página de agenda semanal"""
    return templates.TemplateResponse("schedule.html", {"request": request})

@app.get("/profile", response_class=HTMLResponse)
async def profile_page(request: Request):
    """Página de perfil"""
    return templates.TemplateResponse("profile.html", {"request": request})

@app.get("/admin", response_class=HTMLResponse)
async def admin_page(request: Request):
    """Página de administração"""
    return templates.TemplateResponse("admin.html", {"request": request})

@app.get("/health")
async def health_check():
    """Endpoint para verificação de saúde da aplicação"""
    return {"status": "ok", "message": "Sistema funcionando corretamente"}

@app.on_event("startup")
async def startup_event():
    """Eventos executados na inicialização da aplicação"""
    logger.info(f"Iniciando {settings.APP_NAME} v{settings.APP_VERSION}")
    
    # Criar usuário admin padrão se não existir
    from app.services.user_service import create_default_admin
    await create_default_admin()

@app.on_event("shutdown")
async def shutdown_event():
    """Eventos executados no encerramento da aplicação"""
    logger.info("Encerrando aplicação")

if __name__ == "__main__":
    uvicorn.run(
        "main:app",
        host=settings.HOST,
        port=settings.PORT,
        reload=settings.DEBUG,
        log_level=settings.LOG_LEVEL.lower()
    )

